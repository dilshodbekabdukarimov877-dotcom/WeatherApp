package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.api.GeocodingResult
import com.example.data.api.WeatherResponse
import com.example.data.db.AlertEntity
import com.example.data.db.SavedLocation
import com.example.ui.theme.*
import com.example.ui.utils.WeatherInfo
import com.example.ui.utils.WeatherProbabilityInfo
import com.example.ui.utils.WeatherUtils
import com.example.ui.utils.WeatherBackgroundManager
import com.example.ui.utils.WeatherTheme
import com.example.ui.viewmodel.WeatherUiState
import com.example.ui.viewmodel.WeatherViewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherDashboard(viewModel: WeatherViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val isSearching by viewModel.isSearching.collectAsStateWithLifecycle()
    val savedLocations by viewModel.savedLocations.collectAsStateWithLifecycle()
    val weatherAlerts by viewModel.weatherAlerts.collectAsStateWithLifecycle()
    val unreadAlertsCount by viewModel.unreadAlertsCount.collectAsStateWithLifecycle()
    val recentSearches by viewModel.recentSearches.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()

    // Location Permission Launcher
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
        if (fineGranted || coarseGranted) {
            viewModel.requestDeviceLocation(context)
        }
    }

    // Android 13+ Notification Permission Launcher
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Handle outcome if needed, otherwise repo handles notification creation
    }

    // Request Notification and Location permissions automatically on startup to fetch local weather immediately
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val fineGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fineGranted || coarseGranted) {
            viewModel.requestDeviceLocation(context)
        } else {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    // Determine currently active weather metadata to drive atmosphere background colors
    val activeWeatherInfo = remember(uiState) {
        when (val state = uiState) {
            is WeatherUiState.Success -> {
                val isDay = state.weather.current?.isDay != 0
                val code = state.weather.current?.weatherCode ?: 0
                WeatherUtils.getWeatherInfo(code, isDay)
            }
            else -> WeatherUtils.getWeatherInfo(0, true) // fallback clear sky
        }
    }

    val lazyListState = rememberLazyListState()
    val scrollOffsetProvider: () -> Float = remember {
        {
            if (lazyListState.firstVisibleItemIndex == 0) {
                lazyListState.firstVisibleItemScrollOffset.toFloat()
            } else {
                1000f + lazyListState.firstVisibleItemIndex.toFloat() * 350f
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // 1. Moving Atmospheric Background Canvas (Strong Blur Effect with Parallax & Motion Blur)
        AnimatedAtmosphereBackground(weatherInfo = activeWeatherInfo, scrollOffsetProvider = scrollOffsetProvider)

        // 2. Weather Particles overlay (drifting rain or floating snow particles with Motion Blur)
        WeatherOverlayParticles(weatherInfo = activeWeatherInfo, scrollOffsetProvider = scrollOffsetProvider)

        // Main Scrolling Dashboard
        Scaffold(
            containerColor = Color.Transparent, // fully see-through scaffold to see frosted blur effect
            topBar = {
                GlassmorphicTopBar(
                    searchQuery = searchQuery,
                    searchResults = searchResults,
                    isSearching = isSearching,
                    unreadAlertsCount = unreadAlertsCount,
                    recentSearches = recentSearches,
                    isDarkMode = isDarkMode,
                    currentLanguage = currentLanguage,
                    onLanguageChange = { viewModel.setLanguage(it) },
                    onToggleTheme = { viewModel.toggleTheme() },
                    onQueryChange = { viewModel.onSearchQueryChange(it) },
                    onSuggestionClick = { result -> viewModel.saveLocationFromResult(result) },
                    onSearchHistoryClick = { query -> viewModel.onSearchQueryChange(query) },
                    onClearHistory = { viewModel.clearSearchHistory() },
                    onRequestLocation = {
                        val fineGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        val coarseGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        if (fineGranted || coarseGranted) {
                            viewModel.requestDeviceLocation(context)
                        } else {
                            locationPermissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                        }
                    }
                )
            },
            modifier = Modifier.fillMaxSize()
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                AnimatedContent(
                    targetState = uiState,
                    transitionSpec = {
                        (fadeIn(animationSpec = tween(400)) + scaleIn(initialScale = 0.96f, animationSpec = spring(stiffness = Spring.StiffnessLow)))
                            .togetherWith(fadeOut(animationSpec = tween(300)) + scaleOut(targetScale = 0.96f, animationSpec = tween(300)))
                    },
                    label = "DashboardStateTransition",
                    modifier = Modifier.fillMaxSize()
                ) { state ->
                    when (state) {
                        is WeatherUiState.Loading -> {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(
                                        color = NeonCyan,
                                        modifier = Modifier.size(50.dp)
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = "Syncing Atmospheric Waves...",
                                        color = Color.White,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                        is WeatherUiState.Success -> {
                            SuccessDashboardContent(
                                state = state,
                                savedLocations = savedLocations,
                                viewModel = viewModel,
                                currentLanguage = currentLanguage,
                                lazyListState = lazyListState
                            )
                        }
                        is WeatherUiState.Error -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                GlassCard(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(24.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.CloudOff,
                                            contentDescription = "Cloud Offline",
                                            tint = ExtremeRed,
                                            modifier = Modifier.size(64.dp)
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        Text(
                                            text = "Synchronization Disrupted",
                                            color = Color.White,
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = state.message,
                                            color = Color.White.copy(alpha = 0.7f),
                                            textAlign = TextAlign.Center,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Spacer(modifier = Modifier.height(24.dp))
                                        Button(
                                            onClick = { viewModel.refreshCurrentWeather() },
                                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Refresh,
                                                contentDescription = "Retry",
                                                tint = Color.Black
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Re-establish Connection", color = Color.Black, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- Dynamic Meteorological Background Canvas (Strong Blur Ambient Canvas) ---
@Composable
fun AnimatedAtmosphereBackground(
    weatherInfo: WeatherInfo,
    scrollOffsetProvider: () -> Float = { 0f }
) {
    val theme = remember(weatherInfo) { WeatherBackgroundManager.resolveTheme(weatherInfo) }
    val themeState = WeatherBackgroundManager.animateThemeState(theme)

    val color1 = themeState.color1
    val color2 = themeState.color2
    val color3 = themeState.color3
    val isCloudy = theme == WeatherTheme.CLOUDY

    val infiniteTransition = rememberInfiniteTransition(label = "AtmosphericDrift")

    // Reusable Path instances to prevent heap allocations during animation draw frames
    val wavePath = remember { Path() }
    val crescentPath = remember { Path() }
    val mPath = remember { Path() }
    val h1Path = remember { Path() }
    val h2Path = remember { Path() }
    val pPath = remember { Path() }
    val snowCapPath = remember { Path() }
    val boltPath = remember { Path() }

    // Gentle sun halo pulse
    val sunPulse by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "SunPulse"
    )

    // Smooth ambient drift offset driven by infinite transition
    val driftOffsetState = infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(30000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "AtmosphericDriftOffset"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        // 1. BACKDROP: Smooth ambient aurora light field Canvas with Motion Blur & Parallax
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val dynamicOffset = driftOffsetState.value
            val parallaxAuroraY = scrollOffsetProvider() * 0.08f

            // Render rich full-bleed baseline gradient
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(color1, color2, color3)
                )
            )

            // Calculate precise center points of glowing ambient blobs depending on weather
            val blob1Center: Offset
            val blob2Center: Offset
            val blob1Radius: Float
            val blob2Radius: Float

            when {
                weatherInfo.isStormy -> {
                    // Stormy: Fast, high-frequency chaotic motion
                    val angle = dynamicOffset * 0.08f
                    val driftX = sin(angle) * 200f + cos(angle * 1.5f) * 50f
                    val driftY = cos(angle * 0.9f) * 200f + sin(angle * 2.1f) * 60f
                    blob1Center = Offset(width * 0.35f + driftX, height * 0.35f + driftY - parallaxAuroraY)
                    blob2Center = Offset(width * 0.75f - driftY, height * 0.65f - driftX - parallaxAuroraY)
                    blob1Radius = width * (0.65f + sin(dynamicOffset * 0.05f) * 0.05f)
                    blob2Radius = width * (0.55f + cos(dynamicOffset * 0.06f) * 0.05f)
                }
                weatherInfo.isSnowing -> {
                    // Snowy: Gentle side-to-side sway, slow drift
                    val swayX1 = sin(dynamicOffset * 0.04f) * 80f
                    val swayY1 = cos(dynamicOffset * 0.02f) * 40f
                    val swayX2 = cos(dynamicOffset * 0.03f) * 60f
                    val swayY2 = sin(dynamicOffset * 0.02f) * 30f
                    blob1Center = Offset(width * 0.35f + swayX1, height * 0.3f + swayY1 - parallaxAuroraY)
                    blob2Center = Offset(width * 0.7f + swayX2, height * 0.6f + swayY2 - parallaxAuroraY)
                    blob1Radius = width * (0.75f + sin(dynamicOffset * 0.02f) * 0.03f)
                    blob2Radius = width * (0.65f + cos(dynamicOffset * 0.02f) * 0.03f)
                }
                weatherInfo.isRaining -> {
                    // Rainy: Steady diagonal drift down-left
                    val shiftX1 = ((dynamicOffset * 1.2f) % (width * 0.6f)) - (width * 0.3f)
                    val shiftY1 = ((dynamicOffset * 1.6f) % (height * 0.4f)) - (height * 0.2f)
                    val shiftX2 = -(((dynamicOffset * 1.0f) % (width * 0.5f)) - (width * 0.25f))
                    val shiftY2 = ((dynamicOffset * 1.3f) % (height * 0.3f)) - (height * 0.15f)
                    blob1Center = Offset(width * 0.35f + shiftX1, height * 0.35f + shiftY1 - parallaxAuroraY)
                    blob2Center = Offset(width * 0.75f + shiftX2, height * 0.65f + shiftY2 - parallaxAuroraY)
                    blob1Radius = width * 0.72f
                    blob2Radius = width * 0.62f
                }
                isCloudy -> {
                    // Cloudy: Heavy, very slow-rolling strictly horizontal mist bands
                    val shiftX1 = ((dynamicOffset * 0.6f) % (width * 0.5f)) - (width * 0.25f)
                    val shiftX2 = -(((dynamicOffset * 0.4f) % (width * 0.4f)) - (width * 0.2f))
                    blob1Center = Offset(width * 0.35f + shiftX1, height * 0.35f - parallaxAuroraY)
                    blob2Center = Offset(width * 0.75f + shiftX2, height * 0.65f - parallaxAuroraY)
                    blob1Radius = width * (0.8f + sin(dynamicOffset * 0.01f) * 0.02f)
                    blob2Radius = width * (0.7f + cos(dynamicOffset * 0.01f) * 0.02f)
                }
                else -> {
                    // Sunny/Clear: Serene circular or spiral breathing movement
                    val angle = dynamicOffset * 0.03f
                    val driftX = sin(angle) * 120f
                    val driftY = cos(angle) * 120f
                    blob1Center = Offset(width * 0.35f + driftX, height * 0.35f + driftY - parallaxAuroraY)
                    blob2Center = Offset(width * 0.75f - driftY, height * 0.65f + driftX - parallaxAuroraY)
                    blob1Radius = width * 0.7f
                    blob2Radius = width * 0.6f
                }
            }

            // Liquid Glass Motion Blur Trailing Pass
            val trailDirX = sin(dynamicOffset * 0.05f) * 40f
            val trailDirY = cos(dynamicOffset * 0.05f) * 40f
            val blob1TrailCenter = blob1Center - Offset(trailDirX, trailDirY)
            val blob2TrailCenter = blob2Center - Offset(trailDirX * 0.8f, trailDirY * 0.8f)

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(color2.copy(alpha = 0.22f), Color.Transparent),
                    center = blob1TrailCenter,
                    radius = blob1Radius * 1.15f
                ),
                center = blob1TrailCenter,
                radius = blob1Radius * 1.15f
            )

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(color3.copy(alpha = 0.18f), Color.Transparent),
                    center = blob2TrailCenter,
                    radius = blob2Radius * 1.15f
                ),
                center = blob2TrailCenter,
                radius = blob2Radius * 1.15f
            )

            // Primary glowing air-glow ellipses
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(color2.copy(alpha = 0.45f), Color.Transparent),
                    center = blob1Center,
                    radius = blob1Radius
                ),
                center = blob1Center,
                radius = blob1Radius
            )

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(color3.copy(alpha = 0.4f), Color.Transparent),
                    center = blob2Center,
                    radius = blob2Radius
                ),
                center = blob2Center,
                radius = blob2Radius
            )

            // WEATHER-SPECIFIC DECORATIVE ATMOSPHERIC MOVEMENT OVERLAYS
            when {
                weatherInfo.isStormy -> {
                    // Draw rapid horizontal wind gusts
                    val windLinesCount = 4
                    for (i in 0 until windLinesCount) {
                        val progress = ((dynamicOffset * 3f + i * 250f) % (width + 300f)) - 150f
                        val yPos = height * (0.2f + i * 0.15f)
                        drawLine(
                            color = Color(0xFF81D4FA).copy(alpha = 0.15f),
                            start = Offset(progress, yPos),
                            end = Offset(progress + 180f, yPos),
                            strokeWidth = 4f,
                            cap = StrokeCap.Round
                        )
                    }
                }
                weatherInfo.isRaining -> {
                    // Draw slanted rain wind lines sweeping down
                    val streakCount = 6
                    for (i in 0 until streakCount) {
                        val progress = ((dynamicOffset * 2.5f + i * 200f) % (width + height))
                        val startX = progress
                        val startY = -100f + (progress * 0.5f)
                        
                        // Diagonal wind streak
                        drawLine(
                            color = Color(0xFFB3E5FC).copy(alpha = 0.1f),
                            start = Offset(startX, startY),
                            end = Offset(startX - 120f, startY + 160f),
                            strokeWidth = 3f,
                            cap = StrokeCap.Round
                        )
                    }
                }
                weatherInfo.isSnowing -> {
                    // Draw glittering snow dust
                    val flakeCount = 8
                    for (i in 0 until flakeCount) {
                        val swayX = sin(dynamicOffset * 0.05f + i) * 30f
                        val yProgress = ((dynamicOffset * 0.8f + i * 150f) % (height + 100f)) - 50f
                        val xPos = (width * 0.1f + i * (width * 0.11f)) + swayX
                        
                        drawCircle(
                            color = Color.White.copy(alpha = 0.25f),
                            radius = 3f,
                            center = Offset(xPos, yProgress)
                        )
                    }
                }
                isCloudy -> {
                    // Draw very slow horizontal mist bands
                    val mistCount = 3
                    for (i in 0 until mistCount) {
                        val shift = ((dynamicOffset * 0.3f + i * 400f) % (width + 600f)) - 300f
                        val yPos = height * (0.4f + i * 0.12f)
                        
                        drawLine(
                            color = Color.White.copy(alpha = 0.06f),
                            start = Offset(shift, yPos),
                            end = Offset(shift + 400f, yPos),
                            strokeWidth = 24f,
                            cap = StrokeCap.Round
                        )
                    }
                }
                else -> {
                    // Sunny/Clear Sky: Heat/aurora waves rising gently at the top
                    val waveCount = 3
                    for (i in 0 until waveCount) {
                        wavePath.reset()
                        val yBase = height * (0.05f + i * 0.04f)
                        wavePath.moveTo(0f, yBase)
                        for (x in 0..10) {
                            val xPos = x * (width / 10f)
                            val yOffset = sin(dynamicOffset * 0.04f + x * 0.8f + i) * 15f
                            wavePath.lineTo(xPos, yBase + yOffset)
                        }
                        wavePath.lineTo(width, height * 0.5f)
                        wavePath.lineTo(0f, height * 0.5f)
                        wavePath.close()
                        
                        drawPath(
                            path = wavePath,
                            color = Color(0xFFFFE082).copy(alpha = 0.04f)
                        )
                    }
                }
            }
        }

        // 2. FOREGROUND: High-clarity, non-blurred weather representations with multi-layer Parallax Depth
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val dynamicOffset = driftOffsetState.value

            val parallaxSkyY = scrollOffsetProvider() * 0.20f
            val parallaxMountainsY = scrollOffsetProvider() * 0.35f
            val parallaxMiddleHillsY = scrollOffsetProvider() * 0.50f
            val parallaxForegroundHillsY = scrollOffsetProvider() * 0.65f

            // A. Sky Objects (Sun/Stars/Moon)
            if (weatherInfo.isDay) {
                // SUN (Adapts in opacity/halo size depending on weather!)
                val sunCenter = Offset(width * 0.82f, height * 0.18f - parallaxSkyY)
                val sunBaseRadius = width * 0.09f
                
                val sunColor = when {
                    weatherInfo.isStormy -> Color(0xFFFFF176)
                    weatherInfo.isRaining -> Color(0xFFFFF59D)
                    isCloudy -> Color(0xFFFFEE58)
                    else -> Color(0xFFFFD166)
                }
                val haloColor = when {
                    weatherInfo.isStormy -> Color(0xFFFFD54F)
                    weatherInfo.isRaining -> Color(0xFFFFE082)
                    isCloudy -> Color(0xFFFFCA28)
                    else -> Color(0xFFFFB703)
                }
                val coronaColor = when {
                    weatherInfo.isStormy -> Color(0xFFFFF59D)
                    weatherInfo.isRaining -> Color(0xFFFFF9C4)
                    isCloudy -> Color(0xFFFFF59D)
                    else -> Color(0xFFFB8500)
                }
                val sunOpacity = when {
                    weatherInfo.isStormy -> 0.05f
                    weatherInfo.isRaining -> 0.15f
                    isCloudy -> 0.45f
                    else -> 1.0f
                }

                if (sunOpacity > 0.01f) {
                    // Large outer radial corona
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(coronaColor.copy(alpha = 0.22f * sunPulse * sunOpacity), coronaColor.copy(alpha = 0.04f * sunOpacity), Color.Transparent),
                            center = sunCenter,
                            radius = sunBaseRadius * 3.4f
                        ),
                        center = sunCenter,
                        radius = sunBaseRadius * 3.4f
                    )

                    // Sun Halo
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(haloColor.copy(alpha = 0.5f * sunOpacity), haloColor.copy(alpha = 0.15f * sunOpacity), Color.Transparent),
                            center = sunCenter,
                            radius = sunBaseRadius * 1.9f
                        ),
                        center = sunCenter,
                        radius = sunBaseRadius * 1.9f
                    )

                    // Main Golden Sun Disc
                    drawCircle(
                        color = sunColor.copy(alpha = sunOpacity),
                        radius = sunBaseRadius * sunPulse,
                        center = sunCenter
                    )
                }
            } else {
                // NIGHT: Crescent Moon & Twinkling Stars
                // 1. Twinkling stars (15 stars mapped with static coordinates)
                val starCoordinates = listOf(
                    Offset(width * 0.12f, height * 0.08f - parallaxSkyY),
                    Offset(width * 0.28f, height * 0.14f - parallaxSkyY),
                    Offset(width * 0.42f, height * 0.06f - parallaxSkyY),
                    Offset(width * 0.55f, height * 0.18f - parallaxSkyY),
                    Offset(width * 0.72f, height * 0.09f - parallaxSkyY),
                    Offset(width * 0.88f, height * 0.12f - parallaxSkyY),
                    Offset(width * 0.15f, height * 0.24f - parallaxSkyY),
                    Offset(width * 0.38f, height * 0.28f - parallaxSkyY),
                    Offset(width * 0.64f, height * 0.22f - parallaxSkyY),
                    Offset(width * 0.82f, height * 0.27f - parallaxSkyY),
                    Offset(width * 0.06f, height * 0.18f - parallaxSkyY),
                    Offset(width * 0.94f, height * 0.21f - parallaxSkyY),
                    Offset(width * 0.50f, height * 0.10f - parallaxSkyY),
                    Offset(width * 0.33f, height * 0.05f - parallaxSkyY),
                    Offset(width * 0.68f, height * 0.04f - parallaxSkyY)
                )

                starCoordinates.forEachIndexed { i, coord ->
                    val starPulse = (sin(dynamicOffset * 0.12f + i * 1.7f) + 1.0f) / 2.0f
                    drawCircle(
                        color = Color.White.copy(alpha = (0.2f + 0.8f * starPulse)),
                        radius = (1.5f + 2.0f * (if (i % 3 == 0) 1f else 0.5f)),
                        center = coord
                    )
                }

                // 2. Crescent Moon (Silver glowing outer moon, then subtracted with sky offset)
                val moonCenter = Offset(width * 0.80f, height * 0.15f - parallaxSkyY)
                val moonRadius = width * 0.08f

                // Moon glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFFE3F2FD).copy(alpha = 0.25f), Color.Transparent),
                        center = moonCenter,
                        radius = moonRadius * 2.2f
                    ),
                    center = moonCenter,
                    radius = moonRadius * 2.2f
                )

                // Silver Moon Crescent Path
                crescentPath.reset()
                crescentPath.arcTo(
                    rect = Rect(Offset(moonCenter.x - moonRadius, moonCenter.y - moonRadius), Size(moonRadius * 2f, moonRadius * 2f)),
                    startAngleDegrees = -70f,
                    sweepAngleDegrees = 160f,
                    forceMoveTo = true
                )
                crescentPath.arcTo(
                    rect = Rect(Offset(moonCenter.x - moonRadius * 0.6f, moonCenter.y - moonRadius * 0.9f), Size(moonRadius * 1.8f, moonRadius * 1.8f)),
                    startAngleDegrees = 90f,
                    sweepAngleDegrees = -160f,
                    forceMoveTo = false
                )
                crescentPath.close()

                drawPath(
                    path = crescentPath,
                    brush = Brush.linearGradient(
                        colors = listOf(Color(0xFFECEFF1), Color(0xFF90A4AE)),
                        start = Offset(moonCenter.x - moonRadius, moonCenter.y - moonRadius),
                        end = Offset(moonCenter.x + moonRadius, moonCenter.y + moonRadius)
                    )
                )
            }

            // B. Distant Mountain Range Path
            mPath.reset()
            val mBaseY = height * 0.76f - parallaxMountainsY
            mPath.moveTo(0f, height)
            mPath.lineTo(0f, mBaseY)
            mPath.lineTo(width * 0.18f, mBaseY - height * 0.05f)
            mPath.lineTo(width * 0.38f, mBaseY + height * 0.02f)
            mPath.lineTo(width * 0.62f, mBaseY - height * 0.08f)
            mPath.lineTo(width * 0.82f, mBaseY + height * 0.01f)
            mPath.lineTo(width * 0.94f, mBaseY - height * 0.03f)
            mPath.lineTo(width, mBaseY + height * 0.03f)
            mPath.lineTo(width, height)
            mPath.close()

            val mColor = when {
                weatherInfo.isStormy -> Color(0xFF131124).copy(alpha = 0.8f)
                weatherInfo.isRaining -> Color(0xFF37474F).copy(alpha = 0.7f)
                weatherInfo.isSnowing -> Color(0xFFCFD8DC).copy(alpha = 0.85f)
                isCloudy -> Color(0xFF546E7A).copy(alpha = 0.6f)
                !weatherInfo.isDay -> Color(0xFF0C1424).copy(alpha = 0.85f)
                else -> Color(0xFF78909C).copy(alpha = 0.45f) // Sunny Clear Day
            }
            drawPath(mPath, mColor)

            // C. Middle Hills
            h1Path.reset()
            val h1BaseY = height * 0.85f - parallaxMiddleHillsY
            h1Path.moveTo(0f, height)
            h1Path.lineTo(0f, h1BaseY)
            h1Path.quadraticTo(width * 0.3f, h1BaseY - height * 0.04f, width * 0.65f, h1BaseY + height * 0.01f)
            h1Path.quadraticTo(width * 0.85f, h1BaseY + height * 0.03f, width, h1BaseY - height * 0.02f)
            h1Path.lineTo(width, height)
            h1Path.close()

            val h1Color = when {
                weatherInfo.isStormy -> Color(0xFF0A0914)
                weatherInfo.isRaining -> Color(0xFF263238)
                weatherInfo.isSnowing -> Color(0xFFECEFF1)
                isCloudy -> Color(0xFF37474F)
                !weatherInfo.isDay -> Color(0xFF070B14)
                else -> Color(0xFF2E7D32).copy(alpha = 0.75f) // Clear Sunny Day Green Slopes
            }
            drawPath(h1Path, h1Color)

            // D. Foreground Hills (Slightly darker, overlapping closely)
            h2Path.reset()
            val h2BaseY = height * 0.92f - parallaxForegroundHillsY
            h2Path.moveTo(0f, height)
            h2Path.lineTo(0f, h2BaseY)
            h2Path.quadraticTo(width * 0.5f, h2BaseY - height * 0.03f, width, h2BaseY + height * 0.02f)
            h2Path.lineTo(width, height)
            h2Path.close()

            val h2Color = when {
                weatherInfo.isStormy -> Color(0xFF040408)
                weatherInfo.isRaining -> Color(0xFF1C2321)
                weatherInfo.isSnowing -> Color(0xFFE0E0E0)
                isCloudy -> Color(0xFF212121)
                !weatherInfo.isDay -> Color(0xFF030509)
                else -> Color(0xFF1B5E20).copy(alpha = 0.85f) // Foreground deep forest green
            }
            drawPath(h2Path, h2Color)

            // E. evergreen pine trees (Placed beautifully in perspective scaling!)
            val treeLeafColor = when {
                weatherInfo.isStormy -> Color(0xFF0C091A)
                weatherInfo.isRaining -> Color(0xFF1F2D2A)
                weatherInfo.isSnowing -> Color(0xFFB0BEC5)
                isCloudy -> Color(0xFF2C3E50)
                !weatherInfo.isDay -> Color(0xFF081408)
                else -> Color(0xFF1B4332) // Sunny Day deep green
            }
            val treeTrunkColor = when {
                weatherInfo.isStormy -> Color(0xFF05030A)
                weatherInfo.isRaining -> Color(0xFF111716)
                weatherInfo.isSnowing -> Color(0xFF455A64)
                isCloudy -> Color(0xFF1A252F)
                !weatherInfo.isDay -> Color(0xFF030803)
                else -> Color(0xFF4E342E) // Sunny Day brown
            }

            // Draw multiple scale pine trees in landscape
            val treeLocations = listOf(
                Triple(width * 0.15f, height * 0.84f, 0.75f),
                Triple(width * 0.28f, height * 0.87f, 1.15f),
                Triple(width * 0.48f, height * 0.89f, 0.90f),
                Triple(width * 0.72f, height * 0.88f, 1.05f),
                Triple(width * 0.88f, height * 0.86f, 0.80f)
            )

            for (tree in treeLocations) {
                val tx = tree.first
                val ty = tree.second - parallaxForegroundHillsY
                val tScale = tree.third
                
                val treeHeight = 70f * tScale
                val trunkHeight = 15f * tScale
                val trunkWidth = 6f * tScale
                
                // 1. Draw trunk
                drawRect(
                    color = treeTrunkColor,
                    topLeft = Offset(tx - trunkWidth / 2f, ty - trunkHeight),
                    size = androidx.compose.ui.geometry.Size(trunkWidth, trunkHeight)
                )
                
                // 2. Draw 3 layers of evergreen triangles
                val leafBaseY = ty - trunkHeight
                val layerHeight = 22f * tScale
                val layerWidth = 40f * tScale
                
                for (i in 0 until 3) {
                    val y = leafBaseY - i * (layerHeight * 0.62f)
                    pPath.reset()
                    pPath.moveTo(tx, y - layerHeight) // tip
                    pPath.lineTo(tx - (layerWidth * (1f - i * 0.15f)) / 2f, y) // bottom left
                    pPath.lineTo(tx + (layerWidth * (1f - i * 0.15f)) / 2f, y) // bottom right
                    pPath.close()
                    drawPath(pPath, treeLeafColor)

                    // Draw snow caps on pine trees in snow mode!
                    if (weatherInfo.isSnowing) {
                        snowCapPath.reset()
                        snowCapPath.moveTo(tx, y - layerHeight) // tip
                        snowCapPath.lineTo(tx - (layerWidth * (1f - i * 0.15f)) * 0.25f, y - layerHeight * 0.5f)
                        snowCapPath.lineTo(tx + (layerWidth * (1f - i * 0.15f)) * 0.25f, y - layerHeight * 0.5f)
                        snowCapPath.close()
                        drawPath(snowCapPath, Color.White)
                    }
                }
            }

            // F. Drifting clouds (over the mountain range but behind the foreground card)
            if (isCloudy || weatherInfo.isRaining || weatherInfo.isStormy) {
                val cloudColor = if (weatherInfo.isStormy) {
                    Color(0xFF2C2E3E).copy(alpha = 0.25f)
                } else {
                    Color.White.copy(alpha = 0.18f)
                }
                
                val cloud1X = ((dynamicOffset * 18f) % (width + 600f)) - 300f
                val cloud1Y = height * 0.38f - parallaxMountainsY
                
                // Liquid Motion Blur Trail Pass
                drawRoundRect(
                    color = cloudColor.copy(alpha = cloudColor.alpha * 0.5f),
                    topLeft = Offset(cloud1X - 35f, cloud1Y),
                    size = androidx.compose.ui.geometry.Size(390f, 100f),
                    cornerRadius = CornerRadius(50f, 50f)
                )

                drawRoundRect(
                    color = cloudColor,
                    topLeft = Offset(cloud1X, cloud1Y),
                    size = androidx.compose.ui.geometry.Size(360f, 100f),
                    cornerRadius = CornerRadius(50f, 50f)
                )
                drawCircle(
                    color = cloudColor,
                    center = Offset(cloud1X + 120f, cloud1Y - 15f),
                    radius = 70f
                )
                drawCircle(
                    color = cloudColor,
                    center = Offset(cloud1X + 220f, cloud1Y - 30f),
                    radius = 85f
                )
            }

            // G. Stormy lightning flashes and severe thunderclouds
            if (weatherInfo.isStormy) {
                val tick = (dynamicOffset * 22f).toInt()
                val isLightningActive = tick % 43 == 0 || tick % 97 == 0
                
                if (isLightningActive) {
                    drawRect(color = Color(0x7FCEE6F2)) // lightning flash

                    boltPath.reset()
                    val startX = width * 0.45f + sin(dynamicOffset) * 120f
                    val startY = height * 0.12f
                    
                    boltPath.moveTo(startX, startY)
                    boltPath.lineTo(startX - 50f, startY + height * 0.15f)
                    boltPath.lineTo(startX + 20f, startY + height * 0.13f)
                    boltPath.lineTo(startX - 80f, startY + height * 0.35f)
                    boltPath.lineTo(startX - 10f, startY + height * 0.33f)
                    boltPath.lineTo(startX - 100f, startY + height * 0.58f)
                    
                    drawPath(
                        path = boltPath,
                        color = Color(0xFFFFF9C4),
                        style = Stroke(width = 5f, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
                    )
                    drawPath(
                        path = boltPath,
                        color = Color.White,
                        style = Stroke(width = 2.5f, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
                    )
                }
            }

            // Background canvas rendering completed
        }
    }
}


// --- Weather Particle & Atmospheric Condition Physics Canvas Simulator ---
@Composable
fun WeatherOverlayParticles(
    weatherInfo: WeatherInfo,
    scrollOffsetProvider: () -> Float = { 0f }
) {
    val infiniteTransition = rememberInfiniteTransition(label = "WeatherAnimations")
    val particleBoltPath = remember { Path() }

    // Main continuous animation loop for particles and cloud drift
    val animProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ParticlesProgress"
    )

    // Lightning pulse timer for storm conditions
    val lightningPulse by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 5000
                0.0f at 0
                0.0f at 3200
                0.9f at 3280
                0.1f at 3350
                0.8f at 3400
                0.0f at 3500
                0.0f at 5000
            },
            repeatMode = RepeatMode.Restart
        ),
        label = "LightningPulse"
    )

    // Setup static random seeds for consistent particle & cloud position distributions
    val particleCount = 50
    val seeds = remember { List(particleCount) { RandomSeed(Math.random().toFloat(), Math.random().toFloat(), (12..32).random().toFloat()) } }

    // Cloud puff seeds for overcast/cloudy dynamic animation
    val cloudCount = 6
    val cloudSeeds = remember {
        List(cloudCount) { index ->
            CloudSeed(
                initialX = (index * 0.22f) % 1f,
                yRatio = 0.08f + (index % 3) * 0.07f,
                scale = 0.8f + (index % 4) * 0.35f,
                speed = 0.12f + (index % 3) * 0.08f,
                alpha = 0.18f + (index % 3) * 0.08f
            )
        }
    }

    // Star seeds for clear night sky
    val starCount = 35
    val starSeeds = remember { List(starCount) { RandomSeed(Math.random().toFloat(), Math.random().toFloat() * 0.6f, (2..6).random().toFloat()) } }

    Canvas(modifier = Modifier.fillMaxSize().testTag("weather_particle_canvas")) {
        val width = size.width
        val height = size.height

        val particleParallaxY = scrollOffsetProvider() * 0.70f
        val cloudParallaxY = scrollOffsetProvider() * 0.38f
        val fogParallaxY = scrollOffsetProvider() * 0.45f

        // 1. SWIRLING / DRIFTING CLOUDS (Overcast / Cloudy / Stormy) WITH LIQUID GLASS MOTION BLUR
        if (weatherInfo.isCloudy || weatherInfo.isStormy) {
            for (cloud in cloudSeeds) {
                val cloudX = ((cloud.initialX + animProgress * cloud.speed) % 1.2f - 0.1f) * width
                val cloudY = cloud.yRatio * height - cloudParallaxY
                val baseRadius = 60f * cloud.scale

                val cloudColor = if (weatherInfo.isStormy) {
                    Color(0xFF2C2A4A).copy(alpha = cloud.alpha * 1.5f)
                } else {
                    Color.White.copy(alpha = cloud.alpha)
                }

                // Motion Blur Trail Cloud Pass (Liquid speed streak)
                val trailX = cloudX - cloud.speed * 45f
                drawCircle(color = cloudColor.copy(alpha = cloudColor.alpha * 0.35f), radius = baseRadius * 1.15f, center = Offset(trailX, cloudY))
                drawCircle(color = cloudColor.copy(alpha = cloudColor.alpha * 0.25f), radius = baseRadius * 0.85f, center = Offset(trailX - baseRadius * 0.7f, cloudY + baseRadius * 0.15f))
                drawCircle(color = cloudColor.copy(alpha = cloudColor.alpha * 0.28f), radius = baseRadius * 0.95f, center = Offset(trailX + baseRadius * 0.7f, cloudY + baseRadius * 0.1f))

                // Main organic cloud puff composite shape (overlapping rounded lobes)
                drawCircle(color = cloudColor, radius = baseRadius, center = Offset(cloudX, cloudY))
                drawCircle(color = cloudColor, radius = baseRadius * 0.75f, center = Offset(cloudX - baseRadius * 0.7f, cloudY + baseRadius * 0.15f))
                drawCircle(color = cloudColor, radius = baseRadius * 0.82f, center = Offset(cloudX + baseRadius * 0.7f, cloudY + baseRadius * 0.1f))
                drawCircle(color = cloudColor, radius = baseRadius * 0.6f, center = Offset(cloudX + baseRadius * 1.1f, cloudY + baseRadius * 0.2f))
            }
        }

        // 2. DRIFTING FOG BANDS (Foggy / Misty / Hazy)
        if (weatherInfo.isFoggy) {
            for (i in 0..3) {
                val fogY = (0.25f + i * 0.18f) * height - fogParallaxY
                val offsetX = sin((animProgress * Math.PI * 2 + i).toFloat()) * width * 0.08f
                val fogAlpha = 0.12f + 0.05f * sin((animProgress * Math.PI * 4 + i * 2).toFloat())

                drawRect(
                    color = Color.White.copy(alpha = fogAlpha),
                    topLeft = Offset(-width * 0.2f + offsetX, fogY),
                    size = Size(width * 1.4f, 90f)
                )
            }
        }

        // 3. THUNDERSTORM LIGHTNING FLASH & BOLT (Stormy)
        if (weatherInfo.isStormy && lightningPulse > 0.05f) {
            // Full background ambient flash
            drawRect(
                color = Color(0xFFD8B4FE).copy(alpha = lightningPulse * 0.35f)
            )

            // Draw stylized lightning bolt with motion blur glow aura
            if (lightningPulse > 0.4f) {
                particleBoltPath.reset()
                val startX = width * 0.55f
                particleBoltPath.moveTo(startX, 0f)
                particleBoltPath.lineTo(startX - 30f, height * 0.15f)
                particleBoltPath.lineTo(startX + 20f, height * 0.18f)
                particleBoltPath.lineTo(startX - 40f, height * 0.35f)
                particleBoltPath.lineTo(startX + 10f, height * 0.38f)
                particleBoltPath.lineTo(startX - 50f, height * 0.55f)

                drawPath(
                    path = particleBoltPath,
                    color = Color(0xFFC084FC).copy(alpha = lightningPulse * 0.5f),
                    style = Stroke(width = 24f, cap = StrokeCap.Round)
                )
                drawPath(
                    path = particleBoltPath,
                    color = Color.White.copy(alpha = lightningPulse),
                    style = Stroke(width = 6f, cap = StrokeCap.Round)
                )
                drawPath(
                    path = particleBoltPath,
                    color = Color(0xFFA855F7).copy(alpha = lightningPulse * 0.8f),
                    style = Stroke(width = 14f, cap = StrokeCap.Round)
                )
            }
        }

        // 4. CLEAR SKY DAY SUN RAYS / CLEAR NIGHT STARRY TWINKLE
        if (weatherInfo.isClear) {
            if (weatherInfo.isDay) {
                // Sun dust golden bokeh particles with motion-blur speed trails
                for (seed in starSeeds) {
                    val px = seed.x * width
                    val py = ((seed.y - animProgress * 0.3f + 1f) % 1f) * height - particleParallaxY * 0.7f
                    val pAlpha = (0.2f + 0.3f * sin(animProgress * Math.PI * 2 + seed.x * 10).toFloat()).coerceIn(0f, 0.6f)

                    // Vertical speed trail oval for liquid motion blur
                    drawOval(
                        color = Color(0xFFFFE082).copy(alpha = pAlpha),
                        topLeft = Offset(px - seed.size, py),
                        size = Size(seed.size * 2f, seed.size * 3.5f)
                    )
                }
            } else {
                // Twinkling stars with subtle parallax
                for (seed in starSeeds) {
                    val px = seed.x * width
                    val py = seed.y * height - particleParallaxY * 0.3f
                    val starTwinkle = (0.3f + 0.6f * sin((animProgress * Math.PI * 4 + seed.x * 20).toFloat())).coerceIn(0.1f, 0.9f)

                    drawCircle(
                        color = Color.White.copy(alpha = starTwinkle),
                        radius = seed.size * 0.8f,
                        center = Offset(px, py)
                    )
                }
            }
        }

        // 5. RAIN & SNOW FALLING PARTICLES (Raining / Snowing / Stormy) WITH MOTION BLUR STREAKS
        if (weatherInfo.isRaining || weatherInfo.isSnowing || weatherInfo.isStormy) {
            for (seed in seeds) {
                val startX = seed.x * width
                val speedMultiplier = if (weatherInfo.isStormy) 2.2f else 1.2f
                val currentY = ((seed.y + animProgress * speedMultiplier) % 1f) * height - particleParallaxY
                val length = seed.size

                if (weatherInfo.isRaining || weatherInfo.isStormy) {
                    val dropColor = if (weatherInfo.isStormy) Color(0xFF93C5FD) else RainCyan
                    val blurLength = length * (if (weatherInfo.isStormy) 2.2f else 1.6f)
                    val dropEnd = Offset(startX - blurLength * 0.35f, currentY + blurLength)

                    // Fast GPU line draw with primary color and alpha gradient representation
                    drawLine(
                        color = dropColor.copy(alpha = 0.75f),
                        start = Offset(startX, currentY),
                        end = dropEnd,
                        strokeWidth = if (weatherInfo.isStormy) 4.5f else 3.2f,
                        cap = StrokeCap.Round
                    )

                    // Secondary soft motion glow pass
                    drawLine(
                        color = dropColor.copy(alpha = 0.20f),
                        start = Offset(startX, currentY),
                        end = dropEnd,
                        strokeWidth = if (weatherInfo.isStormy) 8f else 6f,
                        cap = StrokeCap.Round
                    )

                    // Ground/Card splash ripple when near bottom
                    if (currentY > height * 0.85f && seed.x < 0.8f) {
                        val splashProgress = ((currentY - height * 0.85f) / (height * 0.15f)).coerceIn(0f, 1f)
                        drawCircle(
                            color = dropColor.copy(alpha = 0.3f * (1f - splashProgress)),
                            radius = 14f * splashProgress,
                            center = Offset(startX, height * 0.92f),
                            style = Stroke(width = 2f)
                        )
                    }
                } else if (weatherInfo.isSnowing) {
                    // Fluffy white snow flakes with motion blur trailing ovals
                    val swayX = sin(animProgress * 2 * Math.PI.toFloat() + seed.x * 10) * 18f
                    val snowCenter = Offset(startX + swayX, currentY)
                    val snowRadius = length / 4.5f

                    // Motion blur trailing oval
                    drawOval(
                        color = Color.White.copy(alpha = 0.35f),
                        topLeft = Offset(snowCenter.x - snowRadius, snowCenter.y - snowRadius * 2.8f),
                        size = Size(snowRadius * 2f, snowRadius * 3.8f)
                    )

                    // Main snowflake core
                    drawCircle(
                        color = Color.White.copy(alpha = 0.85f),
                        radius = snowRadius,
                        center = snowCenter
                    )
                }
            }
        }
    }
}

data class RandomSeed(val x: Float, val y: Float, val size: Float)
data class CloudSeed(val initialX: Float, val yRatio: Float, val scale: Float, val speed: Float, val alpha: Float)

// --- Frosted Blur Container (Premium Real-time Blur Effect with Hover Scale & Blur Enhancement) ---
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    borderStrokeWidth: Float = 1.2f,
    glowColor: Color = Color.Transparent,
    key: Any? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val isDarkTheme = MaterialTheme.colorScheme.onBackground == Color.White

    // A. Spring Entrance Animation when first created or key changes (Framer Motion style)
    var isComposed by remember { mutableStateOf(false) }
    LaunchedEffect(key) {
        isComposed = false
        kotlinx.coroutines.delay(20)
        isComposed = true
    }

    // B. Interactive Hover & Touch Pointer Detection
    val interactionSource = remember { MutableInteractionSource() }
    val isHoveredState by interactionSource.collectIsHoveredAsState()
    val isPressedState by interactionSource.collectIsPressedAsState()

    val isHovered = isHoveredState || isPressedState

    // C. Animated Scale Transform (Slight lift / expansion on hover: 1.0 -> 1.025x)
    val baseScale = if (isComposed) 1f else 0.96f
    val targetScale = if (isHovered) baseScale * 1.025f else baseScale
    val animatedScale by animateFloatAsState(
        targetValue = targetScale,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "BlurScaleEntry"
    )

    val animatedAlpha by animateFloatAsState(
        targetValue = if (isComposed) 1f else 0f,
        animationSpec = tween(400),
        label = "BlurAlphaEntry"
    )

    // D. Animated Glass Border Highlight
    val baseBorderAlpha = if (isDarkTheme) 0.22f else 0.45f
    val hoverBorderAlpha = if (isDarkTheme) 0.55f else 0.75f
    val animatedBorderAlpha by animateFloatAsState(
        targetValue = if (isHovered) hoverBorderAlpha else baseBorderAlpha,
        animationSpec = tween(250),
        label = "GlassBorderAlpha"
    )

    Box(
        modifier = modifier
            .hoverable(interactionSource)
            .graphicsLayer(
                scaleX = animatedScale,
                scaleY = animatedScale,
                alpha = animatedAlpha
            )
            .clip(RoundedCornerShape(24.dp))
    ) {
        // 1. High-performance Frosted Backing Layer
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    color = if (isDarkTheme) {
                        Color.Black.copy(alpha = if (isHovered) 0.40f else 0.28f)
                    } else {
                        Color.White.copy(alpha = if (isHovered) 0.40f else 0.28f)
                    }
                )
        )

        // 2. High-contrast frosted translucent overlay tinting & border highlight
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    color = if (isDarkTheme) Color(0x35101010) else Color(0x55FAFAFA)
                )
                .border(
                    width = if (isHovered) (borderStrokeWidth * 1.3f).dp else borderStrokeWidth.dp,
                    brush = Brush.linearGradient(
                        colors = if (isDarkTheme) {
                            listOf(
                                Color.White.copy(alpha = animatedBorderAlpha),
                                if (glowColor != Color.Transparent && isHovered) glowColor.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.08f)
                            )
                        } else {
                            listOf(
                                Color.White.copy(alpha = animatedBorderAlpha),
                                if (glowColor != Color.Transparent && isHovered) glowColor.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.18f)
                            )
                        }
                    ),
                    shape = RoundedCornerShape(24.dp)
                )
        )

        // 3. Content layout container
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onBackground) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    content = content
                )
            }
        }
    }
}

// --- Glassmorphic Top Header & Expandable Global Search Panel ---
@Composable
fun GlassmorphicTopBar(
    searchQuery: String,
    searchResults: List<GeocodingResult>,
    isSearching: Boolean,
    unreadAlertsCount: Int,
    recentSearches: List<String>,
    isDarkMode: Boolean,
    currentLanguage: String,
    onLanguageChange: (String) -> Unit,
    onToggleTheme: () -> Unit,
    onQueryChange: (String) -> Unit,
    onSuggestionClick: (GeocodingResult) -> Unit,
    onSearchHistoryClick: (String) -> Unit,
    onClearHistory: () -> Unit,
    onRequestLocation: () -> Unit
) {
    var searchActive by remember { mutableStateOf(false) }
    val isDark = MaterialTheme.colorScheme.onBackground == Color.White

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(MaterialTheme.colorScheme.background.copy(alpha = 0.9f), Color.Transparent)
                )
            )
            .padding(16.dp)
            .statusBarsPadding()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Glass Search Bar
            TextField(
                value = searchQuery,
                onValueChange = {
                    onQueryChange(it)
                    searchActive = it.isNotEmpty()
                },
                placeholder = { Text(com.example.ui.utils.WeatherLocalization.get("search_placeholder", currentLanguage), color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f), fontSize = 14.sp) },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = NeonCyan) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = {
                            onQueryChange("")
                            searchActive = false
                        }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Clear search", tint = MaterialTheme.colorScheme.onBackground)
                        }
                    } else {
                        IconButton(onClick = onRequestLocation) {
                            Icon(imageVector = Icons.Default.MyLocation, contentDescription = "My Location", tint = NeonCyan)
                        }
                    }
                },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = if (isDark) Color.White.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.6f),
                    unfocusedContainerColor = if (isDark) Color.White.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.4f),
                    focusedIndicatorColor = NeonCyan,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = MaterialTheme.colorScheme.onBackground,
                    unfocusedTextColor = MaterialTheme.colorScheme.onBackground
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .testTag("location_search_input")
            )

            if (unreadAlertsCount > 0) {
                Spacer(modifier = Modifier.width(10.dp))
                // Animated pulsing alert badge for extreme weather push warning highlights
                val infiniteTransition = rememberInfiniteTransition(label = "BellPulse")
                val pulseScale by infiniteTransition.animateFloat(
                    initialValue = 1f,
                    targetValue = 1.25f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1000, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "PulseScale"
                )

                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .scale(pulseScale)
                        .background(ExtremeRed.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                        .border(1.dp, ExtremeRed, RoundedCornerShape(12.dp))
                        .clickable { /* Tapping focuses alert banner */ },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Active Alerts",
                        tint = ExtremeRed,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))
            
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(
                        if (isDark) Color.White.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.45f), 
                        RoundedCornerShape(12.dp)
                    )
                    .border(
                        1.dp, 
                        if (isDark) Color.White.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.25f), 
                        RoundedCornerShape(12.dp)
                    )
                    .clickable { onToggleTheme() }
                    .testTag("theme_toggle_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isDarkMode) Icons.Default.WbSunny else Icons.Default.NightsStay,
                    contentDescription = "Toggle Theme Mode",
                    tint = if (isDarkMode) SunlightYellow else SkyBlue,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Box(
                modifier = Modifier
                    .height(44.dp)
                    .background(
                        if (isDark) Color.White.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.45f), 
                        RoundedCornerShape(12.dp)
                    )
                    .border(
                        1.dp, 
                        if (isDark) Color.White.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.25f), 
                        RoundedCornerShape(12.dp)
                    )
                    .clickable {
                        val nextLang = when (currentLanguage) {
                            "en" -> "uz"
                            "uz" -> "ru"
                            else -> "en"
                        }
                        onLanguageChange(nextLang)
                    }
                    .testTag("language_toggle_button")
                    .padding(horizontal = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Language Selector",
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = currentLanguage.uppercase(java.util.Locale.ROOT),
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Dropdown suggested coordinates/results list (Overlay)
        AnimatedVisibility(
            visible = searchActive && (searchResults.isNotEmpty() || isSearching || recentSearches.isNotEmpty()),
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
                    .background(
                        brush = Brush.linearGradient(
                            listOf(Color(0xFF1E293B).copy(alpha = 0.95f), Color(0xFF0F172A).copy(alpha = 0.95f))
                        ),
                        shape = RoundedCornerShape(20.dp)
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                if (isSearching) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = NeonCyan, modifier = Modifier.size(24.dp))
                    }
                } else if (searchResults.isNotEmpty()) {
                    Text(
                        text = "Global Geolocation Matches",
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    searchResults.forEach { result ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSuggestionClick(result)
                                    searchActive = false
                                }
                                .padding(vertical = 10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "Loc",
                                tint = SkyBlue,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = result.name,
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                val subRegion = listOfNotNull(
                                    result.admin4, // Village
                                    result.admin3, // City
                                    result.admin1, // District
                                    result.country // Country
                                ).distinct().joinToString(", ")

                                if (subRegion.isNotEmpty()) {
                                    Text(
                                        text = subRegion,
                                        color = Color.White.copy(alpha = 0.6f),
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                        Divider(color = Color.White.copy(alpha = 0.05f))
                    }
                } else {
                    // Show Recent Search History if query empty
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Recent Coordinates Searches",
                            color = Color.White.copy(alpha = 0.5f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Clear",
                            color = NeonPurple,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { onClearHistory() }
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    recentSearches.forEach { historyQuery ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSearchHistoryClick(historyQuery)
                                }
                                .padding(vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "History",
                                tint = Color.White.copy(alpha = 0.4f),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(historyQuery, color = Color.White, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

// --- Dynamic Scaling Helper for Bell animation ---
fun Modifier.scale(scale: Float) = this.graphicsLayer(scaleX = scale, scaleY = scale)

// --- Primary Successful UI Dashboard Modules ---
@Composable
fun SuccessDashboardContent(
    state: WeatherUiState.Success,
    savedLocations: List<SavedLocation>,
    viewModel: WeatherViewModel,
    currentLanguage: String,
    lazyListState: LazyListState = rememberLazyListState()
) {
    val context = LocalContext.current
    val current = state.weather.current
    val weatherInfo = remember(current) {
        val code = current?.weatherCode ?: 0
        val isDay = current?.isDay != 0
        WeatherUtils.getWeatherInfo(code, isDay)
    }

    // Refresh animation trigger
    var isRefreshing by remember { mutableStateOf(false) }

    LazyColumn(
        state = lazyListState,
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Active Location Details (District -> City -> Country hierarchy)
        item {
            LocationHierarchyHeader(
                location = state.location,
                isFavorite = state.location.isFavorite,
                isRefreshing = isRefreshing,
                onToggleFavorite = { viewModel.toggleFavorite(state.location) },
                onRefresh = {
                    isRefreshing = true
                    viewModel.refreshCurrentWeather()
                    isRefreshing = false
                }
            )
        }

        // Automatic Weather Refresh Countdown & Last Updated Status Bar
        item {
            AutoRefreshStatusBar(
                viewModel = viewModel,
                currentLanguage = currentLanguage,
                onRefresh = {
                    viewModel.refreshCurrentWeather()
                }
            )
        }

        // Pulses Active Extreme Weather Alerts Banner if present
        if (state.alerts.isNotEmpty()) {
            item {
                ActiveAlertsCard(alerts = state.alerts, currentLanguage = currentLanguage, onMarkRead = { viewModel.markAllAlertsAsRead() })
            }
        }

        // Glowing Glass Main Weather Readout
        item {
            MainWeatherGlassCard(state = state, weatherInfo = weatherInfo, currentLanguage = currentLanguage, key = state.location.name)
        }

        // Quick Selector: Horizontal swipe list of other saved cities
        if (savedLocations.size > 1) {
            item {
                QuickLocationSelector(
                    savedLocations = savedLocations,
                    activeLocation = state.location,
                    onSelectLocation = { viewModel.selectLocation(it) },
                    onDeleteLocation = { viewModel.deleteLocation(it) }
                )
            }
        }

        // Hourly Forecast Bar
        item {
            HourlyForecastCard(weather = state.weather, currentLanguage = currentLanguage, key = state.location.name)
        }

        // 7-Day Symmetrical Range Slider Forecast Card
        item {
            SevenDayForecastCard(weather = state.weather, currentLanguage = currentLanguage, key = state.location.name)
        }

        // Weather Condition Probabilities Card for All Weather Types
        item {
            WeatherProbabilitiesCard(weather = state.weather, currentLanguage = currentLanguage, key = state.location.name)
        }

        // Dynamic Wind Speed & Compass Direction Heading Indicator Card
        item {
            WindCompassCard(weather = state.weather, currentLanguage = currentLanguage, key = state.location.name)
        }

        // UV Radiation Warning & Index Card
        item {
            UvRadiationCard(weather = state.weather, currentLanguage = currentLanguage, key = state.location.name)
        }

        // Interactive Radar Map Screen module
        item {
            WeatherRadarMapCard(location = state.location, viewModel = viewModel, currentLanguage = currentLanguage, key = state.location.name)
        }

        // Localized Warning Warning Simulation Console
        item {
            SimulationAlertsConsoleCard(viewModel = viewModel, currentLanguage = currentLanguage, key = state.location.name)
        }

        // Margin spacer
        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

// --- Header Component showing precise regional boundaries ---
@Composable
fun LocationHierarchyHeader(
    location: SavedLocation,
    isFavorite: Boolean,
    isRefreshing: Boolean,
    onToggleFavorite: () -> Unit,
    onRefresh: () -> Unit
) {
    val isDarkTheme = MaterialTheme.colorScheme.onBackground == Color.White
    val contentColor = LocalContentColor.current

    val btnBgColor = if (isDarkTheme) Color.White.copy(alpha = 0.06f) else Color.Black.copy(alpha = 0.05f)
    val btnBorderColor = if (isDarkTheme) Color.White.copy(alpha = 0.12f) else Color.Black.copy(alpha = 0.10f)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            // Village/Locality level
            if (!location.admin4.isNullOrBlank()) {
                Text(
                    text = location.admin4,
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    letterSpacing = 1.sp
                )
            }
            // Major city/Prefecture
            Text(
                text = location.name,
                color = contentColor,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 28.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            // State, District, and country hierarchy
            val adminHierarchy = listOfNotNull(
                location.admin3?.takeIf { it != location.name },
                location.admin1,
                location.country
            ).joinToString(", ")

            Text(
                text = adminHierarchy,
                color = contentColor.copy(alpha = 0.6f),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Row {
            // Favorite spring animation
            val favScale by animateFloatAsState(
                targetValue = if (isFavorite) 1.25f else 1.0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMedium
                ),
                label = "FavoritePulse"
            )

            // Favorite toggle
            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier
                    .background(btnBgColor, RoundedCornerShape(12.dp))
                    .border(1.dp, btnBorderColor, RoundedCornerShape(12.dp))
            ) {
                Icon(
                    imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (isFavorite) ExtremeRed else contentColor,
                    modifier = Modifier.scale(favScale)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Refresh rotation animation
            val rotationTransition = rememberInfiniteTransition(label = "RefreshRotation")
            val angle by rotationTransition.animateFloat(
                initialValue = 0f,
                targetValue = if (isRefreshing) 360f else 0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "RotationAngle"
            )

            IconButton(
                onClick = onRefresh,
                modifier = Modifier
                    .background(btnBgColor, RoundedCornerShape(12.dp))
                    .border(1.dp, btnBorderColor, RoundedCornerShape(12.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Sync,
                    contentDescription = "Sync",
                    tint = NeonCyan,
                    modifier = Modifier.rotate(angle)
                )
            }
        }
    }
}

// --- Pulsing Local Weather Warning Banner ---
@Composable
fun ActiveAlertsCard(alerts: List<AlertEntity>, currentLanguage: String, onMarkRead: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "AlertPulse")
    val alphaAnim by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "AlphaAnim"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.linearGradient(
                    listOf(ExtremeRed.copy(alpha = 0.25f), AlertOrange.copy(alpha = 0.15f))
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .border(
                width = 1.dp,
                color = ExtremeRed.copy(alpha = alphaAnim),
                shape = RoundedCornerShape(20.dp)
            )
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Severe warning active",
                    tint = ExtremeRed,
                    modifier = Modifier
                        .size(24.dp)
                        .scale(alphaAnim * 0.3f + 0.8f)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = when (currentLanguage) {
                        "uz" -> "MAHALLIY FAVQULODDA OB-HAVO AXBOROTI"
                        "ru" -> "БЮЛЛЕТЕНЬ ЭКСТРЕМАЛЬНОЙ ПОГОДЫ"
                        else -> "LOCAL EXTREME WEATHER BULLETIN"
                    },
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    letterSpacing = 1.sp
                )
            }

            Text(
                text = when (currentLanguage) {
                    "uz" -> "YOPISH"
                    "ru" -> "ЗАКРЫТЬ"
                    else -> "DISMISS"
                },
                color = NeonCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable { onMarkRead() }
                    .background(Color.White.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        alerts.forEachIndexed { idx, alert ->
            Column(modifier = Modifier.padding(bottom = if (idx == alerts.lastIndex) 0.dp else 12.dp)) {
                Text(
                    text = "[${alert.severity}] ${alert.title}",
                    color = if (alert.severity == "CRITICAL") ExtremeRed else AlertOrange,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = alert.message,
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

// --- Glowing Glass Main Weather Readout ---
@Composable
fun MainWeatherGlassCard(
    state: WeatherUiState.Success,
    weatherInfo: WeatherInfo,
    currentLanguage: String,
    key: Any? = null
) {
    val current = state.weather.current ?: return
    val contentColor = LocalContentColor.current
    val localizedDesc = remember(current.weatherCode, currentLanguage) {
        com.example.ui.utils.WeatherLocalization.getWeatherDescription(current.weatherCode, currentLanguage)
    }

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("current_weather_card"),
        key = key
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // High-Precision Meteorological Sync Status Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(NeonCyan.copy(alpha = 0.12f))
                    .border(
                        1.dp,
                        NeonCyan.copy(alpha = 0.4f),
                        RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(50.dp))
                            .background(NeonCyan)
                    )
                    Text(
                        text = "HYPER-LOCAL METEOROLOGICAL ENGINE (ECMWF/GFS)",
                        color = NeonCyan,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Weather Icon & Description
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                DynamicWeatherIcon(
                    weatherInfo = weatherInfo,
                    modifier = Modifier.size(54.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = localizedDesc,
                        color = contentColor,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (current.isDay != 0) {
                            com.example.ui.utils.WeatherLocalization.get("day_wave", currentLanguage)
                        } else {
                            com.example.ui.utils.WeatherLocalization.get("night_wave", currentLanguage)
                        },
                        color = contentColor.copy(alpha = 0.5f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Massive temperature read
            Text(
                text = "${current.temperature.toInt()}°",
                color = contentColor,
                fontWeight = FontWeight.Light,
                fontSize = 72.sp,
                fontFamily = FontFamily.SansSerif,
                modifier = Modifier.offset(x = 6.dp) // centering offset
            )

            // High/Low for the day
            val tempMax = state.weather.daily?.tempMax?.firstOrNull()?.toInt() ?: 0
            val tempMin = state.weather.daily?.tempMin?.firstOrNull()?.toInt() ?: 0
            val apparentLabel = com.example.ui.utils.WeatherLocalization.get("apparent", currentLanguage)
            Text(
                text = "H: $tempMax°   L: $tempMin°   $apparentLabel: ${current.apparentTemperature.toInt()}°",
                color = contentColor.copy(alpha = 0.7f),
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )

            // Current Weather Condition Probability Badge Tag
            val currentPrecipProb = state.weather.daily?.precipitationProbabilityMax?.firstOrNull()
            val currentProbInfo = remember(current.weatherCode, currentPrecipProb, current.cloudCover, currentLanguage) {
                WeatherUtils.getWeatherTypeProbability(current.weatherCode, currentPrecipProb, current.cloudCover, currentLanguage)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
                color = currentProbInfo.tint.copy(alpha = 0.15f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, currentProbInfo.tint.copy(alpha = 0.35f))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                ) {
                    Icon(
                        imageVector = currentProbInfo.icon,
                        contentDescription = null,
                        tint = currentProbInfo.tint,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${currentProbInfo.label}: ${currentProbInfo.percentage}%",
                        color = contentColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Divider(color = contentColor.copy(alpha = 0.08f))
            Spacer(modifier = Modifier.height(16.dp))

            // Weather telemetry indicators (Humidity, Wind with direction arrow, Pressure)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                TelemetryItem(
                    icon = Icons.Outlined.WaterDrop,
                    label = com.example.ui.utils.WeatherLocalization.get("humidity", currentLanguage).uppercase(java.util.Locale.ROOT),
                    value = "${current.humidity.toInt()}${com.example.ui.utils.WeatherLocalization.get("percent_unit", currentLanguage)}",
                    tint = RainCyan
                )

                val windDeg = current.windDirection ?: 0.0
                val windDirAbbr = WeatherUtils.getWindAbbreviation(windDeg)
                TelemetryItem(
                    icon = Icons.Default.Navigation,
                    label = com.example.ui.utils.WeatherLocalization.get("wind_speed", currentLanguage).uppercase(java.util.Locale.ROOT),
                    value = "${current.windSpeed.toInt()}${com.example.ui.utils.WeatherLocalization.get("wind_unit", currentLanguage)} $windDirAbbr",
                    tint = SkyBlue,
                    iconRotation = windDeg.toFloat()
                )

                TelemetryItem(
                    icon = Icons.Outlined.Compress,
                    label = com.example.ui.utils.WeatherLocalization.get("air_pressure", currentLanguage).uppercase(java.util.Locale.ROOT),
                    value = "${current.pressure.toInt()}${com.example.ui.utils.WeatherLocalization.get("pressure_unit", currentLanguage)}",
                    tint = StormViolet
                )
            }
        }
    }
}

@Composable
fun TelemetryItem(icon: ImageVector, label: String, value: String, tint: Color, iconRotation: Float? = null) {
    val contentColor = LocalContentColor.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier
                .size(20.dp)
                .then(if (iconRotation != null) Modifier.rotate(iconRotation) else Modifier)
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            color = contentColor.copy(alpha = 0.4f),
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            color = contentColor,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// --- Quick Location Horizontal Swipe Selector ---
@Composable
fun QuickLocationSelector(
    savedLocations: List<SavedLocation>,
    activeLocation: SavedLocation,
    onSelectLocation: (SavedLocation) -> Unit,
    onDeleteLocation: (SavedLocation) -> Unit
) {
    val contentColor = LocalContentColor.current
    val isDarkTheme = MaterialTheme.colorScheme.onBackground == Color.White

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "SAVED CITIES",
            color = NeonCyan,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(savedLocations) { location ->
                val isActive = location.id == activeLocation.id
                val borderAlpha by animateFloatAsState(targetValue = if (isActive) 0.7f else 0.15f, label = "BorderAlpha")

                val cardBgColors = if (isActive) {
                    listOf(SkyBlue.copy(alpha = 0.18f), NeonPurple.copy(alpha = 0.18f))
                } else {
                    if (isDarkTheme) {
                        listOf(Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.02f))
                    } else {
                        listOf(Color.Black.copy(alpha = 0.05f), Color.Black.copy(alpha = 0.02f))
                    }
                }

                val cardBorderColor = if (isActive) {
                    NeonCyan.copy(alpha = borderAlpha)
                } else {
                    contentColor.copy(alpha = 0.12f)
                }

                Box(
                    modifier = Modifier
                        .width(152.dp)
                        .background(
                            brush = Brush.linearGradient(colors = cardBgColors),
                            shape = RoundedCornerShape(18.dp)
                        )
                        .border(
                            width = 1.dp,
                            color = cardBorderColor,
                            shape = RoundedCornerShape(18.dp)
                        )
                        .clickable { onSelectLocation(location) }
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = location.name,
                                color = contentColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (location.isFavorite) {
                                Icon(
                                    imageVector = Icons.Filled.Favorite,
                                    contentDescription = "Fav",
                                    tint = ExtremeRed,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }

                        val detailLabel = location.admin1 ?: location.country ?: ""
                        Text(
                            text = detailLabel,
                            color = contentColor.copy(alpha = 0.5f),
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            IconButton(
                                onClick = { onDeleteLocation(location) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete",
                                    tint = contentColor.copy(alpha = 0.4f),
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- Hourly Forecast row (Horizontal Apple-Weather style) ---
@Composable
fun HourlyForecastCard(weather: WeatherResponse, currentLanguage: String, key: Any? = null) {
    val hourly = weather.hourly ?: return

    // Show next 12 hours
    val times = hourly.time.take(12)
    val temps = hourly.temperature.take(12)
    val codes = hourly.weatherCode.take(12)

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        key = key
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = com.example.ui.utils.WeatherLocalization.get("hourly_forecast", currentLanguage),
                color = NeonCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                itemsIndexed(times) { index, isoTime ->
                    val temp = temps.getOrNull(index) ?: 20.0
                    val code = codes.getOrNull(index) ?: 0
                    val hourString = remember(isoTime, currentLanguage) {
                        try {
                            val locale = when (currentLanguage) {
                                "uz" -> Locale("uz")
                                "ru" -> Locale("ru")
                                else -> Locale.ENGLISH
                            }
                            val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", locale)
                            val timeFormatPattern = if (currentLanguage == "en") "h a" else "HH:mm"
                            val formatter = SimpleDateFormat(timeFormatPattern, locale)
                            val date = parser.parse(isoTime)
                            formatter.format(date ?: Date())
                        } catch (e: Exception) {
                            isoTime.substringAfter("T")
                        }
                    }
                    val isHourDay = remember(isoTime) {
                        try {
                            val hourPart = isoTime.substringAfter("T").substringBefore(":").toIntOrNull() ?: 12
                            hourPart in 6..18
                        } catch (e: Exception) {
                            true
                        }
                    }
                    val itemWeatherInfo = remember(code, currentLanguage, isHourDay) { 
                        val baseInfo = WeatherUtils.getWeatherInfo(code, isHourDay)
                        baseInfo.copy(description = com.example.ui.utils.WeatherLocalization.getWeatherDescription(code, currentLanguage))
                    }

                    val hourlyPrecipProb = hourly.precipitationProbability?.getOrNull(index)
                    val hourlyProbInfo = remember(code, hourlyPrecipProb, currentLanguage) {
                        WeatherUtils.getWeatherTypeProbability(code, hourlyPrecipProb, null, currentLanguage)
                    }

                    val contentColor = LocalContentColor.current
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    ) {
                        Text(
                            text = hourString,
                            color = contentColor.copy(alpha = 0.5f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        DynamicWeatherIcon(
                            weatherInfo = itemWeatherInfo,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${temp.toInt()}°",
                            color = contentColor,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${hourlyProbInfo.percentage}%",
                            color = hourlyProbInfo.tint,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// --- Detail Metric Mini Card inside Expanded Forecast ---
@Composable
fun DetailMetricMiniCard(
    label: String,
    value: String,
    icon: ImageVector,
    tint: Color,
    iconRotation: Float? = null
) {
    var isPointerHovered by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }
    val isHoveredState by interactionSource.collectIsHoveredAsState()
    val isPressedState by interactionSource.collectIsPressedAsState()
    val active = isPointerHovered || isHoveredState || isPressedState

    val scale by animateFloatAsState(
        targetValue = if (active) 1.04f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "MiniCardScale"
    )

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (active) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.08f),
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            width = if (active) 1.dp else 0.5.dp,
            color = if (active) tint.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.12f)
        ),
        modifier = Modifier
            .width(135.dp)
            .height(72.dp)
            .hoverable(interactionSource)
            .graphicsLayer(
                scaleX = scale,
                scaleY = scale
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = tint,
                    modifier = Modifier
                        .size(15.dp)
                        .then(if (iconRotation != null) Modifier.rotate(iconRotation) else Modifier)
                )
                Text(
                    text = label,
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                text = value,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// --- Horizontal Glassmorphism Daily Forecast Card Component ---
@Composable
fun HorizontalDailyForecastGlassCard(
    dayName: String,
    dateString: String,
    dayWeatherInfo: WeatherInfo,
    minTemp: Double,
    maxTemp: Double,
    absoluteMin: Double,
    absoluteMax: Double,
    rangeSpan: Double,
    probInfo: WeatherProbabilityInfo,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    viewportScaleProvider: () -> Float = { 1f },
    viewportAlphaProvider: () -> Float = { 1f },
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isHoveredState by interactionSource.collectIsHoveredAsState()
    val isPressedState by interactionSource.collectIsPressedAsState()
    val active = isHoveredState || isPressedState || isSelected

    val activeScaleBoost by animateFloatAsState(
        targetValue = if (active) 1.05f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessLow, dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "DailyCardActiveScale"
    )

    val contentColor = LocalContentColor.current

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color.White.copy(alpha = 0.18f)
                             else if (active) Color.White.copy(alpha = 0.14f)
                             else Color.White.copy(alpha = 0.08f),
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else if (active) 1.dp else 0.5.dp,
            color = if (isSelected) NeonCyan else if (active) Color.White.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.15f)
        ),
        modifier = modifier
            .width(145.dp)
            .height(205.dp)
            .hoverable(interactionSource)
            .graphicsLayer {
                val finalScale = viewportScaleProvider() * activeScaleBoost
                scaleX = finalScale
                scaleY = finalScale
                alpha = viewportAlphaProvider()
            }
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. Day Name & Date Header
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = dayName,
                    color = if (isSelected) NeonCyan else contentColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (dateString.isNotEmpty()) {
                    Text(
                        text = dateString,
                        color = contentColor.copy(alpha = 0.5f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // 2. Weather Icon & Description
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                DynamicWeatherIcon(
                    weatherInfo = dayWeatherInfo,
                    modifier = Modifier.size(40.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = dayWeatherInfo.description,
                    color = contentColor.copy(alpha = 0.85f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
            }

            // 3. High/Low Temp & Symmetrical Mini Range Slider
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "L ",
                            color = SkyBlue,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${minTemp.toInt()}°",
                            color = contentColor.copy(alpha = 0.7f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "H ",
                            color = SunlightYellow,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${maxTemp.toInt()}°",
                            color = contentColor,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                val fillStartFraction = ((minTemp - absoluteMin) / rangeSpan).toFloat().coerceIn(0f, 1f)
                val fillEndFraction = ((maxTemp - absoluteMin) / rangeSpan).toFloat().coerceIn(0f, 1f)

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                ) {
                    val trackWidth = size.width
                    val trackHeight = size.height
                    val rRadius = trackHeight / 2f

                    drawRoundRect(
                        color = contentColor.copy(alpha = 0.12f),
                        size = size,
                        cornerRadius = CornerRadius(rRadius, rRadius)
                    )

                    val startX = fillStartFraction * trackWidth
                    val endX = fillEndFraction * trackWidth
                    val barWidth = (endX - startX).coerceAtLeast(6f)

                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            colors = listOf(SkyBlue, SunlightYellow),
                            startX = startX,
                            endX = endX
                        ),
                        topLeft = Offset(startX, 0f),
                        size = Size(barWidth, trackHeight),
                        cornerRadius = CornerRadius(rRadius, rRadius)
                    )
                }
            }

            // 4. Precipitation Probability Pill Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .background(color = probInfo.tint.copy(alpha = 0.15f), shape = RoundedCornerShape(10.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Icon(
                    imageVector = probInfo.icon,
                    contentDescription = null,
                    tint = probInfo.tint,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = "${probInfo.percentage}%",
                    color = probInfo.tint,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// --- 7-Day Range Horizontal Glassmorphism Card Forecast ---
@Composable
fun SevenDayForecastCard(weather: WeatherResponse, currentLanguage: String, key: Any? = null) {
    val daily = weather.daily ?: return

    val times = daily.time
    val codes = daily.weatherCode
    val maxTemps = daily.tempMax
    val minTemps = daily.tempMin

    // Determine absolute extremes of this 7-day run to calibrate symmetrical slider bars
    val absoluteMin = minTemps.minOrNull() ?: 0.0
    val absoluteMax = maxTemps.maxOrNull() ?: 40.0
    val rangeSpan = (absoluteMax - absoluteMin).coerceAtLeast(1.0)

    var selectedIndex by remember { mutableStateOf<Int?>(0) }
    var isHorizontalMode by remember { mutableStateOf(true) }
    val horizontalListState = rememberLazyListState()

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        key = key
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header with title and view mode switcher
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = com.example.ui.utils.WeatherLocalization.get("seven_day_forecast", currentLanguage),
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 1.sp
                )

                IconButton(
                    onClick = { isHorizontalMode = !isHorizontalMode },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = if (isHorizontalMode) Icons.Default.FormatListBulleted else Icons.Default.ViewWeek,
                        contentDescription = "Switch View Mode",
                        tint = LocalContentColor.current.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            if (isHorizontalMode) {
                // Horizontal Scrolling Glass Cards Layout with Framer Motion style viewport entrance animations
                LazyRow(
                    state = horizontalListState,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    itemsIndexed(times) { index, isoTime ->
                        val code = codes.getOrNull(index) ?: 0
                        val minTemp = minTemps.getOrNull(index) ?: 0.0
                        val maxTemp = maxTemps.getOrNull(index) ?: 20.0
                        val dayWeatherInfo = remember(code, currentLanguage) {
                            val baseInfo = WeatherUtils.getWeatherInfo(code)
                            baseInfo.copy(description = com.example.ui.utils.WeatherLocalization.getWeatherDescription(code, currentLanguage))
                        }

                        val dayName = remember(isoTime, currentLanguage) {
                            try {
                                val locale = when (currentLanguage) {
                                    "uz" -> Locale("uz")
                                    "ru" -> Locale("ru")
                                    else -> Locale.ENGLISH
                                }
                                val parser = SimpleDateFormat("yyyy-MM-dd", locale)
                                val formatter = SimpleDateFormat("EEEE", locale)
                                val date = parser.parse(isoTime)
                                if (index == 0) {
                                    com.example.ui.utils.WeatherLocalization.get("today", currentLanguage)
                                } else {
                                    formatter.format(date ?: Date()).replaceFirstChar { if (it.isLowerCase()) it.titlecase(locale) else it.toString() }
                                }
                            } catch (e: Exception) {
                                "Day ${index + 1}"
                            }
                        }

                        val dateString = remember(isoTime) {
                            try {
                                val parts = isoTime.split("-")
                                if (parts.size == 3) "${parts[1]}/${parts[2]}" else ""
                            } catch (e: Exception) {
                                ""
                            }
                        }

                        val dailyPrecipProb = daily.precipitationProbabilityMax?.getOrNull(index)
                        val dayProbInfo = remember(code, dailyPrecipProb, currentLanguage) {
                            WeatherUtils.getWeatherTypeProbability(code, dailyPrecipProb, null, currentLanguage)
                        }

                        // Deferred viewport-relative scroll visibility lambdas to prevent recomposition during scroll
                        val viewportScaleProvider: () -> Float = remember(index) {
                            {
                                val itemInfo = horizontalListState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == index }
                                val viewportWidth = horizontalListState.layoutInfo.viewportSize.width.toFloat()
                                if (itemInfo != null && viewportWidth > 0f) {
                                    val itemStart = itemInfo.offset.toFloat()
                                    val itemWidth = itemInfo.size.toFloat()
                                    val itemEnd = itemStart + itemWidth

                                    val rightEdgeVisible = ((viewportWidth - itemStart) / (itemWidth * 0.75f)).coerceIn(0f, 1f)
                                    val leftEdgeVisible = (itemEnd / (itemWidth * 0.75f)).coerceIn(0f, 1f)
                                    val visibility = minOf(rightEdgeVisible, leftEdgeVisible)

                                    0.85f + 0.15f * visibility
                                } else {
                                    1f
                                }
                            }
                        }

                        val viewportAlphaProvider: () -> Float = remember(index) {
                            {
                                val itemInfo = horizontalListState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == index }
                                val viewportWidth = horizontalListState.layoutInfo.viewportSize.width.toFloat()
                                if (itemInfo != null && viewportWidth > 0f) {
                                    val itemStart = itemInfo.offset.toFloat()
                                    val itemWidth = itemInfo.size.toFloat()
                                    val itemEnd = itemStart + itemWidth

                                    val rightEdgeVisible = ((viewportWidth - itemStart) / (itemWidth * 0.75f)).coerceIn(0f, 1f)
                                    val leftEdgeVisible = (itemEnd / (itemWidth * 0.75f)).coerceIn(0f, 1f)
                                    val visibility = minOf(rightEdgeVisible, leftEdgeVisible)

                                    0.35f + 0.65f * visibility
                                } else {
                                    1f
                                }
                            }
                        }

                        HorizontalDailyForecastGlassCard(
                            dayName = dayName,
                            dateString = dateString,
                            dayWeatherInfo = dayWeatherInfo,
                            minTemp = minTemp,
                            maxTemp = maxTemp,
                            absoluteMin = absoluteMin,
                            absoluteMax = absoluteMax,
                            rangeSpan = rangeSpan,
                            probInfo = dayProbInfo,
                            isSelected = selectedIndex == index,
                            viewportScaleProvider = viewportScaleProvider,
                            viewportAlphaProvider = viewportAlphaProvider,
                            onClick = {
                                selectedIndex = if (selectedIndex == index) null else index
                            }
                        )
                    }
                }

                // Selected Day Deep Details Row
                selectedIndex?.let { index ->
                    val code = codes.getOrNull(index) ?: 0
                    val minTemp = minTemps.getOrNull(index) ?: 0.0
                    val maxTemp = maxTemps.getOrNull(index) ?: 20.0
                    val dayWeatherInfo = remember(code, currentLanguage) {
                        val baseInfo = WeatherUtils.getWeatherInfo(code)
                        baseInfo.copy(description = com.example.ui.utils.WeatherLocalization.getWeatherDescription(code, currentLanguage))
                    }
                    val dailyPrecipProb = daily.precipitationProbabilityMax?.getOrNull(index)
                    val dayProbInfo = remember(code, dailyPrecipProb, currentLanguage) {
                        WeatherUtils.getWeatherTypeProbability(code, dailyPrecipProb, null, currentLanguage)
                    }

                    val formattedSunrise = remember(daily.sunrise.getOrNull(index), currentLanguage) {
                        try {
                            val sunriseTime = daily.sunrise.getOrNull(index) ?: ""
                            val locale = when (currentLanguage) {
                                "uz" -> Locale("uz")
                                "ru" -> Locale("ru")
                                else -> Locale.ENGLISH
                            }
                            val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", locale)
                            val formatter = SimpleDateFormat("HH:mm", locale)
                            val date = parser.parse(sunriseTime)
                            formatter.format(date ?: Date())
                        } catch (e: Exception) {
                            "--:--"
                        }
                    }

                    val formattedSunset = remember(daily.sunset.getOrNull(index), currentLanguage) {
                        try {
                            val sunsetTime = daily.sunset.getOrNull(index) ?: ""
                            val locale = when (currentLanguage) {
                                "uz" -> Locale("uz")
                                "ru" -> Locale("ru")
                                else -> Locale.ENGLISH
                            }
                            val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", locale)
                            val formatter = SimpleDateFormat("HH:mm", locale)
                            val date = parser.parse(sunsetTime)
                            formatter.format(date ?: Date())
                        } catch (e: Exception) {
                            "--:--"
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            DetailMetricMiniCard(
                                label = dayProbInfo.label,
                                value = "${dayProbInfo.percentage}% (${dayWeatherInfo.description})",
                                icon = dayProbInfo.icon,
                                tint = dayProbInfo.tint
                            )
                        }
                        item {
                            val minFeels = daily.apparentTempMin.getOrNull(index) ?: minTemp
                            val maxFeels = daily.apparentTempMax.getOrNull(index) ?: maxTemp
                            DetailMetricMiniCard(
                                label = "Apparent Temp",
                                value = "${minFeels.toInt()}° - ${maxFeels.toInt()}°",
                                icon = Icons.Default.Thermostat,
                                tint = SunlightYellow
                            )
                        }
                        item {
                            val precip = daily.precipitationSum.getOrNull(index) ?: 0.0
                            DetailMetricMiniCard(
                                label = "Precipitation",
                                value = "${precip} mm",
                                icon = Icons.Outlined.WaterDrop,
                                tint = SkyBlue
                            )
                        }
                        item {
                            val wind = daily.windSpeedMax.getOrNull(index) ?: 0.0
                            val windDeg = daily.windDirectionDominant?.getOrNull(index) ?: 0.0
                            val windHeading = WeatherUtils.getWindDirectionCardinal(windDeg, currentLanguage)
                            DetailMetricMiniCard(
                                label = "Wind & Heading",
                                value = "${wind.toInt()} km/h $windHeading",
                                icon = Icons.Default.Navigation,
                                tint = NeonCyan,
                                iconRotation = windDeg.toFloat()
                            )
                        }
                        item {
                            val uv = daily.uvIndexMax.getOrNull(index) ?: 0.0
                            DetailMetricMiniCard(
                                label = "UV Index",
                                value = "$uv",
                                icon = Icons.Default.WbSunny,
                                tint = SunlightYellow
                            )
                        }
                        item {
                            DetailMetricMiniCard(
                                label = "Sunrise",
                                value = formattedSunrise,
                                icon = Icons.Default.WbSunny,
                                tint = SunlightYellow
                            )
                        }
                        item {
                            DetailMetricMiniCard(
                                label = "Sunset",
                                value = formattedSunset,
                                icon = Icons.Default.NightsStay,
                                tint = AlertOrange
                            )
                        }
                    }
                }
            } else {
                // Vertical List View
                times.forEachIndexed { index, isoTime ->
                    val code = codes.getOrNull(index) ?: 0
                    val minTemp = minTemps.getOrNull(index) ?: 0.0
                    val maxTemp = maxTemps.getOrNull(index) ?: 20.0
                    val dayWeatherInfo = remember(code, currentLanguage) { 
                        val baseInfo = WeatherUtils.getWeatherInfo(code)
                        baseInfo.copy(description = com.example.ui.utils.WeatherLocalization.getWeatherDescription(code, currentLanguage))
                    }

                    val dayName = remember(isoTime, currentLanguage) {
                        try {
                            val locale = when (currentLanguage) {
                                "uz" -> Locale("uz")
                                "ru" -> Locale("ru")
                                else -> Locale.ENGLISH
                            }
                            val parser = SimpleDateFormat("yyyy-MM-dd", locale)
                            val formatter = SimpleDateFormat("EEEE", locale)
                            val date = parser.parse(isoTime)
                            if (index == 0) {
                                com.example.ui.utils.WeatherLocalization.get("today", currentLanguage)
                            } else {
                                formatter.format(date ?: Date()).replaceFirstChar { if (it.isLowerCase()) it.titlecase(locale) else it.toString() }
                            }
                        } catch (e: Exception) {
                            "Horizon"
                        }
                    }

                    val formattedSunrise = remember(daily.sunrise.getOrNull(index), currentLanguage) {
                        try {
                            val sunriseTime = daily.sunrise.getOrNull(index) ?: ""
                            val locale = when (currentLanguage) {
                                "uz" -> Locale("uz")
                                "ru" -> Locale("ru")
                                else -> Locale.ENGLISH
                            }
                            val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", locale)
                            val formatter = SimpleDateFormat("HH:mm", locale)
                            val date = parser.parse(sunriseTime)
                            formatter.format(date ?: Date())
                        } catch (e: Exception) {
                            "--:--"
                        }
                    }

                    val formattedSunset = remember(daily.sunset.getOrNull(index), currentLanguage) {
                        try {
                            val sunsetTime = daily.sunset.getOrNull(index) ?: ""
                            val locale = when (currentLanguage) {
                                "uz" -> Locale("uz")
                                "ru" -> Locale("ru")
                                else -> Locale.ENGLISH
                            }
                            val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", locale)
                            val formatter = SimpleDateFormat("HH:mm", locale)
                            val date = parser.parse(sunsetTime)
                            formatter.format(date ?: Date())
                        } catch (e: Exception) {
                            "--:--"
                        }
                    }

                    val dailyPrecipProb = daily.precipitationProbabilityMax?.getOrNull(index)
                    val dayProbInfo = remember(code, dailyPrecipProb, currentLanguage) {
                        WeatherUtils.getWeatherTypeProbability(code, dailyPrecipProb, null, currentLanguage)
                    }

                    val isExpanded = selectedIndex == index
                    val contentColor = LocalContentColor.current

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    selectedIndex = if (isExpanded) null else index
                                }
                                .padding(vertical = 10.dp, horizontal = 4.dp)
                        ) {
                            Text(
                                text = dayName,
                                color = contentColor,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp,
                                modifier = Modifier.width(72.dp)
                            )

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.width(62.dp)
                            ) {
                                DynamicWeatherIcon(
                                    weatherInfo = dayWeatherInfo,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "${dayProbInfo.percentage}%",
                                    color = dayProbInfo.tint,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            Text(
                                text = "${minTemp.toInt()}°",
                                color = contentColor.copy(alpha = 0.5f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(28.dp),
                                textAlign = TextAlign.End
                            )

                            val fillStartFraction = ((minTemp - absoluteMin) / rangeSpan).toFloat().coerceIn(0f, 1f)
                            val fillEndFraction = ((maxTemp - absoluteMin) / rangeSpan).toFloat().coerceIn(0f, 1f)

                            Canvas(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(6.dp)
                                    .padding(horizontal = 8.dp)
                            ) {
                                val trackWidth = size.width
                                val trackHeight = size.height
                                val rRadius = trackHeight / 2f

                                drawRoundRect(
                                    color = contentColor.copy(alpha = 0.12f),
                                    size = size,
                                    cornerRadius = CornerRadius(rRadius, rRadius)
                                )

                                val startX = fillStartFraction * trackWidth
                                val endX = fillEndFraction * trackWidth
                                val barWidth = (endX - startX).coerceAtLeast(6f)

                                drawRoundRect(
                                    brush = Brush.horizontalGradient(
                                        colors = listOf(SkyBlue, SunlightYellow),
                                        startX = startX,
                                        endX = endX
                                    ),
                                    topLeft = Offset(startX, 0f),
                                    size = Size(barWidth, trackHeight),
                                    cornerRadius = CornerRadius(rRadius, rRadius)
                                )
                            }

                            Text(
                                text = "${maxTemp.toInt()}°",
                                color = contentColor,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(28.dp),
                                textAlign = TextAlign.End
                            )

                            Spacer(modifier = Modifier.width(6.dp))

                            Icon(
                                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = "Details Indicator",
                                tint = contentColor.copy(alpha = 0.4f),
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        if (isExpanded) {
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 8.dp)
                            ) {
                                item {
                                    DetailMetricMiniCard(
                                        label = dayProbInfo.label,
                                        value = "${dayProbInfo.percentage}% (${dayWeatherInfo.description})",
                                        icon = dayProbInfo.icon,
                                        tint = dayProbInfo.tint
                                    )
                                }
                                item {
                                    val minFeels = daily.apparentTempMin.getOrNull(index) ?: minTemp
                                    val maxFeels = daily.apparentTempMax.getOrNull(index) ?: maxTemp
                                    DetailMetricMiniCard(
                                        label = "Apparent Temp",
                                        value = "${minFeels.toInt()}° - ${maxFeels.toInt()}°",
                                        icon = Icons.Default.Thermostat,
                                        tint = SunlightYellow
                                    )
                                }
                                item {
                                    val precip = daily.precipitationSum.getOrNull(index) ?: 0.0
                                    DetailMetricMiniCard(
                                        label = "Precipitation",
                                        value = "${precip} mm",
                                        icon = Icons.Outlined.WaterDrop,
                                        tint = SkyBlue
                                    )
                                }
                                item {
                                    val wind = daily.windSpeedMax.getOrNull(index) ?: 0.0
                                    val windDeg = daily.windDirectionDominant?.getOrNull(index) ?: 0.0
                                    val windHeading = WeatherUtils.getWindDirectionCardinal(windDeg, currentLanguage)
                                    DetailMetricMiniCard(
                                        label = "Wind & Heading",
                                        value = "${wind.toInt()} km/h $windHeading",
                                        icon = Icons.Default.Navigation,
                                        tint = NeonCyan,
                                        iconRotation = windDeg.toFloat()
                                    )
                                }
                                item {
                                    val uv = daily.uvIndexMax.getOrNull(index) ?: 0.0
                                    DetailMetricMiniCard(
                                        label = "UV Index",
                                        value = "$uv",
                                        icon = Icons.Default.WbSunny,
                                        tint = SunlightYellow
                                    )
                                }
                                item {
                                    DetailMetricMiniCard(
                                        label = "Sunrise",
                                        value = formattedSunrise,
                                        icon = Icons.Default.WbSunny,
                                        tint = SunlightYellow
                                    )
                                }
                                item {
                                    DetailMetricMiniCard(
                                        label = "Sunset",
                                        value = formattedSunset,
                                        icon = Icons.Default.NightsStay,
                                        tint = AlertOrange
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- Interactive Weather Radar Map Canvas Simulator ---
@Composable
fun WeatherRadarMapCard(
    location: SavedLocation,
    viewModel: WeatherViewModel,
    currentLanguage: String,
    key: Any? = null
) {
    var isScanning by remember { mutableStateOf(true) }
    var zoomLevel by remember { mutableStateOf(1f) }
    var showPrecipitationOverlay by remember { mutableStateOf(true) }
    var tappedCoords by remember { mutableStateOf<Offset?>(null) }

    val infiniteTransition = rememberInfiniteTransition(label = "RadarSweeper")
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "SweepAngle"
    )

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        key = key
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = com.example.ui.utils.WeatherLocalization.get("radar_simulation", currentLanguage),
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (currentLanguage == "uz") "Real vaqtdagi front skanerlash: ${location.name}" else if (currentLanguage == "ru") "Сканирование в реальном времени: ${location.name}" else "Real-time Front scanning: ${location.name}",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 11.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Active scanning toggle
                    Switch(
                        checked = isScanning,
                        onCheckedChange = { isScanning = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonCyan,
                            checkedTrackColor = NeonCyan.copy(alpha = 0.3f),
                            uncheckedThumbColor = Color.White.copy(alpha = 0.4f),
                            uncheckedTrackColor = Color.White.copy(alpha = 0.1f)
                        ),
                        modifier = Modifier.scale(0.8f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isScanning) {
                            if (currentLanguage == "uz") "FAOL" else if (currentLanguage == "ru") "АКТИВЕН" else "ACTIVE"
                        } else {
                            if (currentLanguage == "uz") "PAUZA" else if (currentLanguage == "ru") "ПАУЗА" else "PAUSE"
                        },
                        color = if (isScanning) NeonCyan else Color.White.copy(alpha = 0.5f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Radar display
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                    .background(Color(0xFF070B19))
                    .pointerInput(Unit) {
                        detectTapGestures { offset ->
                            tappedCoords = offset
                            // trigger small simulated flash alerts based on tapped coordinates
                            val lightningTitle = when (currentLanguage) {
                                "uz" -> "Mahalliy chaqmoq razryadi"
                                "ru" -> "Локальный грозовой разряд"
                                else -> "Localized Lightning Discharge"
                            }
                            val lightningMsg = when (currentLanguage) {
                                "uz" -> "Koordinata kvadrantida faol konvektiv bulut urilishi aniqlandi."
                                "ru" -> "В квадранте координат обнаружен активный конвективный грозовой разряд."
                                else -> "Active convective cell strike detected near coordinates quadrant grid point."
                            }
                            viewModel.simulateExtremeWeatherWarning(
                                severity = "WARNING",
                                title = lightningTitle,
                                message = lightningMsg
                            )
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height
                    val center = Offset(width / 2f, height / 2f)
                    val maxRadius = center.x.coerceAtMost(center.y) * 0.95f

                    // Draw concentric radar range indicator rings
                    drawCircle(color = Color.White.copy(alpha = 0.03f), radius = maxRadius, style = Stroke(1.5f))
                    drawCircle(color = Color.White.copy(alpha = 0.05f), radius = maxRadius * 0.66f, style = Stroke(1.5f))
                    drawCircle(color = Color.White.copy(alpha = 0.08f), radius = maxRadius * 0.33f, style = Stroke(1.5f))

                    // Draw cardinal axes
                    drawLine(
                        color = Color.White.copy(alpha = 0.05f),
                        start = Offset(center.x - maxRadius, center.y),
                        end = Offset(center.x + maxRadius, center.y),
                        strokeWidth = 1f
                    )
                    drawLine(
                        color = Color.White.copy(alpha = 0.05f),
                        start = Offset(center.x, center.y - maxRadius),
                        end = Offset(center.x, center.y + maxRadius),
                        strokeWidth = 1f
                    )

                    // Draw some stylized vector land mass contours to represent regional grids
                    val path = Path().apply {
                        moveTo(center.x - maxRadius * 0.6f, center.y - maxRadius * 0.3f)
                        quadraticTo(
                            center.x - maxRadius * 0.2f, center.y - maxRadius * 0.7f,
                            center.x + maxRadius * 0.2f, center.y - maxRadius * 0.4f
                        )
                        quadraticTo(
                            center.x + maxRadius * 0.5f, center.y - maxRadius * 0.1f,
                            center.x + maxRadius * 0.7f, center.y + maxRadius * 0.3f
                        )
                        quadraticTo(
                            center.x + maxRadius * 0.2f, center.y + maxRadius * 0.5f,
                            center.x - maxRadius * 0.3f, center.y + maxRadius * 0.2f
                        )
                        close()
                    }
                    drawPath(
                        path = path,
                        color = SkyBlue.copy(alpha = 0.07f),
                        style = Stroke(2f)
                    )

                    // Draw simulated severe weather storm fronts (Precipitation overlays)
                    if (showPrecipitationOverlay) {
                        // Cyan/Yellow/Red storm blobs indicating level of danger
                        val frontCenter1 = Offset(center.x + maxRadius * 0.25f, center.y - maxRadius * 0.15f)
                        val frontCenter2 = Offset(center.x - maxRadius * 0.4f, center.y + maxRadius * 0.3f)

                        // Light storm
                        drawCircle(color = RainCyan.copy(alpha = 0.2f), radius = maxRadius * 0.3f, center = frontCenter1)
                        drawCircle(color = RainCyan.copy(alpha = 0.15f), radius = maxRadius * 0.25f, center = frontCenter2)

                        // Heavy cell inside
                        drawCircle(color = SunlightYellow.copy(alpha = 0.25f), radius = maxRadius * 0.15f, center = frontCenter1)
                        // Severe core (Extreme cell)
                        drawCircle(color = ExtremeRed.copy(alpha = 0.3f), radius = maxRadius * 0.07f, center = frontCenter1)
                    }

                    // Tapped storm point flash
                    tappedCoords?.let { tap ->
                        drawCircle(
                            color = NeonCyan.copy(alpha = 0.6f),
                            radius = maxRadius * 0.1f,
                            center = tap,
                            style = Stroke(2.dp.toPx())
                        )
                    }

                    // Sweep Scanning Beam
                    if (isScanning) {
                        val angleRadians = Math.toRadians(sweepAngle.toDouble()).toFloat()
                        val sweepEndX = center.x + maxRadius * cos(angleRadians)
                        val sweepEndY = center.y + maxRadius * sin(angleRadians)

                        // Glowing sweeper line
                        drawLine(
                            color = NeonCyan,
                            start = center,
                            end = Offset(sweepEndX, sweepEndY),
                            strokeWidth = 3f
                        )

                        // Soft trailing gradient wedge behind sweeper line
                        val wedgePath = Path().apply {
                            moveTo(center.x, center.y)
                            lineTo(sweepEndX, sweepEndY)
                            val trailingAngleRad = Math.toRadians((sweepAngle - 25f).toDouble()).toFloat()
                            lineTo(center.x + maxRadius * cos(trailingAngleRad), center.y + maxRadius * sin(trailingAngleRad))
                            close()
                        }
                        drawPath(
                            path = wedgePath,
                            brush = Brush.radialGradient(
                                colors = listOf(NeonCyan.copy(alpha = 0.15f), Color.Transparent),
                                center = center,
                                radius = maxRadius
                            )
                        )
                    }
                }

                // Grid stats overlay
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    val sweepRadText = com.example.ui.utils.WeatherLocalization.get("sweep_rad", currentLanguage)
                    val cellCapText = when (currentLanguage) {
                        "uz" -> "BULUT SIG'IMI: KUCHLI"
                        "ru" -> "ОБЛАКО: ВЫСОКОЕ"
                        else -> "CELL CAP: HEAVY SEVERE"
                    }
                    val rainIdxText = when (currentLanguage) {
                        "uz" -> "YOMG'IR INDEKSI: 42.5 MM/S"
                        "ru" -> "ИНДЕКС ДОЖДЯ: 42.5 ММ/Ч"
                        else -> "RAIN INDEX: 42.5 MM/H"
                    }
                    Text(sweepRadText, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text(cellCapText, color = ExtremeRed, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text(rainIdxText, color = NeonCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }

                Text(
                    text = when (currentLanguage) {
                        "uz" -> "RAZRYADLARNI QAYD ETISH UCHUN KATAKLARNI BOSING"
                        "ru" -> "НАЖМИТЕ ДЛЯ СЕТКИ ЗАПИСИ РАЗРЯДОВ"
                        else -> "TAP GRIDS TO LOG DISCHARGES"
                    },
                    color = Color.White.copy(alpha = 0.4f),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(10.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Map interaction controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row {
                    Button(
                        onClick = { showPrecipitationOverlay = !showPrecipitationOverlay },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (showPrecipitationOverlay) SkyBlue.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.05f)
                        ),
                        border = BorderStroke(1.dp, if (showPrecipitationOverlay) SkyBlue else Color.White.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Text(
                            text = com.example.ui.utils.WeatherLocalization.get("show_precipitation", currentLanguage).uppercase(java.util.Locale.ROOT),
                            color = if (showPrecipitationOverlay) NeonCyan else Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { tappedCoords = null },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.05f)),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Text(
                            text = if (currentLanguage == "uz") "MATRITSANI TASHALASH" else if (currentLanguage == "ru") "СБРОС КУРСА" else "RESET MATRIX",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Interactive zoom display
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { zoomLevel = (zoomLevel - 0.25f).coerceAtLeast(0.5f) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Zoom out", tint = Color.White)
                    }
                    Text(
                        text = "${(zoomLevel * 100).toInt()}%",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.width(36.dp),
                        textAlign = TextAlign.Center
                    )
                    IconButton(
                        onClick = { zoomLevel = (zoomLevel + 0.25f).coerceIn(0.5f, 2f) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Zoom in", tint = Color.White)
                    }
                }
            }
        }
    }
}

// --- Localized Push Alerts Simulation Panel ---
@Composable
fun SimulationAlertsConsoleCard(viewModel: WeatherViewModel, currentLanguage: String, key: Any? = null) {
    var expanded by remember { mutableStateOf(false) }
    val contentColor = LocalContentColor.current

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        key = key
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = "Simulate",
                        tint = NeonPurple,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = when (currentLanguage) {
                                "uz" -> "Ogohlantirish tizimlari laboratoriyasi"
                                "ru" -> "Лаборатория систем предупреждения"
                                else -> "Warning Systems Laboratory"
                            },
                            color = contentColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = when (currentLanguage) {
                                "uz" -> "Mahalliy xabarlar va tizim bildirishnomalarini simulyatsiya qiling"
                                "ru" -> "Симуляция локальных предупреждений и пуш-уведомлений"
                                else -> "Simulate local alerts and system push warnings"
                            },
                            color = contentColor.copy(alpha = 0.5f),
                            fontSize = 11.sp
                        )
                    }
                }

                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = "Expand",
                    tint = contentColor
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                ) {
                    Text(
                        text = when (currentLanguage) {
                            "uz" -> "Quyidagi istalgan simulyatsiyani ishga tushirish ogohlantirishni mahalliy ma'lumotlar keshiga qo'shadi va bir zumda tizimli push-bildirishnomasini yuboradi."
                            "ru" -> "Запуск любой симуляции ниже добавляет предупреждение в локальный кэш базы данных и мгновенно отправляет системное пуш-уведомление."
                            else -> "Triggering any simulation below adds the alert to the local database cache and broadcasts a system push notification alert instantly."
                        },
                        color = contentColor.copy(alpha = 0.7f),
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Tornado Warning button
                        Button(
                            onClick = {
                                val tornadoTitle = when (currentLanguage) {
                                    "uz" -> "To'fon ogohlantirishi faol"
                                    "ru" -> "Активное предупреждение о торнадо"
                                    else -> "Tornado Warning active"
                                }
                                val tornadoMsg = when (currentLanguage) {
                                    "uz" -> "Ushbu sektorda kuchli to'fon boshlanishi kutilmoqda. Zudlik bilan mustahkam boshpana toping!"
                                    "ru" -> "В этом секторе зафиксировано торнадо. Немедленно укройтесь в надежном убежище!"
                                    else -> "A severe weather tornado touchdown is indicated in this sector. Seek absolute concrete shelter immediately!"
                                }
                                viewModel.simulateExtremeWeatherWarning(
                                    severity = "CRITICAL",
                                    title = tornadoTitle,
                                    message = tornadoMsg
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ExtremeRed),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(
                                text = when (currentLanguage) {
                                    "uz" -> "TO'FON"
                                    "ru" -> "ТОРНАДО"
                                    else -> "TORNADO"
                                },
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Flood Warning button
                        Button(
                            onClick = {
                                val floodTitle = when (currentLanguage) {
                                    "uz" -> "Kuchli suv toshqini ogohlantirishi"
                                    "ru" -> "Предупреждение о сильном наводнении"
                                    else -> "Severe Flash Flood warning"
                                }
                                val floodMsg = when (currentLanguage) {
                                    "uz" -> "Kuchli mintaqaviy yog'ingarchiliklar suv sathi ko'tarilishiga sabab bo'ldi. Pasttekislik va vodiylardan uzoqroq turing."
                                    "ru" -> "Интенсивные региональные ливни вызвали резкий подъем уровня воды. Избегайте низин и русел рек."
                                    else -> "Intense regional storm runoffs have induced severe structural water-logging. Avoid all valleys and low-lying pathways."
                                }
                                viewModel.simulateExtremeWeatherWarning(
                                    severity = "WARNING",
                                    title = floodTitle,
                                    message = floodMsg
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AlertOrange),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(
                                text = when (currentLanguage) {
                                    "uz" -> "TOSHQUIN"
                                    "ru" -> "НАВОДНЕНИЕ"
                                    else -> "FLASH FLOOD"
                                },
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Heatwave Warning button
                        Button(
                            onClick = {
                                val heatTitle = when (currentLanguage) {
                                    "uz" -> "Issiq havo oqimi tavsiyasi"
                                    "ru" -> "Консультация по аномальной жаре"
                                    else -> "Dynamic Heatwave Advisory"
                                }
                                val heatMsg = when (currentLanguage) {
                                    "uz" -> "Uzoq vaqt davomida haddan tashqari issiq harorat kutilmoqda. Jismoniy faollikni cheklang va ko'proq suv iching."
                                    "ru" -> "Ожидается длительная аномальная жара. Ограничьте физические нагрузки и пейте больше воды."
                                    else -> "Prolonged extreme solar indices forecast up to high thermal indexes. Restrict physical exertions and secure fluids."
                                }
                                viewModel.simulateExtremeWeatherWarning(
                                    severity = "WARNING",
                                    title = heatTitle,
                                    message = heatMsg
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SunlightYellow),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(
                                text = when (currentLanguage) {
                                    "uz" -> "ISS_IQ TO'LQINI"
                                    "ru" -> "ЖАРА"
                                    else -> "HEAT WAVE"
                                },
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Ice Warning button
                        Button(
                            onClick = {
                                val blizzardTitle = when (currentLanguage) {
                                    "uz" -> "Qor bo'roni kuzatuvi"
                                    "ru" -> "Наблюдение за метелью"
                                    else -> "Sub-Zero Blizzard Watch"
                                }
                                val blizzardMsg = when (currentLanguage) {
                                    "uz" -> "Harorat noldan past bo'lishi yo'l sirtlarini muzlatmoqda. Yo'llarda ehtiyot bo'ling."
                                    "ru" -> "Температура ниже нуля замораживает поверхности дорог. Будьте предельно осторожны при вождении."
                                    else -> "Sub-zero ambient humidity is freezing open ground surfaces. Hazardous driving condition watch is active."
                                }
                                viewModel.simulateExtremeWeatherWarning(
                                    severity = "INFO",
                                    title = blizzardTitle,
                                    message = blizzardMsg
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SkyBlue),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(
                                text = when (currentLanguage) {
                                    "uz" -> "QOR BO'RONI"
                                    "ru" -> "МЕТЕЛЬ"
                                    else -> "BLIZZARD"
                                },
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- UV Radiation Level & Advisory Component ---
@Composable
fun UvRadiationCard(weather: WeatherResponse, currentLanguage: String, key: Any? = null) {
    val daily = weather.daily ?: return
    val uvIndex = daily.uvIndexMax.firstOrNull() ?: 0.0
    val contentColor = LocalContentColor.current

    // Determine if the UV radiation levels are high (UV >= 6.0 is High/Very High/Extreme)
    val isHigh = uvIndex >= 6.0
    val greenColor = Color(0xFF10B981) // Emerald Green for Safe levels

    val classification = remember(uvIndex, currentLanguage) {
        when {
            uvIndex < 3.0 -> when (currentLanguage) {
                "uz" -> "Past"
                "ru" -> "Низкий"
                else -> "Low"
            }
            uvIndex < 6.0 -> when (currentLanguage) {
                "uz" -> "O'rtacha"
                "ru" -> "Умеренный"
                else -> "Moderate"
            }
            uvIndex < 8.0 -> when (currentLanguage) {
                "uz" -> "Yuqori"
                "ru" -> "Высокий"
                else -> "High"
            }
            uvIndex < 11.0 -> when (currentLanguage) {
                "uz" -> "Juda yuqori"
                "ru" -> "Очень высокий"
                else -> "Very High"
            }
            else -> when (currentLanguage) {
                "uz" -> "Ekstremal"
                "ru" -> "Экстремальный"
                else -> "Extreme"
            }
        }
    }

    val warningMessage = remember(isHigh, currentLanguage) {
        if (isHigh) {
            when (currentLanguage) {
                "uz" -> "Ultrabinafsha nurlanish darajasi yuqori. Uydan tashqariga chiqmang."
                "ru" -> "Высокий уровень УФ-излучения. Не выходите из дома."
                else -> "High UV radiation levels. Do not leave the house."
            }
        } else {
            when (currentLanguage) {
                "uz" -> "Ultrabinafsha nurlanish darajasi past. Tashqariga chiqish xavfsiz!"
                "ru" -> "Низкий уровень УФ-излучения. Безопасно для выхода на улицу!"
                else -> "Low UV radiation levels. Safe to go outside!"
            }
        }
    }

    val themeColor = when {
        uvIndex < 3.0 -> greenColor
        uvIndex < 6.0 -> SunlightYellow
        uvIndex < 8.0 -> AlertOrange
        else -> NeonPurple
    }

    GlassCard(
        modifier = Modifier.fillMaxWidth().testTag("uv_radiation_card"),
        key = key
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WbSunny,
                        contentDescription = "UV Radiation",
                        tint = themeColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = when (currentLanguage) {
                            "uz" -> "Ultrabinafsha nurlanish (UV)"
                            "ru" -> "УФ-излучение"
                            else -> "UV Radiation"
                        },
                        color = contentColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                // Value badge
                Surface(
                    color = themeColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, themeColor.copy(alpha = 0.3f))
                ) {
                    Text(
                        text = "$classification ($uvIndex)",
                        color = themeColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Gauge Indicator
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(contentColor.copy(alpha = 0.08f))
            ) {
                val fraction = (uvIndex / 12.0).toFloat().coerceIn(0f, 1f)
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fraction)
                        .clip(RoundedCornerShape(5.dp))
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(greenColor, SunlightYellow, AlertOrange, NeonPurple)
                            )
                        )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Message Container
            Surface(
                color = if (isHigh) AlertOrange.copy(alpha = 0.1f) else greenColor.copy(alpha = 0.08f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(
                    width = 1.dp,
                    color = if (isHigh) AlertOrange.copy(alpha = 0.25f) else greenColor.copy(alpha = 0.15f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isHigh) Icons.Default.Warning else Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = if (isHigh) AlertOrange else greenColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = warningMessage,
                        color = contentColor,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

// --- Dynamic Wind Speed & Direction Compass Indicator Component ---
@Composable
fun WindCompassCard(weather: WeatherResponse, currentLanguage: String, key: Any? = null) {
    val current = weather.current ?: return
    val daily = weather.daily
    val windDeg = current.windDirection ?: 0.0
    val windSpeed = current.windSpeed
    val maxWind = daily?.windSpeedMax?.firstOrNull() ?: windSpeed
    val contentColor = LocalContentColor.current

    val animatedRotation by animateFloatAsState(
        targetValue = windDeg.toFloat(),
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "WindRotation"
    )

    val cardinalText = WeatherUtils.getWindDirectionCardinal(windDeg, currentLanguage)

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("wind_compass_card"),
        key = key
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.Air,
                        contentDescription = "Wind Compass",
                        tint = NeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = com.example.ui.utils.WeatherLocalization.get("wind_compass", currentLanguage),
                        color = contentColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Surface(
                    color = NeonCyan.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.3f))
                ) {
                    Text(
                        text = "${windSpeed.toInt()}${com.example.ui.utils.WeatherLocalization.get("wind_unit", currentLanguage)}",
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Compass Dial Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                // Visual Compass Dial with Rotating Navigation Arrow
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .clip(CircleShape)
                        .background(contentColor.copy(alpha = 0.06f))
                        .border(1.5.dp, NeonCyan.copy(alpha = 0.35f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    // Cardinal Labels (N, E, S, W)
                    Text("N", color = contentColor.copy(alpha = 0.8f), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.TopCenter).padding(top = 4.dp))
                    Text("S", color = contentColor.copy(alpha = 0.5f), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp))
                    Text("W", color = contentColor.copy(alpha = 0.5f), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterStart).padding(start = 6.dp))
                    Text("E", color = contentColor.copy(alpha = 0.5f), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 6.dp))

                    // Dynamic Rotating Wind Heading Arrow
                    Icon(
                        imageVector = Icons.Default.Navigation,
                        contentDescription = "Wind Heading Arrow",
                        tint = NeonCyan,
                        modifier = Modifier
                            .size(38.dp)
                            .rotate(animatedRotation)
                    )
                }

                // Digital Heading Telemetry
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column {
                        Text(
                            text = com.example.ui.utils.WeatherLocalization.get("wind_direction", currentLanguage).uppercase(java.util.Locale.ROOT),
                            color = contentColor.copy(alpha = 0.4f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "$cardinalText (${windDeg.toInt()}°)",
                            color = contentColor,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Column {
                        Text(
                            text = "PEAK GUSTS TODAY",
                            color = contentColor.copy(alpha = 0.4f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${maxWind.toInt()}${com.example.ui.utils.WeatherLocalization.get("wind_unit", currentLanguage)}",
                            color = SkyBlue,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

// --- Weather Condition Probabilities for All Weather Types ---
@Composable
fun WeatherProbabilitiesCard(weather: WeatherResponse, currentLanguage: String, key: Any? = null) {
    val current = weather.current ?: return
    val daily = weather.daily
    val precipProbMax = daily?.precipitationProbabilityMax?.firstOrNull()
    val allProbabilities = remember(current.weatherCode, precipProbMax, current.cloudCover, current.windSpeed, currentLanguage) {
        WeatherUtils.getAllWeatherTypeProbabilities(
            code = current.weatherCode,
            precipProb = precipProbMax,
            cloudCover = current.cloudCover,
            windSpeed = current.windSpeed,
            lang = currentLanguage
        )
    }

    val contentColor = LocalContentColor.current

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("weather_probabilities_card"),
        key = key
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Analytics,
                    contentDescription = "Probabilities",
                    tint = SunlightYellow,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = com.example.ui.utils.WeatherLocalization.get("weather_probabilities", currentLanguage),
                    color = contentColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Probability Rows for all weather types
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                allProbabilities.forEach { probInfo ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = probInfo.icon,
                            contentDescription = null,
                            tint = probInfo.tint,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = probInfo.label,
                            color = contentColor.copy(alpha = 0.85f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.width(135.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        // Progress Bar
                        val fraction = (probInfo.percentage / 100f).coerceIn(0.04f, 1f)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(contentColor.copy(alpha = 0.08f))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(fraction)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(probInfo.tint)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        // Percentage Badge
                        Text(
                            text = "${probInfo.percentage}%",
                            color = probInfo.tint,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(36.dp),
                            textAlign = TextAlign.End
                        )
                    }
                }
            }
        }
    }
}

// --- Automatic Weather Refresh & Last Updated Live Status Component ---
@Composable
fun AutoRefreshStatusBar(
    viewModel: WeatherViewModel,
    currentLanguage: String,
    onRefresh: () -> Unit
) {
    val lastUpdatedMillis by viewModel.lastUpdatedMillis.collectAsStateWithLifecycle()
    val nextRefreshSeconds by viewModel.nextRefreshSeconds.collectAsStateWithLifecycle()

    val contentColor = LocalContentColor.current

    val elapsedSeconds = ((System.currentTimeMillis() - lastUpdatedMillis) / 1000).coerceAtLeast(0)
    val lastUpdatedText = remember(elapsedSeconds, currentLanguage) {
        val updatedLabel = com.example.ui.utils.WeatherLocalization.get("last_updated", currentLanguage)
        if (elapsedSeconds < 60) {
            "$updatedLabel: ${com.example.ui.utils.WeatherLocalization.get("just_now", currentLanguage)}"
        } else {
            val mins = (elapsedSeconds / 60).toInt()
            when (currentLanguage) {
                "uz" -> "$updatedLabel: $mins daq oldin"
                "ru" -> "$updatedLabel: $mins мин назад"
                else -> "$updatedLabel: ${mins}m ago"
            }
        }
    }

    val minutesRemaining = nextRefreshSeconds / 60
    val secondsRemaining = nextRefreshSeconds % 60
    val countdownFormatted = String.format(java.util.Locale.getDefault(), "%02d:%02d", minutesRemaining, secondsRemaining)

    val infiniteTransition = rememberInfiniteTransition(label = "SyncDotPulse")
    val dotAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "DotAlpha"
    )

    Surface(
        color = Color.White.copy(alpha = 0.07f),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("auto_refresh_status_bar")
            .clickable { onRefresh() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Live status dot & Last Updated timestamp
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(NeonCyan.copy(alpha = dotAlpha))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = lastUpdatedText,
                    color = contentColor.copy(alpha = 0.85f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Right: 15-Min Auto-refresh Countdown Timer Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .background(NeonCyan.copy(alpha = 0.14f), RoundedCornerShape(12.dp))
                    .border(0.5.dp, NeonCyan.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Schedule,
                    contentDescription = "Countdown",
                    tint = NeonCyan,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = countdownFormatted,
                    color = NeonCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

