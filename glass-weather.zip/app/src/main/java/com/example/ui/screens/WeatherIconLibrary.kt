package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import com.example.ui.utils.WeatherInfo
import kotlin.math.cos
import kotlin.math.sin

/**
 * A highly polished, dynamic vector/SVG icon library for weather states.
 * Replaces standard material icons with premium layered graphics that animate
 * based on current atmospheric conditions.
 */
@Composable
fun DynamicWeatherIcon(
    weatherInfo: WeatherInfo,
    modifier: Modifier = Modifier
) {
    // 1. Core animations triggered at Composable level
    val sunAngle = SunnyRayAnimation()
    val rainOffset = RainAnimation()
    val (snowOffset, snowDrift) = SnowAnimation()
    val isLightningActive = LightningAnimation()
    val twinkleFactor = TwinkleAnimation()

    Box(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val isDay = weatherInfo.isDay

            when {
                // 1. STORMY WEATHER
                weatherInfo.isStormy -> {
                    drawStormyIcon(width, height, isLightningActive, rainOffset)
                }
                // 2. SNOWY & RAINY (Sleet / Freezing Rain)
                weatherInfo.isSnowing && weatherInfo.isRaining -> {
                    drawSleetIcon(width, height, rainOffset, snowOffset, snowDrift)
                }
                // 3. SNOWY WEATHER
                weatherInfo.isSnowing -> {
                    drawSnowyIcon(width, height, snowOffset, snowDrift)
                }
                // 4. RAINY WEATHER
                weatherInfo.isRaining -> {
                    drawRainyIcon(width, height, rainOffset)
                }
                // 5. PARTLY CLOUDY (Sun peeking behind cloud)
                weatherInfo.description.contains("Partly Cloudy", ignoreCase = true) || 
                weatherInfo.description.contains("Mainly Clear", ignoreCase = true) -> {
                    drawPartlyCloudyIcon(width, height, isDay, sunAngle, twinkleFactor)
                }
                // 6. CLOUDY / OVERCAST / FOGGY
                weatherInfo.description.contains("Overcast", ignoreCase = true) || 
                weatherInfo.description.contains("Cloudy", ignoreCase = true) || 
                weatherInfo.description.contains("Fog", ignoreCase = true) -> {
                    drawCloudyIcon(width, height)
                }
                // 7. CLEAR SKY / SUNNY (Or Clear Night)
                else -> {
                    if (isDay) {
                        drawSunnyIcon(width, height, sunAngle)
                    } else {
                        drawNightIcon(width, height, twinkleFactor)
                    }
                }
            }
        }
    }
}

@Composable
private fun SunnyRayAnimation(): Float {
    val infiniteTransition = rememberInfiniteTransition(label = "SunRotation")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "SunAngle"
    )
    return angle
}

@Composable
private fun RainAnimation(): Float {
    val infiniteTransition = rememberInfiniteTransition(label = "RainFall")
    val offset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "RainOffset"
    )
    return offset
}

@Composable
private fun SnowAnimation(): Pair<Float, Float> {
    val infiniteTransition = rememberInfiniteTransition(label = "SnowFall")
    val offset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "SnowOffset"
    )
    val drift by infiniteTransition.animateFloat(
        initialValue = -10f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "SnowDrift"
    )
    return Pair(offset, drift)
}

@Composable
private fun TwinkleAnimation(): Float {
    val infiniteTransition = rememberInfiniteTransition(label = "StarTwinkle")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "StarAlpha"
    )
    return alpha
}

@Composable
private fun LightningAnimation(): Boolean {
    val infiniteTransition = rememberInfiniteTransition(label = "LightningFlash")
    val flashTickFloat by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 100f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "FlashTick"
    )
    val flashTick = flashTickFloat.toInt()
    return flashTick in listOf(12, 14, 45, 47, 48, 88)
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSunnyIcon(
    width: Float,
    height: Float,
    rotationAngle: Float
) {
    val center = Offset(width * 0.5f, height * 0.5f)
    val sunRadius = width * 0.25f

    // 1. Outer golden aura
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFFF9C4).copy(alpha = 0.4f), Color.Transparent),
            center = center,
            radius = sunRadius * 1.8f
        ),
        center = center,
        radius = sunRadius * 1.8f
    )

    // 2. Rotating rays (wrapped with rotation transform)
    withTransform({
        rotate(rotationAngle, center)
    }) {
        for (i in 0 until 8) {
            val angleRad = Math.toRadians((i * 45).toDouble())
            val rayStartDist = sunRadius * 1.2f
            val rayEndDist = sunRadius * 1.55f
            
            val startX = center.x + cos(angleRad).toFloat() * rayStartDist
            val startY = center.y + sin(angleRad).toFloat() * rayStartDist
            val endX = center.x + cos(angleRad).toFloat() * rayEndDist
            val endY = center.y + sin(angleRad).toFloat() * rayEndDist

            drawLine(
                color = Color(0xFFFFB300),
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = width * 0.045f,
                cap = StrokeCap.Round
            )
        }
    }

    // 3. Main Sun body (high contrast yellow gradient)
    drawCircle(
        brush = Brush.linearGradient(
            colors = listOf(Color(0xFFFFF176), Color(0xFFF57C00)),
            start = Offset(center.x - sunRadius, center.y - sunRadius),
            end = Offset(center.x + sunRadius, center.y + sunRadius)
        ),
        center = center,
        radius = sunRadius
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawNightIcon(
    width: Float,
    height: Float,
    twinkleFactor: Float
) {
    val center = Offset(width * 0.5f, height * 0.5f)
    val moonRadius = width * 0.26f

    // 1. Soft blue star glow
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFBBDEFB).copy(alpha = 0.25f), Color.Transparent),
            center = center,
            radius = moonRadius * 1.9f
        ),
        center = center,
        radius = moonRadius * 1.9f
    )

    // 2. Twinkling little stars with twinkle opacity
    val starPoints = listOf(
        Offset(width * 0.22f, height * 0.3f),
        Offset(width * 0.35f, height * 0.18f),
        Offset(width * 0.78f, height * 0.75f)
    )
    starPoints.forEachIndexed { i, pt ->
        val sizeMultiplier = if (i == 1) 1.2f else 0.8f
        val pulseAlpha = if (i == 1) twinkleFactor else (1.3f - twinkleFactor).coerceIn(0.2f, 1.0f)
        
        drawLine(
            color = Color.White.copy(alpha = 0.85f * pulseAlpha),
            start = Offset(pt.x - 6f * sizeMultiplier, pt.y),
            end = Offset(pt.x + 6f * sizeMultiplier, pt.y),
            strokeWidth = 2.5f
        )
        drawLine(
            color = Color.White.copy(alpha = 0.85f * pulseAlpha),
            start = Offset(pt.x, pt.y - 6f * sizeMultiplier),
            end = Offset(pt.x, pt.y + 6f * sizeMultiplier),
            strokeWidth = 2.5f
        )
    }

    // 3. Draw crescent moon shape using a clean subtraction path
    val moonPath = Path().apply {
        arcTo(
            rect = Rect(Offset(width * 0.24f, height * 0.24f), Size(width * 0.52f, height * 0.52f)),
            startAngleDegrees = -70f,
            sweepAngleDegrees = 160f,
            forceMoveTo = true
        )
        arcTo(
            rect = Rect(Offset(width * 0.34f, height * 0.26f), Size(width * 0.44f, height * 0.48f)),
            startAngleDegrees = 90f,
            sweepAngleDegrees = -160f,
            forceMoveTo = false
        )
        close()
    }

    drawPath(
        path = moonPath,
        brush = Brush.linearGradient(
            colors = listOf(Color(0xFFECEFF1), Color(0xFF90A4AE)),
            start = Offset(width * 0.3f, height * 0.3f),
            end = Offset(width * 0.7f, height * 0.7f)
        )
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCloudyIcon(width: Float, height: Float) {
    // Overlapping multi-cloud layer for a fully volumetric cloud design
    // 1. Back cloud
    val backCloudPath = getCloudPath(
        xOffset = width * 0.08f,
        yOffset = -height * 0.05f,
        scaleWidth = 0.75f,
        scaleHeight = 0.75f,
        width = width,
        height = height
    )
    drawPath(
        path = backCloudPath,
        brush = Brush.linearGradient(
            colors = listOf(Color(0xFFCFD8DC), Color(0xFF78909C)),
            start = Offset(0f, 0f),
            end = Offset(width, height)
        )
    )

    // 2. Front cloud
    val frontCloudPath = getCloudPath(
        xOffset = 0f,
        yOffset = height * 0.05f,
        scaleWidth = 0.82f,
        scaleHeight = 0.82f,
        width = width,
        height = height
    )
    drawPath(
        path = frontCloudPath,
        brush = Brush.linearGradient(
            colors = listOf(Color.White, Color(0xFFB0BEC5)),
            start = Offset(width * 0.2f, height * 0.2f),
            end = Offset(width * 0.8f, height * 0.8f)
        )
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawPartlyCloudyIcon(
    width: Float,
    height: Float,
    isDay: Boolean,
    rotationAngle: Float,
    twinkleFactor: Float
) {
    // 1. Sunny / Moon peeking background
    if (isDay) {
        val sunCenter = Offset(width * 0.65f, height * 0.4f)
        val sunRadius = width * 0.2f
        
        withTransform({
            rotate(rotationAngle, sunCenter)
        }) {
            // Draw peeking sun
            drawCircle(
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFFFFEE58), Color(0xFFF57C00)),
                    start = Offset(sunCenter.x - sunRadius, sunCenter.y - sunRadius),
                    end = Offset(sunCenter.x + sunRadius, sunCenter.y + sunRadius)
                ),
                center = sunCenter,
                radius = sunRadius
            )
        }
    } else {
        val moonCenter = Offset(width * 0.65f, height * 0.4f)
        val moonRadius = width * 0.18f
        val moonPath = Path().apply {
            arcTo(
                rect = Rect(Offset(moonCenter.x - moonRadius, moonCenter.y - moonRadius), Size(moonRadius * 2f, moonRadius * 2f)),
                startAngleDegrees = -70f,
                sweepAngleDegrees = 160f,
                forceMoveTo = true
            )
            arcTo(
                rect = Rect(Offset(moonCenter.x - moonRadius * 0.6f, moonCenter.y - moonRadius * 0.9f), Size(moonRadius * 1.8f, moonRadius * 1.8f)),
                startAngleDegrees = 90f,
                sweepAngleDegrees = -160f,
                forceMoveTo = false
            )
            close()
        }
        drawPath(
            path = moonPath,
            brush = Brush.linearGradient(colors = listOf(Color(0xFFECEFF1), Color(0xFF90A4AE)))
        )
    }

    // 2. Forefront fluffy white cloud
    val cloudPath = getCloudPath(
        xOffset = -width * 0.08f,
        yOffset = height * 0.08f,
        scaleWidth = 0.78f,
        scaleHeight = 0.78f,
        width = width,
        height = height
    )
    drawPath(
        path = cloudPath,
        brush = Brush.linearGradient(
            colors = listOf(Color.White, Color(0xFFECEFF1), Color(0xFFCFD8DC)),
            start = Offset(0f, height * 0.3f),
            end = Offset(width, height * 0.9f)
        )
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawRainyIcon(
    width: Float,
    height: Float,
    rainOffset: Float
) {
    // 1. Clouds
    val cloudPath = getCloudPath(
        xOffset = 0f,
        yOffset = -height * 0.06f,
        scaleWidth = 0.8f,
        scaleHeight = 0.8f,
        width = width,
        height = height
    )
    drawPath(
        path = cloudPath,
        brush = Brush.linearGradient(
            colors = listOf(Color(0xFFB0BEC5), Color(0xFF546E7A)),
            start = Offset(0f, 0f),
            end = Offset(width, height)
        )
    )

    // 2. Clean structural animated raindrop lines
    val rainDropX = listOf(width * 0.32f, width * 0.45f, width * 0.58f, width * 0.7f)
    val rainDropYBase = height * 0.62f
    val verticalSpan = height * 0.15f
    
    rainDropX.forEachIndexed { idx, rx ->
        val staggerY = if (idx % 2 == 0) 0f else height * 0.05f
        
        // Loop the rain drops smoothly using offset
        val animatedProgressY = (rainOffset + (idx * 0.25f)) % 1f
        val startY = rainDropYBase + staggerY + (animatedProgressY * verticalSpan)
        val endY = startY + height * 0.08f

        // Only draw if within bounds under cloud
        if (startY < height * 0.92f) {
            drawLine(
                color = Color(0xFF29B6F6),
                start = Offset(rx, startY),
                end = Offset(rx - width * 0.02f, endY),
                strokeWidth = width * 0.02f,
                cap = StrokeCap.Round
            )
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSnowyIcon(
    width: Float,
    height: Float,
    snowOffset: Float,
    snowDrift: Float
) {
    // 1. Clouds
    val cloudPath = getCloudPath(
        xOffset = 0f,
        yOffset = -height * 0.06f,
        scaleWidth = 0.8f,
        scaleHeight = 0.8f,
        width = width,
        height = height
    )
    drawPath(
        path = cloudPath,
        brush = Brush.linearGradient(
            colors = listOf(Color(0xFFECEFF1), Color(0xFF90A4AE)),
            start = Offset(0f, 0f),
            end = Offset(width, height)
        )
    )

    // 2. Detailed drifting animated snowflakes
    val snowflakeBaseCoords = listOf(
        Offset(width * 0.35f, height * 0.64f),
        Offset(width * 0.5f, height * 0.68f),
        Offset(width * 0.65f, height * 0.64f)
    )

    val verticalSpan = height * 0.16f

    snowflakeBaseCoords.forEachIndexed { idx, pt ->
        val animatedProgressY = (snowOffset + (idx * 0.33f)) % 1f
        val currentY = pt.y + (animatedProgressY * verticalSpan)
        val currentX = pt.x + (snowDrift * 0.5f)

        if (currentY < height * 0.94f) {
            drawSnowflake(Offset(currentX, currentY), width * 0.055f)
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSleetIcon(
    width: Float,
    height: Float,
    rainOffset: Float,
    snowOffset: Float,
    snowDrift: Float
) {
    // 1. Dark cloudy sky backing
    val cloudPath = getCloudPath(
        xOffset = 0f,
        yOffset = -height * 0.06f,
        scaleWidth = 0.8f,
        scaleHeight = 0.8f,
        width = width,
        height = height
    )
    drawPath(
        path = cloudPath,
        brush = Brush.linearGradient(
            colors = listOf(Color(0xFF78909C), Color(0xFF37474F)),
            start = Offset(0f, 0f),
            end = Offset(width, height)
        )
    )

    // 2. Mix of animated rain and snowflakes
    // Left rain drop
    val rainProgY = (rainOffset + 0.1f) % 1f
    val rY = height * 0.62f + (rainProgY * height * 0.15f)
    drawLine(
        color = Color(0xFF29B6F6),
        start = Offset(width * 0.32f, rY),
        end = Offset(width * 0.29f, rY + height * 0.08f),
        strokeWidth = width * 0.018f,
        cap = StrokeCap.Round
    )

    // Right rain drop
    val rainProgY2 = (rainOffset + 0.6f) % 1f
    val rY2 = height * 0.62f + (rainProgY2 * height * 0.15f)
    drawLine(
        color = Color(0xFF29B6F6),
        start = Offset(width * 0.68f, rY2),
        end = Offset(width * 0.65f, rY2 + height * 0.08f),
        strokeWidth = width * 0.018f,
        cap = StrokeCap.Round
    )

    // Center snow star
    val snowProgY = (snowOffset + 0.4f) % 1f
    val sY = height * 0.64f + (snowProgY * height * 0.16f)
    val sX = width * 0.5f + (snowDrift * 0.4f)
    drawSnowflake(Offset(sX, sY), width * 0.05f)
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawStormyIcon(
    width: Float,
    height: Float,
    isLightningActive: Boolean,
    rainOffset: Float
) {
    // 1. Dark storm clouds
    val cloudPath = getCloudPath(
        xOffset = 0f,
        yOffset = -height * 0.06f,
        scaleWidth = 0.8f,
        scaleHeight = 0.8f,
        width = width,
        height = height
    )
    drawPath(
        path = cloudPath,
        brush = Brush.linearGradient(
            colors = if (isLightningActive) {
                listOf(Color(0xFF78909C), Color(0xFF3F51B5)) // lightning flash glow on clouds
            } else {
                listOf(Color(0xFF37474F), Color(0xFF1A237E))
            },
            start = Offset(0f, 0f),
            end = Offset(width, height)
        )
    )

    // 2. Rain in storm
    val rainDropX = listOf(width * 0.35f, width * 0.65f)
    val rainDropYBase = height * 0.62f
    rainDropX.forEachIndexed { idx, rx ->
        val animatedProgressY = (rainOffset + (idx * 0.5f)) % 1f
        val startY = rainDropYBase + (animatedProgressY * height * 0.15f)
        val endY = startY + height * 0.07f

        drawLine(
            color = Color(0xFF0288D1).copy(alpha = 0.7f),
            start = Offset(rx, startY),
            end = Offset(rx - width * 0.02f, endY),
            strokeWidth = width * 0.016f,
            cap = StrokeCap.Round
        )
    }

    // 3. Bold flashing yellow vector lightning bolt
    if (isLightningActive || true) { // Always draw but make it extremely vibrant during flash
        val boltAlpha = if (isLightningActive) 1.0f else 0.85f
        val boltPath = Path().apply {
            moveTo(width * 0.52f, height * 0.53f)
            lineTo(width * 0.43f, height * 0.70f)
            lineTo(width * 0.51f, height * 0.70f)
            lineTo(width * 0.41f, height * 0.90f)
            lineTo(width * 0.61f, height * 0.65f)
            lineTo(width * 0.52f, height * 0.65f)
            close()
        }

        drawPath(
            path = boltPath,
            brush = Brush.linearGradient(
                colors = if (isLightningActive) {
                    listOf(Color(0xFFFFFFFF), Color(0xFFFFEB3B), Color(0xFFFF6F00))
                } else {
                    listOf(Color(0xFFFFEE58), Color(0xFFFFB300))
                },
                start = Offset(width * 0.4f, height * 0.53f),
                end = Offset(width * 0.6f, height * 0.90f)
            ),
            alpha = boltAlpha
        )
    }
}

/**
 * Helper to build a clean SVG-style vector cloud path of any scale/offset.
 */
private fun getCloudPath(
    xOffset: Float,
    yOffset: Float,
    scaleWidth: Float,
    scaleHeight: Float,
    width: Float,
    height: Float
): Path {
    val cloudPath = Path()
    
    // Scale baseline coordinates
    val baseStartX = width * 0.25f
    val baseStartY = height * 0.62f
    val baseEndX = width * 0.75f
    
    cloudPath.moveTo(baseStartX * scaleWidth + xOffset, baseStartY * scaleHeight + yOffset)
    
    // Bottom line to right side
    cloudPath.lineTo(baseEndX * scaleWidth + xOffset, baseStartY * scaleHeight + yOffset)
    
    // Right bulge
    cloudPath.cubicTo(
        (width * 0.88f) * scaleWidth + xOffset, (height * 0.62f) * scaleWidth + yOffset,
        (width * 0.88f) * scaleWidth + xOffset, (height * 0.42f) * scaleHeight + yOffset,
        (width * 0.75f) * scaleWidth + xOffset, (height * 0.42f) * scaleHeight + yOffset
    )
    
    // Top center bulge
    cloudPath.cubicTo(
        (width * 0.70f) * scaleWidth + xOffset, (height * 0.18f) * scaleHeight + yOffset,
        (width * 0.45f) * scaleWidth + xOffset, (height * 0.18f) * scaleHeight + yOffset,
        (width * 0.45f) * scaleWidth + xOffset, (height * 0.38f) * scaleHeight + yOffset
    )
    
    // Left bulge
    cloudPath.cubicTo(
        (width * 0.30f) * scaleWidth + xOffset, (height * 0.32f) * scaleHeight + yOffset,
        (width * 0.12f) * scaleWidth + xOffset, (height * 0.42f) * scaleHeight + yOffset,
        baseStartX * scaleWidth + xOffset, baseStartY * scaleHeight + yOffset
    )
    
    cloudPath.close()
    return cloudPath
}

/**
 * Draws a beautiful 6-axis clean snowflake vector.
 */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSnowflake(center: Offset, size: Float) {
    for (i in 0 until 3) {
        val angleRad = Math.toRadians((i * 60).toDouble())
        val dx = cos(angleRad).toFloat() * size
        val dy = sin(angleRad).toFloat() * size

        drawLine(
            color = Color.White.copy(alpha = 0.9f),
            start = Offset(center.x - dx, center.y - dy),
            end = Offset(center.x + dx, center.y + dy),
            strokeWidth = size * 0.18f,
            cap = StrokeCap.Round
        )
    }

    // Small decorative center ring
    drawCircle(
        color = Color(0xFFE3F2FD),
        radius = size * 0.25f,
        center = center,
        style = Stroke(width = size * 0.12f)
    )
}
