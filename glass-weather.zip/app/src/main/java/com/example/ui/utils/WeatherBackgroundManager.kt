package com.example.ui.utils

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

/**
 * WeatherTheme represents a highly curated visual design state for the atmospheric background.
 * It contains all parameters required to build beautiful, fluid Canvas-based gradients,
 * movement patterns, and custom particles mimicking high-fidelity CSS and WebGL shaders.
 */
enum class WeatherTheme(
    val description: String,
    val baseGradientColors: List<Color>,
    val speedMultiplier: Float,
    val particleCount: Int,
    val overlayAlpha: Float,
    val glowColor: Color,
    val vignetteStrength: Float,
    val scaleFactor: Float
) {
    SUNNY(
        description = "Sunny/Clear Day",
        baseGradientColors = listOf(Color(0xFF0284C7), Color(0xFF38BDF8), Color(0xFFBAE6FD)),
        speedMultiplier = 1.0f,
        particleCount = 4, // Heat wave / sunbeam paths
        overlayAlpha = 0.05f,
        glowColor = Color(0xFFFEF08A),
        vignetteStrength = 0.10f,
        scaleFactor = 1.0f
    ),
    SUNSET(
        description = "Sunset / Golden Hour",
        baseGradientColors = listOf(Color(0xFF311B92), Color(0xFF880E4F), Color(0xFFE65100), Color(0xFFFFB300)),
        speedMultiplier = 0.8f,
        particleCount = 6,
        overlayAlpha = 0.08f,
        glowColor = Color(0xFFFDE047),
        vignetteStrength = 0.20f,
        scaleFactor = 1.0f
    ),
    CLOUDY(
        description = "Cloudy/Overcast",
        baseGradientColors = listOf(Color(0xFF334155), Color(0xFF64748B), Color(0xFF94A3B8)),
        speedMultiplier = 0.4f,
        particleCount = 6, // Cloud mist bands
        overlayAlpha = 0.08f,
        glowColor = Color.White,
        vignetteStrength = 0.20f,
        scaleFactor = 1.05f
    ),
    FOGGY(
        description = "Fog/Mist/Haze",
        baseGradientColors = listOf(Color(0xFF37474F), Color(0xFF546E7A), Color(0xFF78909C)),
        speedMultiplier = 0.3f,
        particleCount = 8,
        overlayAlpha = 0.12f,
        glowColor = Color(0xFFECEFF1),
        vignetteStrength = 0.25f,
        scaleFactor = 1.05f
    ),
    RAINY(
        description = "Rainy/Showers",
        baseGradientColors = listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF334155)),
        speedMultiplier = 2.2f,
        particleCount = 35, // Rain streaks
        overlayAlpha = 0.15f,
        glowColor = Color(0xFF38BDF8),
        vignetteStrength = 0.30f,
        scaleFactor = 0.95f
    ),
    STORMY(
        description = "Stormy/Thunderstorms",
        baseGradientColors = listOf(Color(0xFF090D16), Color(0xFF1E1B4B), Color(0xFF312E81)),
        speedMultiplier = 4.5f,
        particleCount = 45, // Active storm vectors
        overlayAlpha = 0.25f,
        glowColor = Color(0xFFC084FC),
        vignetteStrength = 0.40f,
        scaleFactor = 0.9f
    ),
    SNOWY(
        description = "Snowy/Winter",
        baseGradientColors = listOf(Color(0xFF1E293B), Color(0xFF475569), Color(0xFF94A3B8)),
        speedMultiplier = 0.7f,
        particleCount = 30, // Snowflakes
        overlayAlpha = 0.18f,
        glowColor = Color.White,
        vignetteStrength = 0.18f,
        scaleFactor = 1.05f
    ),
    NIGHT(
        description = "Clear Starry Night",
        baseGradientColors = listOf(Color(0xFF020617), Color(0xFF0B132B), Color(0xFF1C2541)),
        speedMultiplier = 0.5f,
        particleCount = 45, // Twinkling stars
        overlayAlpha = 0.25f,
        glowColor = Color(0xFF60A5FA),
        vignetteStrength = 0.35f,
        scaleFactor = 1.0f
    ),
    NIGHT_CLOUDY(
        description = "Cloudy Night",
        baseGradientColors = listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF273549)),
        speedMultiplier = 0.4f,
        particleCount = 12,
        overlayAlpha = 0.25f,
        glowColor = Color(0xFF94A3B8),
        vignetteStrength = 0.35f,
        scaleFactor = 1.0f
    )
}

/**
 * WeatherBackgroundManager orchestrates the runtime state, interpolations, and animations
 * for the dynamic atmospheric background based on the current weather condition.
 */
object WeatherBackgroundManager {

    /**
     * Resolves the appropriate WeatherTheme given a WeatherInfo object.
     */
    fun resolveTheme(weatherInfo: WeatherInfo): WeatherTheme {
        val desc = weatherInfo.description.lowercase()
        val isSunsetOrSunrise = desc.contains("sunset") || desc.contains("sunrise") || desc.contains("dawn") || desc.contains("dusk") || desc.contains("golden")

        return when {
            weatherInfo.isStormy -> WeatherTheme.STORMY
            weatherInfo.isSnowing -> WeatherTheme.SNOWY
            weatherInfo.isRaining -> WeatherTheme.RAINY
            isSunsetOrSunrise -> WeatherTheme.SUNSET
            !weatherInfo.isDay -> {
                if (weatherInfo.isCloudy || weatherInfo.isFoggy) WeatherTheme.NIGHT_CLOUDY else WeatherTheme.NIGHT
            }
            weatherInfo.isFoggy -> WeatherTheme.FOGGY
            weatherInfo.isCloudy -> WeatherTheme.CLOUDY
            else -> WeatherTheme.SUNNY
        }
    }

    /**
     * Animate and interpolate all visual parameters between different themes.
     * This ensures fluid transitions (comparable to CSS ease-in-out / keyframes) when switching cities.
     */
    @Composable
    fun animateThemeState(theme: WeatherTheme): AnimatedThemeState {
        // Interpolate the gradient colors
        val colors = theme.baseGradientColors
        val c1 by animateColorAsState(targetValue = colors[0], animationSpec = tween(2500), label = "ThemeC1")
        val c2 by animateColorAsState(targetValue = colors.getOrElse(1) { colors[0] }, animationSpec = tween(2500), label = "ThemeC2")
        val c3 by animateColorAsState(targetValue = colors.getOrElse(2) { colors.getOrNull(1) ?: colors[0] }, animationSpec = tween(2500), label = "ThemeC3")

        // Interpolate physics multipliers
        val speed by animateFloatAsState(targetValue = theme.speedMultiplier, animationSpec = tween(1500, easing = LinearOutSlowInEasing), label = "ThemeSpeed")
        val particleDensity by animateFloatAsState(targetValue = theme.particleCount.toFloat(), animationSpec = tween(1500), label = "ThemeDensity")
        val overlayOpacity by animateFloatAsState(targetValue = theme.overlayAlpha, animationSpec = tween(2000), label = "ThemeOpacity")
        val vignette by animateFloatAsState(targetValue = theme.vignetteStrength, animationSpec = tween(2000), label = "ThemeVignette")
        val scale by animateFloatAsState(targetValue = theme.scaleFactor, animationSpec = tween(2000, easing = FastOutSlowInEasing), label = "ThemeScale")

        return remember(c1, c2, c3, speed, particleDensity, overlayOpacity, vignette, scale) {
            AnimatedThemeState(
                color1 = c1,
                color2 = c2,
                color3 = c3,
                speed = speed,
                particleCount = particleDensity.toInt(),
                overlayAlpha = overlayOpacity,
                vignetteStrength = vignette,
                scaleFactor = scale,
                offset = 0f
            )
        }
    }
}

/**
 * AnimatedThemeState holds the fully-interpolated animation values at any given frame.
 */
data class AnimatedThemeState(
    val color1: Color,
    val color2: Color,
    val color3: Color,
    val speed: Float,
    val particleCount: Int,
    val overlayAlpha: Float,
    val vignetteStrength: Float,
    val scaleFactor: Float,
    val offset: Float
)
