package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Vibrant Palette - Deep Dark Obsidian & High-Contrast Electric Neon
val DarkBackground = Color(0xFF050810) // Ultra deep obsidian blue-black
val DarkSurface = Color(0xFF0E1324)     // Dark navy slate container background
val DarkSurfaceGlass = Color(0x0DFFFFFF) // Transluncet white glass (white/5)
val GlassBorder = Color(0x1AFFFFFF)      // Pure crystalline border (white/10)
val GlassBorderHighlight = Color(0x33FFFFFF) // Bright rim accent (white/20)

// Vibrant Accent Colors representing physical weather dynamics
val SunlightYellow = Color(0xFFFBBF24) // Bright sun yellow
val SkyBlue = Color(0xFF60A5FA)        // Vibrant electric blue-400
val RainCyan = Color(0xFF22D3EE)       // Luminous cyan-400
val SnowWhite = Color(0xFFF8FAFC)      // Crisp slate white-50
val StormViolet = Color(0xFF818CF8)    // Indigo storm-400
val ExtremeRed = Color(0xFFEF4444)     // Alert red-500
val AlertOrange = Color(0xFFF59E0B)    // Alert amber-500
val InfoBlue = Color(0xFF3B82F6)       // Primary blue-600

// Neon Highlights for active visual glowing state-feedback
val NeonCyan = Color(0xFF22D3EE)
val NeonPurple = Color(0xFFC084FC)
val NeonBlue = Color(0xFF60A5FA)

// Material 3 Compatibility Fallback Palette
val Purple80 = Color(0xFFC084FC)
val PurpleGrey80 = Color(0xFFCBD5E1)
val Pink80 = Color(0xFFFDA4AF)
val Purple40 = Color(0xFF818CF8)
val PurpleGrey40 = Color(0xFF64748B)
val Pink40 = Color(0xFFF43F5E)
