package com.example.ui.utils

object WeatherLocalization {
    private val translations = mapOf(
        "en" to mapOf(
            "app_title" to "Glass Weather",
            "search_placeholder" to "Search districts, cities, villages...",
            "seven_day_forecast" to "7-Day Wave Horizon Forecast",
            "hourly_forecast" to "Hourly Fluid Temperature Wave",
            "radar_simulation" to "Radar Simulation Map",
            "simulation_console" to "Simulation Alerts Console",
            "sweep_rad" to "SWEEP RAD: 350 KM",
            "live_radar_scanning" to "LIVE RADAR SCANNING",
            "show_precipitation" to "Precipitation Overlay",
            "zoom" to "Zoom",
            "today" to "Today",
            "apparent" to "Apparent",
            "humidity" to "Humidity",
            "wind_speed" to "Wind",
            "air_pressure" to "Pressure",
            "cloud_cover" to "Cloud",
            "uv_index" to "UV Index",
            "sunrise" to "Sunrise",
            "sunset" to "Sunset",
            "rain" to "Rain",
            "day_wave" to "Day Wave",
            "night_wave" to "Night Wave",
            "active_alerts" to "Active Severe Alerts",
            "no_alerts" to "No severe weather alerts active for this area.",
            "quick_locations" to "Quick Location Selector",
            "recent_searches" to "Recent Searches",
            "generate_sim_alert" to "Generate Sim Alert",
            "mark_as_read" to "Marked as Read",
            "radar_sweep_controls" to "Radar sweep controls",
            "zoom_in" to "Zoom in",
            "zoom_out" to "Zoom out",
            "temp_unit" to "°C",
            "wind_unit" to " km/h",
            "pressure_unit" to " hPa",
            "percent_unit" to "%",
            "wind_direction" to "Wind Heading",
            "weather_probabilities" to "Weather Condition Probabilities",
            "rain_probability" to "Rain Probability",
            "snow_probability" to "Snow Probability",
            "clear_sky_probability" to "Clear Sky Probability",
            "cloud_probability" to "Cloud Cover Probability",
            "storm_probability" to "Thunderstorm Probability",
            "wind_gust_probability" to "High Wind Probability",
            "wind_compass" to "Dynamic Wind Compass",
            "last_updated" to "Updated",
            "next_refresh" to "Next refresh in",
            "just_now" to "Just now",
            "refreshing" to "Refreshing weather..."
        ),
        "uz" to mapOf(
            "app_title" to "Oyna Ob-havo",
            "search_placeholder" to "Tuman, shahar, qishloqlarni qidirish...",
            "seven_day_forecast" to "7 kunlik ob-havo ufqi",
            "hourly_forecast" to "Soatbay harorat o'zgarishi",
            "radar_simulation" to "Radar simulyatsiya xaritasi",
            "simulation_console" to "Simulyatsiya xabarlari konsoli",
            "sweep_rad" to "RADAR DOIRASI: 350 KM",
            "live_radar_scanning" to "JONLI RADAR QIDIRUV",
            "show_precipitation" to "Yog'ingarchilik qatlami",
            "zoom" to "Kattalashtirish",
            "today" to "Bugun",
            "apparent" to "Tashqi tuyulish",
            "humidity" to "Namlik",
            "wind_speed" to "Shamol",
            "air_pressure" to "Bosim",
            "cloud_cover" to "Bulutlilik",
            "uv_index" to "UV Indeksi",
            "sunrise" to "Chiqishi",
            "sunset" to "Botishi",
            "rain" to "Yomg'ir",
            "day_wave" to "Kunduzgi to'lqin",
            "night_wave" to "Tungi to'lqin",
            "active_alerts" to "Xavfli ob-havo ogohlantirishlari",
            "no_alerts" to "Ushbu hududda hech qanday xavfli ogohlantirishlar mavjud emas.",
            "quick_locations" to "Tezkor joylashuvni tanlash",
            "recent_searches" to "Oxirgi qidiruvlar",
            "generate_sim_alert" to "Sim xabarini yaratish",
            "mark_as_read" to "O'qilgan",
            "radar_sweep_controls" to "Radar sozlamalari",
            "zoom_in" to "Yaqinlashtirish",
            "zoom_out" to "Uzoqlashtirish",
            "temp_unit" to "°C",
            "wind_unit" to " km/s",
            "pressure_unit" to " gPa",
            "percent_unit" to "%",
            "wind_direction" to "Shamol Yo'nalishi",
            "weather_probabilities" to "Ob-havo Ehtimolliklari",
            "rain_probability" to "Yomg'ir Ehtimoli",
            "snow_probability" to "Qor Yog'ishi Ehtimoli",
            "clear_sky_probability" to "Ochiq Osmon Ehtimoli",
            "cloud_probability" to "Bulutlilik Ehtimoli",
            "storm_probability" to "Momaqaldiroq Ehtimoli",
            "wind_gust_probability" to "Kuchli Shamol Ehtimoli",
            "wind_compass" to "Jonli Shamol Kompasi",
            "last_updated" to "Yangilandi",
            "next_refresh" to "Keyingi yangilanish",
            "just_now" to "Hozirgina",
            "refreshing" to "Ma'lumotlar yangilanmoqda..."
        ),
        "ru" to mapOf(
            "app_title" to "Стеклянная Погода",
            "search_placeholder" to "Поиск районов, городов, сел...",
            "seven_day_forecast" to "Прогноз погоды на 7 дней",
            "hourly_forecast" to "Почасовое изменение температуры",
            "radar_simulation" to "Карта симуляции радара",
            "simulation_console" to "Консоль симуляции тревог",
            "sweep_rad" to "РАДИУС ОБХОДА: 350 КМ",
            "live_radar_scanning" to "ЖИВОЕ СКАНИРОВАНИЕ РАДАРА",
            "show_precipitation" to "Слой осадков",
            "zoom" to "Масштаб",
            "today" to "Сегодня",
            "apparent" to "Ощущается",
            "humidity" to "Влажность",
            "wind_speed" to "Ветер",
            "air_pressure" to "Давление",
            "cloud_cover" to "Облачность",
            "uv_index" to "УФ-индекс",
            "sunrise" to "Восход",
            "sunset" to "Закат",
            "rain" to "Дождь",
            "day_wave" to "Дневная волна",
            "night_wave" to "Ночная волна",
            "active_alerts" to "Активные опасные тревоги",
            "no_alerts" to "В этом районе нет активных предупреждений.",
            "quick_locations" to "Быстрый выбор локации",
            "recent_searches" to "История поиска",
            "generate_sim_alert" to "Создать симуляцию",
            "mark_as_read" to "Прочитано",
            "radar_sweep_controls" to "Управление радаром",
            "zoom_in" to "Приблизить",
            "zoom_out" to "Отдалить",
            "temp_unit" to "°C",
            "wind_unit" to " км/ч",
            "pressure_unit" to " гПа",
            "percent_unit" to "%",
            "wind_direction" to "Направление Ветра",
            "weather_probabilities" to "Вероятности Погодных Условий",
            "rain_probability" to "Вероятность Дождя",
            "snow_probability" to "Вероятность Снега",
            "clear_sky_probability" to "Вероятность Ясного Неба",
            "cloud_probability" to "Вероятность Облачности",
            "storm_probability" to "Вероятность Грозы",
            "wind_gust_probability" to "Вероятность Сильного Ветра",
            "wind_compass" to "Динамический Компас Ветра",
            "last_updated" to "Обновлено",
            "next_refresh" to "Авто-обновление через",
            "just_now" to "Только что",
            "refreshing" to "Обновление данных..."
        )
    )

    fun get(key: String, lang: String): String {
        return translations[lang]?.get(key) ?: translations["en"]?.get(key) ?: key
    }

    fun getWeatherDescription(code: Int, lang: String): String {
        return when (lang) {
            "uz" -> when (code) {
                0 -> "Musaffo osmon"
                1 -> "Asosan ochiq"
                2 -> "Qisman bulutli"
                3 -> "Bulutli"
                45, 48 -> "Tumanli ob-havo"
                51, 53, 55 -> "Yengil maydalagan yomg'ir"
                56, 57 -> "Muzli maydalagan yomg'ir"
                61, 63 -> "O'rtacha yomg'ir"
                65 -> "Kuchli yomg'ir"
                66, 67 -> "Muzli yomg'ir"
                71 -> "Yengil qor yog'ishi"
                73 -> "O'rtacha qor yog'ishi"
                75 -> "Kuchli bo'ron"
                80, 81, 82 -> "Yomg'ir jala"
                85, 86 -> "Qor jala"
                95, 96, 99 -> "Kuchli momaqaldiroq"
                else -> "Noma'lum ob-havo"
            }
            "ru" -> when (code) {
                0 -> "Ясное небо"
                1 -> "Преимущественно ясно"
                2 -> "Переменная облачность"
                3 -> "Пасмурно"
                45, 48 -> "Туман"
                51, 53, 55 -> "Легкая морось"
                56, 57 -> "Замерзающая морось"
                61, 63 -> "Умеренный дождь"
                65 -> "Сильный дождь"
                66, 67 -> "Ледяной дождь"
                71 -> "Легкий снегопад"
                73 -> "Умеренный снегопад"
                75 -> "Сильная метель"
                80, 81, 82 -> "Ливневый дождь"
                85, 86 -> "Ливневый снегопад"
                95, 96, 99 -> "Сильные грозы"
                else -> "Неизвестная погода"
            }
            else -> when (code) {
                0 -> "Clear Sky"
                1, 2, 3 -> when (code) {
                    1 -> "Mainly Clear"
                    2 -> "Partly Cloudy"
                    else -> "Overcast"
                }
                45, 48 -> "Foggy Conditions"
                51, 53, 55 -> "Light Drizzle"
                56, 57 -> "Freezing Drizzle"
                61, 63 -> "Moderate Rain"
                65 -> "Heavy Rain"
                66, 67 -> "Freezing Rain"
                71, 73, 75 -> when (code) {
                    71 -> "Light Snowfall"
                    73 -> "Moderate Snowfall"
                    else -> "Heavy Blizzard"
                }
                80, 81, 82 -> "Rain Showers"
                85, 86 -> "Snow Showers"
                95, 96, 99 -> "Severe Thunderstorms"
                else -> "Unknown Weather"
            }
        }
    }
}
