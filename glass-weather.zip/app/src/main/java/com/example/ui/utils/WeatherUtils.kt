package com.example.ui.utils

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.theme.*

data class WeatherInfo(
    val description: String,
    val icon: ImageVector,
    val isRaining: Boolean = false,
    val isSnowing: Boolean = false,
    val isStormy: Boolean = false,
    val isDay: Boolean = true,
    val iconColor: Color,
    val ambientColors: List<Color>
) {
    val isCloudy: Boolean get() = description.contains("Cloud", ignoreCase = true) || description.contains("Overcast", ignoreCase = true)
    val isFoggy: Boolean get() = description.contains("Fog", ignoreCase = true) || description.contains("Mist", ignoreCase = true) || description.contains("Haze", ignoreCase = true)
    val isClear: Boolean get() = description.contains("Clear", ignoreCase = true) || description.contains("Sun", ignoreCase = true) || description.contains("Fair", ignoreCase = true)
}

object WeatherUtils {
    /**
     * Maps WMO weather codes to user-friendly display info, custom dynamic colors, and animation metadata.
     */
    fun getWeatherInfo(code: Int, isDay: Boolean = true): WeatherInfo {
        return when (code) {
            0 -> WeatherInfo(
                description = "Clear Sky",
                icon = if (isDay) Icons.Outlined.WbSunny else Icons.Outlined.NightsStay,
                isDay = isDay,
                iconColor = if (isDay) SunlightYellow else NeonBlue,
                ambientColors = if (isDay) listOf(Color(0xFF0284C7), Color(0xFF38BDF8), Color(0xFFBAE6FD)) else listOf(Color(0xFF020617), Color(0xFF0B132B), Color(0xFF1C2541))
            )
            1 -> WeatherInfo(
                description = "Mainly Clear",
                icon = if (isDay) Icons.Outlined.WbSunny else Icons.Outlined.NightsStay,
                isDay = isDay,
                iconColor = if (isDay) SunlightYellow else SkyBlue,
                ambientColors = if (isDay) listOf(Color(0xFF0369A1), Color(0xFF0EA5E9), Color(0xFFE0F2FE)) else listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF334155))
            )
            2 -> WeatherInfo(
                description = "Partly Cloudy",
                icon = if (isDay) Icons.Outlined.WbCloudy else Icons.Outlined.NightsStay,
                isDay = isDay,
                iconColor = if (isDay) SunlightYellow else SkyBlue,
                ambientColors = if (isDay) listOf(Color(0xFF0284C7), Color(0xFF38BDF8), Color(0xFF94A3B8)) else listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF475569))
            )
            3 -> WeatherInfo(
                description = "Overcast",
                icon = Icons.Outlined.Cloud,
                isDay = isDay,
                iconColor = SkyBlue,
                ambientColors = if (isDay) listOf(Color(0xFF334155), Color(0xFF64748B), Color(0xFF94A3B8)) else listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF334155))
            )
            45, 48 -> WeatherInfo(
                description = "Foggy Conditions",
                icon = Icons.Outlined.Air,
                isDay = isDay,
                iconColor = SkyBlue,
                ambientColors = listOf(Color(0xFF37474F), Color(0xFF546E7A), Color(0xFF78909C))
            )
            51, 53, 55 -> WeatherInfo(
                description = "Light Drizzle",
                icon = Icons.Outlined.Grain,
                isRaining = true,
                isDay = isDay,
                iconColor = RainCyan,
                ambientColors = listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF38BDF8))
            )
            56, 57 -> WeatherInfo(
                description = "Freezing Drizzle",
                icon = Icons.Outlined.SevereCold,
                isSnowing = true,
                isDay = isDay,
                iconColor = SnowWhite,
                ambientColors = listOf(Color(0xFF1E293B), Color(0xFF475569), Color(0xFF94A3B8))
            )
            61, 63 -> WeatherInfo(
                description = "Moderate Rain",
                icon = Icons.Outlined.WaterDrop,
                isRaining = true,
                isDay = isDay,
                iconColor = RainCyan,
                ambientColors = listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF334155))
            )
            65 -> WeatherInfo(
                description = "Heavy Rain",
                icon = Icons.Outlined.Umbrella,
                isRaining = true,
                isDay = isDay,
                iconColor = RainCyan,
                ambientColors = listOf(Color(0xFF090D16), Color(0xFF0F172A), Color(0xFF1E293B))
            )
            66, 67 -> WeatherInfo(
                description = "Freezing Rain",
                icon = Icons.Outlined.AcUnit,
                isRaining = true,
                isSnowing = true,
                isDay = isDay,
                iconColor = SnowWhite,
                ambientColors = listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF475569))
            )
            71, 73, 75 -> WeatherInfo(
                description = when (code) {
                    71 -> "Light Snowfall"
                    73 -> "Moderate Snowfall"
                    else -> "Heavy Blizzard"
                },
                icon = Icons.Outlined.AcUnit,
                isSnowing = true,
                isDay = isDay,
                iconColor = SnowWhite,
                ambientColors = listOf(Color(0xFF1E293B), Color(0xFF475569), Color(0xFF94A3B8))
            )
            80, 81, 82 -> WeatherInfo(
                description = "Rain Showers",
                icon = Icons.Outlined.WaterDrop,
                isRaining = true,
                isDay = isDay,
                iconColor = SkyBlue,
                ambientColors = listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF38BDF8))
            )
            85, 86 -> WeatherInfo(
                description = "Snow Showers",
                icon = Icons.Outlined.AcUnit,
                isSnowing = true,
                isDay = isDay,
                iconColor = SnowWhite,
                ambientColors = listOf(Color(0xFF1E293B), Color(0xFF475569), Color(0xFFCBD5E1))
            )
            95, 96, 99 -> WeatherInfo(
                description = "Severe Thunderstorms",
                icon = Icons.Outlined.Thunderstorm,
                isRaining = true,
                isStormy = true,
                isDay = isDay,
                iconColor = StormViolet,
                ambientColors = listOf(Color(0xFF090D16), Color(0xFF1E1B4B), Color(0xFF312E81))
            )
            else -> WeatherInfo(
                description = "Unknown Weather",
                icon = Icons.Outlined.QuestionMark,
                isDay = isDay,
                iconColor = SkyBlue,
                ambientColors = listOf(Color(0xFF0F172A), Color(0xFF1E293B))
            )
        }
    }

    /**
     * Converts degrees (0-360) to cardinal direction and localized label (e.g. SW, NNE, East).
     */
    fun getWindDirectionCardinal(degree: Double, lang: String = "en"): String {
        val normalized = (degree % 360 + 360) % 360
        return when (lang) {
            "uz" -> when {
                normalized >= 337.5 || normalized < 22.5 -> "Shimal (N)"
                normalized < 67.5 -> "Shimali-Sharq (NE)"
                normalized < 112.5 -> "Sharq (E)"
                normalized < 157.5 -> "Janubi-Sharq (SE)"
                normalized < 202.5 -> "Janub (S)"
                normalized < 247.5 -> "Janubi-G'arb (SW)"
                normalized < 292.5 -> "G'arb (W)"
                else -> "Shimali-G'arb (NW)"
            }
            "ru" -> when {
                normalized >= 337.5 || normalized < 22.5 -> "Север (С)"
                normalized < 67.5 -> "Северо-Восток (СВ)"
                normalized < 112.5 -> "Восток (В)"
                normalized < 157.5 -> "Юго-Восток (ЮВ)"
                normalized < 202.5 -> "Юг (Ю)"
                normalized < 247.5 -> "Юго-Запад (ЮЗ)"
                normalized < 292.5 -> "Запад (З)"
                else -> "Северо-Запад (СЗ)"
            }
            else -> when {
                normalized >= 337.5 || normalized < 22.5 -> "North (N)"
                normalized < 67.5 -> "North-East (NE)"
                normalized < 112.5 -> "East (E)"
                normalized < 157.5 -> "South-East (SE)"
                normalized < 202.5 -> "South (S)"
                normalized < 247.5 -> "South-West (SW)"
                normalized < 292.5 -> "West (W)"
                else -> "North-West (NW)"
            }
        }
    }

    fun getWindAbbreviation(degree: Double): String {
        val normalized = (degree % 360 + 360) % 360
        return when {
            normalized >= 337.5 || normalized < 22.5 -> "N"
            normalized < 67.5 -> "NE"
            normalized < 112.5 -> "E"
            normalized < 157.5 -> "SE"
            normalized < 202.5 -> "S"
            normalized < 247.5 -> "SW"
            normalized < 292.5 -> "W"
            else -> "NW"
        }
    }

    /**
     * Calculates specific condition probability percentage for any WMO code.
     */
    fun getWeatherTypeProbability(code: Int, precipProb: Int?, cloudCover: Double? = null, lang: String = "en"): WeatherProbabilityInfo {
        val prob = when (code) {
            0 -> (100 - (precipProb ?: 5) - (cloudCover?.toInt() ?: 5)).coerceIn(80, 100)
            1 -> (100 - (precipProb ?: 10) - (cloudCover?.toInt() ?: 20)).coerceIn(65, 95)
            2 -> (cloudCover?.toInt() ?: 45).coerceIn(40, 85)
            3 -> (cloudCover?.toInt() ?: 85).coerceIn(70, 100)
            45, 48 -> 75
            51, 53, 55 -> (precipProb ?: 65).coerceIn(45, 95)
            56, 57 -> (precipProb ?: 70).coerceIn(50, 95)
            61, 63, 65 -> (precipProb ?: 80).coerceIn(60, 100)
            66, 67 -> (precipProb ?: 85).coerceIn(65, 100)
            71, 73, 75 -> (precipProb ?: 85).coerceIn(65, 100)
            80, 81, 82 -> (precipProb ?: 75).coerceIn(50, 95)
            85, 86 -> (precipProb ?: 80).coerceIn(60, 98)
            95, 96, 99 -> (precipProb ?: 90).coerceIn(75, 100)
            else -> (precipProb ?: 50).coerceIn(10, 90)
        }

        val info = getWeatherInfo(code)
        val label = when (code) {
            0, 1 -> WeatherLocalization.get("clear_sky_probability", lang)
            2, 3 -> WeatherLocalization.get("cloud_probability", lang)
            71, 73, 75, 85, 86 -> WeatherLocalization.get("snow_probability", lang)
            95, 96, 99 -> WeatherLocalization.get("storm_probability", lang)
            else -> WeatherLocalization.get("rain_probability", lang)
        }

        return WeatherProbabilityInfo(
            label = label,
            percentage = prob,
            icon = info.icon,
            tint = info.iconColor
        )
    }

    /**
     * Generates a complete breakdown of probabilities across ALL weather types.
     */
    fun getAllWeatherTypeProbabilities(
        code: Int,
        precipProb: Int?,
        cloudCover: Double?,
        windSpeed: Double?,
        lang: String = "en"
    ): List<WeatherProbabilityInfo> {
        val basePrecip = precipProb ?: when (code) {
            in 51..67, in 80..82 -> 80
            in 71..77, in 85..86 -> 85
            in 95..99 -> 92
            else -> 10
        }

        val cloud = (cloudCover?.toInt() ?: when (code) {
            0 -> 5
            1 -> 25
            2 -> 55
            3 -> 90
            else -> 60
        }).coerceIn(0, 100)

        val clearProb = if (code in listOf(0, 1)) (100 - basePrecip - cloud / 2).coerceIn(75, 100)
                        else (100 - basePrecip - cloud).coerceIn(5, 55)

        val cloudProb = if (code in listOf(2, 3, 45, 48)) cloud.coerceIn(60, 100) else cloud.coerceIn(10, 80)

        val rainProb = if (code in listOf(51, 53, 55, 61, 63, 65, 66, 67, 80, 81, 82)) basePrecip.coerceIn(60, 100)
                       else if (code in 95..99) basePrecip.coerceIn(50, 95)
                       else (basePrecip / 2).coerceIn(2, 40)

        val snowProb = if (code in listOf(71, 73, 75, 85, 86)) basePrecip.coerceIn(65, 100)
                       else if (code in listOf(56, 57, 66, 67)) (basePrecip * 0.8).toInt().coerceIn(30, 85)
                       else 0

        val stormProb = if (code in 95..99) basePrecip.coerceIn(75, 100)
                        else if (code in listOf(65, 82)) (basePrecip * 0.35).toInt().coerceIn(10, 45)
                        else (basePrecip * 0.1).toInt().coerceIn(0, 15)

        val windVal = windSpeed ?: 12.0
        val windProb = when {
            windVal > 40 -> 95
            windVal > 25 -> 75
            windVal > 15 -> 45
            else -> (windVal * 2).toInt().coerceIn(5, 30)
        }

        return listOf(
            WeatherProbabilityInfo(
                label = WeatherLocalization.get("clear_sky_probability", lang),
                percentage = clearProb,
                icon = Icons.Outlined.WbSunny,
                tint = SunlightYellow
            ),
            WeatherProbabilityInfo(
                label = WeatherLocalization.get("cloud_probability", lang),
                percentage = cloudProb,
                icon = Icons.Outlined.Cloud,
                tint = SkyBlue
            ),
            WeatherProbabilityInfo(
                label = WeatherLocalization.get("rain_probability", lang),
                percentage = rainProb,
                icon = Icons.Outlined.WaterDrop,
                tint = RainCyan
            ),
            WeatherProbabilityInfo(
                label = WeatherLocalization.get("snow_probability", lang),
                percentage = snowProb,
                icon = Icons.Outlined.AcUnit,
                tint = SnowWhite
            ),
            WeatherProbabilityInfo(
                label = WeatherLocalization.get("storm_probability", lang),
                percentage = stormProb,
                icon = Icons.Outlined.Thunderstorm,
                tint = StormViolet
            ),
            WeatherProbabilityInfo(
                label = WeatherLocalization.get("wind_gust_probability", lang),
                percentage = windProb,
                icon = Icons.Outlined.Air,
                tint = NeonCyan
            )
        )
    }
}

data class WeatherProbabilityInfo(
    val label: String,
    val percentage: Int,
    val icon: ImageVector,
    val tint: Color
)
