package com.example.ui.viewmodel

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeocodingResult
import com.example.data.api.WeatherResponse
import com.example.data.db.AlertEntity
import com.example.data.db.SavedLocation
import com.example.data.repository.WeatherRepository
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.util.*

sealed interface WeatherUiState {
    object Loading : WeatherUiState
    data class Success(
        val location: SavedLocation,
        val weather: WeatherResponse,
        val alerts: List<AlertEntity>
    ) : WeatherUiState
    data class Error(val message: String) : WeatherUiState
}

@OptIn(FlowPreview::class)
class WeatherViewModel(private val repository: WeatherRepository) : ViewModel() {

    private var weatherCollectionJob: kotlinx.coroutines.Job? = null

    // --- Weather UI State ---
    private val _uiState = MutableStateFlow<WeatherUiState>(WeatherUiState.Loading)
    val uiState: StateFlow<WeatherUiState> = _uiState.asStateFlow()

    // --- Search Query and Results Flow ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<GeocodingResult>>(emptyList())
    val searchResults = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching = _isSearching.asStateFlow()

    // --- Saved Locations and Alerts Flows ---
    val savedLocations: StateFlow<List<SavedLocation>> = repository.savedLocations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val weatherAlerts: StateFlow<List<AlertEntity>> = repository.weatherAlerts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadAlertsCount: StateFlow<Int> = repository.unreadAlertsCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val recentSearches: StateFlow<List<String>> = repository.recentSearches
        .map { list -> list.map { it.query } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Dark / Light Mode Preference ---
    private val _isDarkMode = MutableStateFlow(true) // Default to gorgeous dark mode as requested
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // --- Multilingual Support ("en", "uz", "ru") ---
    private val _currentLanguage = MutableStateFlow("en")
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    // --- Automatic Refresh & Timestamp State ---
    private val _lastUpdatedMillis = MutableStateFlow(System.currentTimeMillis())
    val lastUpdatedMillis: StateFlow<Long> = _lastUpdatedMillis.asStateFlow()

    private val _nextRefreshSeconds = MutableStateFlow(15 * 60) // 15 minutes = 900s
    val nextRefreshSeconds: StateFlow<Int> = _nextRefreshSeconds.asStateFlow()

    private var autoRefreshTimerJob: kotlinx.coroutines.Job? = null

    fun setLanguage(lang: String) {
        _currentLanguage.value = lang
    }

    fun toggleTheme() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun setTheme(dark: Boolean) {
        _isDarkMode.value = dark
    }

    private var fusedLocationClient: FusedLocationProviderClient? = null

    init {
        // Trigger search suggestion updates on text change
        viewModelScope.launch {
            _searchQuery
                .debounce(500)
                .distinctUntilChanged()
                .collectLatest { query ->
                    if (query.length >= 2) {
                        performSearch(query)
                    } else {
                        _searchResults.value = emptyList()
                    }
                }
        }

        // Load the initial location on app launch (default to London, UK if nothing saved yet)
        viewModelScope.launch {
            val current = repository.getCurrentSelectedLocation()
            if (current != null) {
                selectLocation(current)
            } else {
                // Check if we have any saved locations, otherwise load a beautiful default (e.g., Tokyo or New York)
                val saved = repository.savedLocations.first()
                if (saved.isNotEmpty()) {
                    selectLocation(saved.first())
                } else {
                    val defaultLoc = SavedLocation(
                        id = 5128581,
                        name = "New York",
                        country = "United States",
                        countryCode = "US",
                        admin1 = "New York",
                        admin2 = "New York County",
                        admin3 = "New York City",
                        admin4 = null,
                        latitude = 40.71427,
                        longitude = -74.00597,
                        isFavorite = true,
                        isCurrentLocation = true
                    )
                    repository.saveLocation(defaultLoc)
                    selectLocation(defaultLoc)
                }
            }
        }

        // Start 15-minute auto refresh countdown timer loop
        startAutoRefreshTimer()
    }

    private fun startAutoRefreshTimer() {
        autoRefreshTimerJob?.cancel()
        autoRefreshTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_nextRefreshSeconds.value > 1) {
                    _nextRefreshSeconds.value -= 1
                } else {
                    _nextRefreshSeconds.value = 15 * 60
                    refreshCurrentWeather()
                }
            }
        }
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    private suspend fun performSearch(query: String) {
        _isSearching.value = true
        repository.searchLocations(query, _currentLanguage.value).fold(
            onSuccess = { results ->
                _searchResults.value = results
                _isSearching.value = false
            },
            onFailure = {
                _searchResults.value = emptyList()
                _isSearching.value = false
            }
        )
    }

    fun selectLocation(location: SavedLocation) {
        viewModelScope.launch {
            _uiState.value = WeatherUiState.Loading
            repository.selectCurrentLocation(location)
            repository.addSearchQuery(location.name)
            refreshWeatherForLocation(location)
        }
    }

    fun refreshCurrentWeather() {
        viewModelScope.launch {
            val currentLoc = repository.getCurrentSelectedLocation()
            if (currentLoc != null) {
                refreshWeatherForLocation(currentLoc)
            }
        }
    }

    private suspend fun refreshWeatherForLocation(location: SavedLocation) {
        weatherCollectionJob?.cancel()
        repository.fetchWeather(location.latitude, location.longitude).fold(
            onSuccess = { weatherResponse ->
                // Update timestamp and reset 15-minute countdown
                _lastUpdatedMillis.value = System.currentTimeMillis()
                _nextRefreshSeconds.value = 15 * 60

                // Generate alerts based on the real weather readings
                repository.processAndGenerateAlerts(location, weatherResponse)

                // Get local alerts from Room db to merge into success state safely in a single managed job
                weatherCollectionJob = viewModelScope.launch {
                    repository.weatherAlerts.collectLatest { alerts ->
                        val filteredAlerts = alerts.filter { it.locationId == location.id }
                        _uiState.value = WeatherUiState.Success(location, weatherResponse, filteredAlerts)
                    }
                }
            },
            onFailure = { error ->
                _uiState.value = WeatherUiState.Error(error.localizedMessage ?: "Failed to load weather forecast.")
            }
        )
    }

    fun saveLocationFromResult(result: GeocodingResult) {
        viewModelScope.launch {
            val newLocation = SavedLocation(
                id = result.id,
                name = result.name,
                country = result.country ?: "Unknown",
                countryCode = result.countryCode,
                admin1 = result.admin1,
                admin2 = result.admin2,
                admin3 = result.admin3,
                admin4 = result.admin4,
                latitude = result.latitude,
                longitude = result.longitude,
                isFavorite = false,
                isCurrentLocation = false
            )
            repository.saveLocation(newLocation)
            selectLocation(newLocation)
            // Reset query search states
            _searchQuery.value = ""
            _searchResults.value = emptyList()
        }
    }

    fun toggleFavorite(location: SavedLocation) {
        viewModelScope.launch {
            repository.toggleFavorite(location)
        }
    }

    fun deleteLocation(location: SavedLocation) {
        viewModelScope.launch {
            repository.deleteLocation(location)
            // If we deleted the current active location, fallback to remaining or default
            val active = repository.getCurrentSelectedLocation()
            if (active == null || active.id == location.id) {
                val remaining = repository.savedLocations.first()
                if (remaining.isNotEmpty()) {
                    selectLocation(remaining.first())
                } else {
                    _uiState.value = WeatherUiState.Error("No locations available. Please search and add a city!")
                }
            }
        }
    }

    fun clearSearchHistory() {
        viewModelScope.launch {
            repository.clearSearchHistory()
        }
    }

    fun markAllAlertsAsRead() {
        viewModelScope.launch {
            repository.markAllAlertsAsRead()
        }
    }

    // --- Extreme Weather Warning Simulator ---
    fun simulateExtremeWeatherWarning(severity: String, title: String, message: String) {
        viewModelScope.launch {
            val currentLoc = repository.getCurrentSelectedLocation()
            if (currentLoc != null) {
                repository.insertManualSimulatedAlert(
                    location = currentLoc,
                    title = title,
                    message = message,
                    severity = severity
                )
                // Refresh to pull the simulated alert into the success state immediately
                refreshWeatherForLocation(currentLoc)
            }
        }
    }

    // --- Real Device Location Services Support ---
    @SuppressLint("MissingPermission")
    fun requestDeviceLocation(context: Context) {
        if (fusedLocationClient == null) {
            fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
        }
        viewModelScope.launch {
            _uiState.value = WeatherUiState.Loading
            var retrieved = false

            // Set up a 7.5-second timeout job to handle hung GPS states elegantly
            val timeoutJob = launch {
                delay(7500)
                if (!retrieved) {
                    retrieved = true // prevent concurrent double-triggers
                    val cachedLoc = repository.getCurrentSelectedLocation() ?: repository.savedLocations.first().firstOrNull()
                    if (cachedLoc != null) {
                        refreshWeatherForLocation(cachedLoc)
                        android.widget.Toast.makeText(
                            context, 
                            "Location request timed out. Showing last active city.", 
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        _uiState.value = WeatherUiState.Error("GPS request timed out. Please select location manually.")
                    }
                }
            }

            fun processLocation(loc: Location) {
                if (!retrieved) {
                    retrieved = true
                    timeoutJob.cancel()
                    getWeatherByCoordinates(context, loc.latitude, loc.longitude)
                }
            }

            try {
                // 1. FAST PATH: Check the cached lastLocation first (usually instant and highly reliable)
                fusedLocationClient?.lastLocation?.addOnSuccessListener { lastLoc: Location? ->
                    if (lastLoc != null) {
                        processLocation(lastLoc)
                    } else if (!retrieved) {
                        // 2. BALANCED POWER ACCURACY PATH: Fast, works indoors and on virtual systems using cellular/Wi-Fi/GPS
                        fusedLocationClient?.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null)
                            ?.addOnSuccessListener { location: Location? ->
                                if (location != null) {
                                    processLocation(location)
                                } else if (!retrieved) {
                                    // 3. FULL ACCURACY FALLBACK: Try HIGH ACCURACY if balanced returned null
                                    fusedLocationClient?.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                                        ?.addOnSuccessListener { highLoc: Location? ->
                                            if (highLoc != null) {
                                                processLocation(highLoc)
                                            } else if (!retrieved) {
                                                retrieved = true
                                                timeoutJob.cancel()
                                                viewModelScope.launch {
                                                    val fallback = repository.getCurrentSelectedLocation()
                                                    if (fallback != null) {
                                                        refreshWeatherForLocation(fallback)
                                                    } else {
                                                        _uiState.value = WeatherUiState.Error("Could not retrieve GPS coordinates. Please search manually.")
                                                    }
                                                }
                                            }
                                        }?.addOnFailureListener {
                                            if (!retrieved) {
                                                retrieved = true
                                                timeoutJob.cancel()
                                                viewModelScope.launch {
                                                    val fallback = repository.getCurrentSelectedLocation()
                                                    if (fallback != null) {
                                                        refreshWeatherForLocation(fallback)
                                                    } else {
                                                        _uiState.value = WeatherUiState.Error("GPS request failed. Please search manually.")
                                                    }
                                                }
                                            }
                                        }
                                }
                            }?.addOnFailureListener {
                                if (!retrieved) {
                                    // Fallback to high accuracy if balanced query failed
                                    fusedLocationClient?.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                                        ?.addOnSuccessListener { highLoc: Location? ->
                                            if (highLoc != null) {
                                                processLocation(highLoc)
                                            } else if (!retrieved) {
                                                retrieved = true
                                                timeoutJob.cancel()
                                                viewModelScope.launch {
                                                    val fallback = repository.getCurrentSelectedLocation()
                                                    if (fallback != null) {
                                                        refreshWeatherForLocation(fallback)
                                                    } else {
                                                        _uiState.value = WeatherUiState.Error("GPS request failed. Please search manually.")
                                                    }
                                                }
                                            }
                                        }?.addOnFailureListener { err ->
                                            if (!retrieved) {
                                                retrieved = true
                                                timeoutJob.cancel()
                                                _uiState.value = WeatherUiState.Error("GPS request failed: ${err.localizedMessage}")
                                            }
                                        }
                                }
                            }
                    }
                }?.addOnFailureListener {
                    // lastLocation check failed, try balanced location immediately
                    if (!retrieved) {
                        fusedLocationClient?.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null)
                            ?.addOnSuccessListener { location: Location? ->
                                if (location != null) {
                                    processLocation(location)
                                }
                            }
                    }
                }
            } catch (e: Exception) {
                if (!retrieved) {
                    retrieved = true
                    timeoutJob.cancel()
                    _uiState.value = WeatherUiState.Error("GPS Error: ${e.localizedMessage}")
                }
            }
        }
    }

    private fun getWeatherByCoordinates(context: Context, lat: Double, lon: Double) {
        viewModelScope.launch {
            _uiState.value = WeatherUiState.Loading
            val detectedLoc = repository.reverseGeocodeLocation(
                context = context,
                latitude = lat,
                longitude = lon,
                language = _currentLanguage.value
            )
            repository.saveLocation(detectedLoc)
            selectLocation(detectedLoc)
        }
    }
}

// Factory for VM
class WeatherViewModelFactory(private val repository: WeatherRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(WeatherViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return WeatherViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
