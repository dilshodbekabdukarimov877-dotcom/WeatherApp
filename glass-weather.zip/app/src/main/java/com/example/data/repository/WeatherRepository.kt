package com.example.data.repository

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import android.location.Geocoder
import com.example.data.api.GeocodingService
import com.example.data.api.GeocodingResult
import com.example.data.api.ReverseGeocodingService
import com.example.data.api.WeatherResponse
import com.example.data.api.WeatherService
import com.example.data.db.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.Locale
import java.util.concurrent.TimeUnit

class WeatherRepository(
    private val context: Context,
    private val database: AppDatabase
) {
    private val savedLocationDao = database.savedLocationDao()
    private val weatherAlertDao = database.weatherAlertDao()
    private val searchHistoryDao = database.searchHistoryDao()

    // --- Retrofit Setup ---
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        })
        .build()

    private val weatherService: WeatherService = Retrofit.Builder()
        .baseUrl("https://api.open-meteo.com/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create())
        .build()
        .create(WeatherService::class.java)



    private val geocodingService: GeocodingService = Retrofit.Builder()
        .baseUrl("https://geocoding-api.open-meteo.com/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create())
        .build()
        .create(GeocodingService::class.java)

    private val reverseGeocodingService: ReverseGeocodingService = Retrofit.Builder()
        .baseUrl("https://api.bigdatacloud.net/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create())
        .build()
        .create(ReverseGeocodingService::class.java)

    // --- Weather & Search Operations ---

    suspend fun reverseGeocodeLocation(context: Context, latitude: Double, longitude: Double, language: String = "en"): SavedLocation {
        return withContext(Dispatchers.IO) {
            // Layer 1: Try System Geocoder
            try {
                if (Geocoder.isPresent()) {
                    val geocoder = Geocoder(context, Locale.getDefault())
                    @Suppress("DEPRECATION")
                    val addresses = geocoder.getFromLocation(latitude, longitude, 1)
                    if (!addresses.isNullOrEmpty()) {
                        val address = addresses[0]
                        val cityName = address.locality 
                            ?: address.subAdminArea 
                            ?: address.adminArea 
                            ?: address.featureName
                        if (!cityName.isNullOrBlank()) {
                            return@withContext SavedLocation(
                                id = (latitude * 100000 + longitude * 100000).toLong(),
                                name = cityName,
                                country = address.countryName ?: "Current Location",
                                countryCode = address.countryCode,
                                admin1 = address.adminArea,
                                admin2 = address.subAdminArea,
                                admin3 = address.locality,
                                admin4 = address.thoroughfare,
                                latitude = latitude,
                                longitude = longitude,
                                isFavorite = false,
                                isCurrentLocation = true
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // Layer 2: Try BigDataCloud Reverse Geocoding Service
            try {
                val response = reverseGeocodingService.reverseGeocode(latitude, longitude, language)
                val cityName = response.city?.ifBlank { null }
                    ?: response.locality?.ifBlank { null }
                    ?: response.principalSubdivision
                if (!cityName.isNullOrBlank()) {
                    return@withContext SavedLocation(
                        id = (latitude * 100000 + longitude * 100000).toLong(),
                        name = cityName,
                        country = response.countryName ?: "Current Location",
                        countryCode = response.countryCode,
                        admin1 = response.principalSubdivision,
                        admin2 = response.locality,
                        admin3 = null,
                        admin4 = null,
                        latitude = latitude,
                        longitude = longitude,
                        isFavorite = false,
                        isCurrentLocation = true
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // Fallback: Default location name
            SavedLocation(
                id = (latitude * 100000 + longitude * 100000).toLong(),
                name = "My Location",
                country = "Current Location",
                countryCode = null,
                admin1 = "Coordinates: %.3f, %.3f".format(Locale.US, latitude, longitude),
                admin2 = null,
                admin3 = null,
                admin4 = null,
                latitude = latitude,
                longitude = longitude,
                isFavorite = false,
                isCurrentLocation = true
            )
        }
    }

    suspend fun fetchWeather(latitude: Double, longitude: Double): Result<WeatherResponse> {
         return withContext(Dispatchers.IO) {
             try {
                 val response = weatherService.getWeatherForecast(latitude, longitude)
                 Result.success(response)
             } catch (e: Exception) {
                 Result.failure(e)
             }
         }
     }

    suspend fun searchLocations(query: String, language: String = "en"): Result<List<GeocodingResult>> {
        if (query.isBlank()) return Result.success(emptyList())
        return withContext(Dispatchers.IO) {
            try {
                val response = geocodingService.searchLocation(query = query, language = language)
                Result.success(response.results ?: emptyList())
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    // --- Room Local Operations ---

    val savedLocations: Flow<List<SavedLocation>> = savedLocationDao.getAllLocationsFlow()
    val favoriteLocations: Flow<List<SavedLocation>> = savedLocationDao.getFavoritesFlow()
    val weatherAlerts: Flow<List<AlertEntity>> = weatherAlertDao.getAllAlertsFlow()
    val recentSearches: Flow<List<SearchHistory>> = searchHistoryDao.getRecentHistoryFlow()
    val unreadAlertsCount: Flow<Int> = weatherAlertDao.getUnreadAlertsCountFlow()

    suspend fun saveLocation(location: SavedLocation) = withContext(Dispatchers.IO) {
        savedLocationDao.insertLocation(location)
    }

    suspend fun deleteLocation(location: SavedLocation) = withContext(Dispatchers.IO) {
        savedLocationDao.deleteLocation(location)
        weatherAlertDao.deleteAlertsByLocation(location.id)
    }

    suspend fun toggleFavorite(location: SavedLocation) = withContext(Dispatchers.IO) {
        savedLocationDao.updateLocation(location.copy(isFavorite = !location.isFavorite))
    }

    suspend fun selectCurrentLocation(location: SavedLocation) = withContext(Dispatchers.IO) {
        savedLocationDao.setCurrentLocation(location)
    }

    suspend fun getCurrentSelectedLocation(): SavedLocation? = withContext(Dispatchers.IO) {
        savedLocationDao.getCurrentLocation()
    }

    suspend fun addSearchQuery(query: String) = withContext(Dispatchers.IO) {
        if (query.isNotBlank()) {
            searchHistoryDao.insertSearch(SearchHistory(query.trim(), System.currentTimeMillis()))
        }
    }

    suspend fun deleteSearchQuery(query: String) = withContext(Dispatchers.IO) {
        searchHistoryDao.deleteSearch(query)
    }

    suspend fun clearSearchHistory() = withContext(Dispatchers.IO) {
        searchHistoryDao.clearAllHistory()
    }

    suspend fun markAlertAsRead(alertId: Int) = withContext(Dispatchers.IO) {
        weatherAlertDao.markAlertAsRead(alertId)
    }

    suspend fun markAllAlertsAsRead() = withContext(Dispatchers.IO) {
        weatherAlertDao.markAllAlertsAsRead()
    }

    // --- Local Alerts Generation & Local Push Notifications ---

    suspend fun processAndGenerateAlerts(location: SavedLocation, weather: WeatherResponse) = withContext(Dispatchers.IO) {
        val code = weather.current?.weatherCode ?: 0
        val temp = weather.current?.temperature ?: 20.0
        val wind = weather.current?.windSpeed ?: 10.0

        val alertsToGenerate = mutableListOf<AlertEntity>()

        // 1. Extreme temperature warnings
        if (temp > 38.0) {
            alertsToGenerate.add(
                AlertEntity(
                    locationId = location.id,
                    locationName = location.name,
                    title = "Extreme Heat Warning",
                    message = "Dangerous heat indices expected up to ${temp}°C in ${location.name}. Stay hydrated and avoid outdoor exposure.",
                    severity = "CRITICAL"
                )
            )
        } else if (temp < -10.0) {
            alertsToGenerate.add(
                AlertEntity(
                    locationId = location.id,
                    locationName = location.name,
                    title = "Extreme Cold Advisory",
                    message = "Sub-zero temperatures of ${temp}°C are affecting ${location.name}. Frostbite can occur quickly.",
                    severity = "WARNING"
                )
            )
        }

        // 2. High wind advisory
        if (wind > 60.0) {
            alertsToGenerate.add(
                AlertEntity(
                    locationId = location.id,
                    locationName = location.name,
                    title = "Severe Gale Warning",
                    message = "High winds up to ${wind} km/h can cause structural damage and dangerous driving conditions in ${location.name}.",
                    severity = "CRITICAL"
                )
            )
        } else if (wind > 40.0) {
            alertsToGenerate.add(
                AlertEntity(
                    locationId = location.id,
                    locationName = location.name,
                    title = "Wind Advisory",
                    message = "Breezy conditions up to ${wind} km/h in ${location.name}. Secure loose outdoor objects.",
                    severity = "INFO"
                )
            )
        }

        // 3. Precipitation / Thunderstorm warnings
        when (code) {
            95, 96, 99 -> {
                alertsToGenerate.add(
                    AlertEntity(
                        locationId = location.id,
                        locationName = location.name,
                        title = "Severe Thunderstorm Warning",
                        message = "Thunderstorms with active lightning, heavy rain, and potential hail are detected in ${location.name}.",
                        severity = "CRITICAL"
                    )
                )
            }
            65, 82 -> {
                alertsToGenerate.add(
                    AlertEntity(
                        locationId = location.id,
                        locationName = location.name,
                        title = "Heavy Rainfall Warning",
                        message = "Torrential rain detected in ${location.name}. Risk of localized flash flooding in low-lying areas.",
                        severity = "WARNING"
                    )
                )
            }
            75, 86 -> {
                alertsToGenerate.add(
                    AlertEntity(
                        locationId = location.id,
                        locationName = location.name,
                        title = "Heavy Snow Warning",
                        message = "Intense winter snowfall is causing accumulation. Hazardous road conditions in ${location.name}.",
                        severity = "WARNING"
                    )
                )
            }
        }

        // Insert alerts to local DB and fire notification alerts for new alerts
        for (alert in alertsToGenerate) {
            weatherAlertDao.insertAlert(alert)
            triggerPushNotification(alert)
        }
    }

    /**
     * Triggers a system local notification that acts and looks like a push notification.
     */
    private fun triggerPushNotification(alert: AlertEntity) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "weather_alerts_channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = "Extreme Weather Alerts"
            val importance = when (alert.severity) {
                "CRITICAL" -> NotificationManager.IMPORTANCE_HIGH
                "WARNING" -> NotificationManager.IMPORTANCE_DEFAULT
                else -> NotificationManager.IMPORTANCE_LOW
            }
            val channel = NotificationChannel(channelId, channelName, importance).apply {
                description = "Channel for extreme weather bulletins and safety alerts."
                enableVibration(true)
                vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            alert.id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val icon = when (alert.severity) {
            "CRITICAL" -> android.R.drawable.ic_dialog_alert
            "WARNING" -> android.R.drawable.stat_sys_warning
            else -> android.R.drawable.ic_dialog_info
        }

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(icon)
            .setContentTitle("[${alert.severity}] ${alert.title}")
            .setContentText("${alert.locationName}: ${alert.message}")
            .setStyle(NotificationCompat.BigTextStyle().bigText("${alert.locationName}: ${alert.message}"))
            .setPriority(
                when (alert.severity) {
                    "CRITICAL" -> NotificationCompat.PRIORITY_HIGH
                    "WARNING" -> NotificationCompat.PRIORITY_DEFAULT
                    else -> NotificationCompat.PRIORITY_LOW
                }
            )
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(alert.id, notification)
    }

    // Direct manual alert insertion for simulated testing of alerts and push notifications
    suspend fun insertManualSimulatedAlert(location: SavedLocation, title: String, message: String, severity: String) = withContext(Dispatchers.IO) {
        val alert = AlertEntity(
            locationId = location.id,
            locationName = location.name,
            title = title,
            message = message,
            severity = severity
        )
        weatherAlertDao.insertAlert(alert)
        triggerPushNotification(alert)
    }
}
