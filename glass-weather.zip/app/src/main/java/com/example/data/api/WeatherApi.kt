package com.example.data.api

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.http.GET
import retrofit2.http.Query

// --- Geocoding Models ---
@JsonClass(generateAdapter = true)
data class GeocodingResponse(
    @Json(name = "results") val results: List<GeocodingResult>?
)

@JsonClass(generateAdapter = true)
data class GeocodingResult(
    @Json(name = "id") val id: Long,
    @Json(name = "name") val name: String,
    @Json(name = "latitude") val latitude: Double,
    @Json(name = "longitude") val longitude: Double,
    @Json(name = "country") val country: String?,
    @Json(name = "country_code") val countryCode: String?,
    @Json(name = "admin1") val admin1: String?, // District / State
    @Json(name = "admin2") val admin2: String?, // County / Prefecture
    @Json(name = "admin3") val admin3: String?, // City / Municipality
    @Json(name = "admin4") val admin4: String?  // Village / Locality
)

// --- Reverse Geocoding Models ---
@JsonClass(generateAdapter = true)
data class BigDataCloudReverseGeocodeResponse(
    @Json(name = "city") val city: String? = null,
    @Json(name = "locality") val locality: String? = null,
    @Json(name = "principalSubdivision") val principalSubdivision: String? = null,
    @Json(name = "countryName") val countryName: String? = null,
    @Json(name = "countryCode") val countryCode: String? = null
)

// --- Weather Models ---
@JsonClass(generateAdapter = true)
data class WeatherResponse(
    @Json(name = "latitude") val latitude: Double,
    @Json(name = "longitude") val longitude: Double,
    @Json(name = "current") val current: CurrentWeather?,
    @Json(name = "hourly") val hourly: HourlyWeather?,
    @Json(name = "daily") val daily: DailyWeather?
)

@JsonClass(generateAdapter = true)
data class CurrentWeather(
    @Json(name = "time") val time: String,
    @Json(name = "temperature_2m") val temperature: Double,
    @Json(name = "relative_humidity_2m") val humidity: Double,
    @Json(name = "apparent_temperature") val apparentTemperature: Double,
    @Json(name = "is_day") val isDay: Int,
    @Json(name = "precipitation") val precipitation: Double,
    @Json(name = "rain") val rain: Double,
    @Json(name = "showers") val showers: Double,
    @Json(name = "snowfall") val snowfall: Double,
    @Json(name = "weather_code") val weatherCode: Int,
    @Json(name = "cloud_cover") val cloudCover: Double,
    @Json(name = "pressure_msl") val pressure: Double,
    @Json(name = "wind_speed_10m") val windSpeed: Double,
    @Json(name = "wind_direction_10m") val windDirection: Double? = 0.0
)

@JsonClass(generateAdapter = true)
data class HourlyWeather(
    @Json(name = "time") val time: List<String>,
    @Json(name = "temperature_2m") val temperature: List<Double>,
    @Json(name = "weather_code") val weatherCode: List<Int>,
    @Json(name = "precipitation_probability") val precipitationProbability: List<Int>? = null
)

@JsonClass(generateAdapter = true)
data class DailyWeather(
    @Json(name = "time") val time: List<String>,
    @Json(name = "weather_code") val weatherCode: List<Int>,
    @Json(name = "temperature_2m_max") val tempMax: List<Double>,
    @Json(name = "temperature_2m_min") val tempMin: List<Double>,
    @Json(name = "apparent_temperature_max") val apparentTempMax: List<Double>,
    @Json(name = "apparent_temperature_min") val apparentTempMin: List<Double>,
    @Json(name = "sunrise") val sunrise: List<String>,
    @Json(name = "sunset") val sunset: List<String>,
    @Json(name = "uv_index_max") val uvIndexMax: List<Double>,
    @Json(name = "precipitation_sum") val precipitationSum: List<Double>,
    @Json(name = "wind_speed_10m_max") val windSpeedMax: List<Double>,
    @Json(name = "wind_direction_10m_dominant") val windDirectionDominant: List<Double>? = null,
    @Json(name = "precipitation_probability_max") val precipitationProbabilityMax: List<Int>? = null,
    @Json(name = "precipitation_probability_mean") val precipitationProbabilityMean: List<Int>? = null
)

// --- Retrofit API Interfaces ---
interface WeatherService {
    @GET("v1/forecast")
    suspend fun getWeatherForecast(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("current") current: String = "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,snowfall,weather_code,cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m",
        @Query("daily") daily: String = "weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,sunrise,sunset,uv_index_max,precipitation_sum,wind_speed_10m_max,wind_direction_10m_dominant,precipitation_probability_max,precipitation_probability_mean",
        @Query("hourly") hourly: String = "temperature_2m,weather_code,precipitation_probability",
        @Query("timezone") timezone: String = "auto"
    ): WeatherResponse
}

interface GeocodingService {
    @GET("v1/search")
    suspend fun searchLocation(
        @Query("name") query: String,
        @Query("count") count: Int = 10,
        @Query("language") language: String = "en",
        @Query("format") format: String = "json"
    ): GeocodingResponse
}

interface ReverseGeocodingService {
    @GET("data/reverse-geocode-client")
    suspend fun reverseGeocode(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("localityLanguage") localityLanguage: String = "en"
    ): BigDataCloudReverseGeocodeResponse
}


