package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// --- Room Entities ---

@Entity(tableName = "saved_locations")
data class SavedLocation(
    @PrimaryKey val id: Long, // Open-Meteo ID
    val name: String,
    val country: String,
    val countryCode: String?,
    val admin1: String?, // District / State
    val admin2: String?, // County
    val admin3: String?, // City
    val admin4: String?, // Village / Locality
    val latitude: Double,
    val longitude: Double,
    val isFavorite: Boolean = false,
    val isCurrentLocation: Boolean = false,
    val lastUpdated: Long = System.currentTimeMillis()
) {
    // Elegant utility to display hierarchical location path (e.g., "Village, City, Country" or "City, District, Country")
    fun getFullLocationDisplay(): String {
        val parts = mutableListOf<String>()
        if (!admin4.isNullOrBlank()) parts.add(admin4)
        if (!admin3.isNullOrBlank() && admin3 != admin4) parts.add(admin3)
        if (!admin1.isNullOrBlank() && admin1 != admin3 && admin1 != admin4) parts.add(admin1)
        if (!country.isNullOrBlank()) parts.add(country)
        return if (parts.isNotEmpty()) parts.joinToString(", ") else name
    }
}

@Entity(tableName = "weather_alerts")
data class AlertEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val locationId: Long,
    val locationName: String,
    val title: String,
    val message: String,
    val severity: String, // "INFO", "WARNING", "CRITICAL"
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

@Entity(tableName = "search_history")
data class SearchHistory(
    @PrimaryKey val query: String,
    val timestamp: Long = System.currentTimeMillis()
)

// --- DAOs ---

@Dao
interface SavedLocationDao {
    @Query("SELECT * FROM saved_locations ORDER BY lastUpdated DESC")
    fun getAllLocationsFlow(): Flow<List<SavedLocation>>

    @Query("SELECT * FROM saved_locations WHERE isFavorite = 1 ORDER BY lastUpdated DESC")
    fun getFavoritesFlow(): Flow<List<SavedLocation>>

    @Query("SELECT * FROM saved_locations WHERE isCurrentLocation = 1 LIMIT 1")
    suspend fun getCurrentLocation(): SavedLocation?

    @Query("SELECT * FROM saved_locations WHERE id = :id LIMIT 1")
    suspend fun getLocationById(id: Long): SavedLocation?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocation(location: SavedLocation)

    @Update
    suspend fun updateLocation(location: SavedLocation)

    @Delete
    suspend fun deleteLocation(location: SavedLocation)

    @Query("UPDATE saved_locations SET isCurrentLocation = 0")
    suspend fun clearCurrentLocationFlag()

    @Transaction
    suspend fun setCurrentLocation(location: SavedLocation) {
        clearCurrentLocationFlag()
        insertLocation(location.copy(isCurrentLocation = true))
    }
}

@Dao
interface WeatherAlertDao {
    @Query("SELECT * FROM weather_alerts ORDER BY timestamp DESC")
    fun getAllAlertsFlow(): Flow<List<AlertEntity>>

    @Query("SELECT * FROM weather_alerts WHERE locationId = :locationId ORDER BY timestamp DESC")
    fun getAlertsForLocationFlow(locationId: Long): Flow<List<AlertEntity>>

    @Query("SELECT COUNT(*) FROM weather_alerts WHERE isRead = 0")
    fun getUnreadAlertsCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: AlertEntity)

    @Query("UPDATE weather_alerts SET isRead = 1 WHERE id = :alertId")
    suspend fun markAlertAsRead(alertId: Int)

    @Query("UPDATE weather_alerts SET isRead = 1")
    suspend fun markAllAlertsAsRead()

    @Query("DELETE FROM weather_alerts WHERE timestamp < :expirationTime")
    suspend fun deleteExpiredAlerts(expirationTime: Long)

    @Query("DELETE FROM weather_alerts WHERE locationId = :locationId")
    suspend fun deleteAlertsByLocation(locationId: Long)
}

@Dao
interface SearchHistoryDao {
    @Query("SELECT * FROM search_history ORDER BY timestamp DESC LIMIT 10")
    fun getRecentHistoryFlow(): Flow<List<SearchHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSearch(search: SearchHistory)

    @Query("DELETE FROM search_history WHERE query = :query")
    suspend fun deleteSearch(query: String)

    @Query("DELETE FROM search_history")
    suspend fun clearAllHistory()
}

// --- AppDatabase ---

@Database(
    entities = [SavedLocation::class, AlertEntity::class, SearchHistory::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun savedLocationDao(): SavedLocationDao
    abstract fun weatherAlertDao(): WeatherAlertDao
    abstract fun searchHistoryDao(): SearchHistoryDao
}
