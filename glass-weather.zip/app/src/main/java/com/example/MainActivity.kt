package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.room.Room
import com.example.data.db.AppDatabase
import com.example.data.repository.WeatherRepository
import com.example.ui.screens.WeatherDashboard
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.WeatherViewModel
import com.example.ui.viewmodel.WeatherViewModelFactory

class MainActivity : ComponentActivity() {

    // Initialize Room Database, WeatherRepository and WeatherViewModel lazily
    private val database by lazy {
        Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "glass_weather_cache.db"
        ).fallbackToDestructiveMigration().build()
    }

    private val repository by lazy {
        WeatherRepository(applicationContext, database)
    }

    private val viewModel: WeatherViewModel by viewModels {
        WeatherViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Supports full edge-to-edge transparent drawing
        enableEdgeToEdge()
        
        setContent {
            val isDarkTheme by viewModel.isDarkMode.collectAsState()
            
            MyApplicationTheme(darkTheme = isDarkTheme) {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    // Main Dashboard content containing our dynamic layers
                    WeatherDashboard(viewModel = viewModel)
                }
            }
        }
    }
}
